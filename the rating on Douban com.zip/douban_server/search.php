<?php
//#1.数据库连接 mysql -u root -p
//$coon = mysqli_connect("localhost","root","root");
////2.选择数据库进行操作
//mysqli_select_db($coon, "text");
//
////3.执行sql命令  select id,title form top250 limit 2,20;返回一个包含结果对象
//$result = mysqli_query($coon, "select id,title form top250");
//
////4. 从结果对象中取数据  mysqli_fetch_all返回数组
//$data_arr = mysqli_fetch_all("$result");
////mysqli_fetch_all 返回的是一个迭代器  每次只能取一条数据
////$row = mysqli_fetch_assoc();
////$data=[];
////while ($row = mysqli_fetch_assoc($result)){
////    array_push($data,$row);
////}
//
//
//#5.关闭连接
//mysqli_close($coon);
//
//#6. 构建接口向前端返回
////echo json_encode($data);
//echo json_encode($data_arr);





// 获取前端的参数
$keyword = $_GET["keyword"];
$page = $_GET["page"];

// 1. 数据库链接 mysql -u root -p root

$conn = mysqli_connect("localhost","root","root");

// 2. 选择数据库进行操作 use douban
mysqli_select_db($conn,"douban");
// 3. 执行sql命令 select id,title from top250 limit 0,20; 返回一个包含结果的对象
$sql = "select id,title,cover_url,score,types,release_date,regions,actors,typename from rank where title like '%".$keyword."%' limit ".(($page-1)*20).",20";
$result = mysqli_query($conn,$sql);

// 4. 从结果对象中取数据 mysqli_fetch_all返回一个数组
$data = [];
// mysqli_fetch_assoc 返回一个迭代器 每一次只能获取一条数据
while ($row = mysqli_fetch_assoc($result)){
    array_push($data,$row);
}
// 5. 关闭链接
mysqli_close($conn);
// 6. 构造接口向前端返回
echo json_encode($data);

?>
