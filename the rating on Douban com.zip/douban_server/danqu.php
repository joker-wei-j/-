<?php
$f=fopen("./data/4.热门单曲榜.json","r");
$data=fread($f,filesize("./data/4.热门单曲榜.json"));
echo $data;
?>



