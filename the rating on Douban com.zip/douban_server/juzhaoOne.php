<?php
$f=fopen("data/长津湖详情页数据/剧照/详情页长津湖数据剧照第1页.json","r");
$data=fread($f,filesize("data/长津湖详情页数据/剧照/详情页长津湖数据剧照第1页.json"));
echo $data;

?>