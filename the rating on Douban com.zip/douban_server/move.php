<?php
$page = $_GET["page"];
$dataName = $_GET["wenzi"];
$path="./data/查看更多页面相关数据/".$dataName."/$dataName"."第".$page."页.json";
$f = @fopen($path, "r") or die("[]");
echo fread($f, filesize($path));
?>