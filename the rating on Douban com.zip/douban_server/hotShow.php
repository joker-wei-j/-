<?php
$f=fopen("./data/2.豆瓣热门.json","r");
$data=fread($f,filesize("./data/2.豆瓣热门.json"));
echo $data;
?>