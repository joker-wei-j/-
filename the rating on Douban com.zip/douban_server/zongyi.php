<?php
$f=fopen("./data/4.近期热门综艺.json","r");
$data=fread($f,filesize("./data/4.近期热门综艺.json"));
echo $data;
?>
