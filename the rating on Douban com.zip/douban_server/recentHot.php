<?php
    $f=fopen("./data/3.近期热门剧集.json","r");
    $data=fread($f,filesize("./data/3.近期热门剧集.json"));
    echo $data;
?>