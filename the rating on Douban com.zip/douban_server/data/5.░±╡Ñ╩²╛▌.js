let data = {
	"one":"https://z3.ax1x.com/2021/07/17/WlueUO.png",
	"two":"https://z3.ax1x.com/2021/07/17/Wlum5D.png",
	"other":[
    {
        'msg': '豆瓣电影top250', "data": [
        {"rank": 1, "title": "肖申克救赎", "score": 9.7},
        {"rank": 2, "title": "霸王别姬", "score": 9.6},
        {"rank": 3, "title": "阿甘正传", "score": 9.5}],
        "cover": "https://z3.ax1x.com/2021/07/17/WlmIp9.png",
		"bigcover": "https://z3.ax1x.com/2021/07/19/WGdO6s.png"
    },
    {
        'msg': '科幻高分电影', "data": [
        {"rank": 1, "title": "星际穿越", "score": 9.3},
        {"rank": 2, "title": "黑客帝国", "score": 9},
        {"rank": 3, "title": "头号玩家", "score": 8.7}],
        "cover": "https://z3.ax1x.com/2021/07/17/Wlm2wT.png",
		"bigcover": "https://z3.ax1x.com/2021/07/19/WGwkc9.png"
    },
    {
        'msg': '喜剧高分电影', "data": [
        {"rank": 1, "title": "三傻大闹宝莱坞", "score": 9.2},
        {"rank": 2, "title": "大话西游之月光宝盒", "score": 9},
        {"rank": 3, "title": "两杆大烟枪", "score": 9.1}],
        "cover": "https://z3.ax1x.com/2021/07/17/Wlmsln.png",
		"bigcover": "https://z3.ax1x.com/2021/07/19/WGwChF.png"
    },
    {
        'msg': '动作高分电影', "data": [
        {"rank": 1, "title": "蝙蝠侠黑暗骑士崛起", "score": 8.8},
        {"rank": 2, "title": "谍影重重3", "score": 8.8},
        {"rank": 3, "title": "复仇者联盟4:终局之战", "score": 8.5}],
        "cover": "https://z3.ax1x.com/2021/07/17/Wlmyyq.png",
		"bigcover": "https://z3.ax1x.com/2021/07/19/WGwF1J.png"
    },
    {
        'msg': '爱情高分电影', "data": [
        {"rank": 1, "title": "泰坦尼克号", "score": 9.4},
        {"rank": 2, "title": "大话西游之大圣娶亲", "score": 9.2},
        {"rank": 3, "title": "乱世佳人", "score": 9.3}],
        "cover": "https://z3.ax1x.com/2021/07/17/WlmRTU.png",
		"bigcover": "https://z3.ax1x.com/2021/07/19/WGw9tU.png"
    },
    {
        'msg': '华语口碑剧集周榜', "data": [
        {"rank": 1, "title": "香港爱情故事", "score": 8.9},
        {"rank": 2, "title": "守护解放西2", "score": 9.2},
        {"rank": 3, "title": "装台", "score": 8.4}],
        "cover": "https://z3.ax1x.com/2021/07/17/WlmhY4.png",
		"bigcover": "https://z3.ax1x.com/2021/07/19/WGwip4.png"
    },
    {
        'msg': '全球口碑剧集周榜', "data": [
        {"rank": 1, "title": "进击的巨人 第四季", "score": 9.8},
        {"rank": 2, "title": "无耻之徒 美版 第十一季", "score": 9.7},
        {"rank": 3, "title": "法官大人", "score": 9.1}],
        "cover": "https://z3.ax1x.com/2021/07/17/WlmgmV.png",
		"bigcover": "https://z3.ax1x.com/2021/07/19/WGdqpQ.png"
    },
    {
        'msg': '2019高分榜华语电影', "data": [
        {"rank": 1, "title": "哪吒之魔童降世", "score": 8.5},
        {"rank": 2, "title": "少年的你", "score": 8.3},
        {"rank": 3, "title": "谁先爱上他", "score": 8.6}],
        "cover": "https://z3.ax1x.com/2021/07/17/WlmrSs.png",
		"bigcover": "https://z3.ax1x.com/2021/07/19/WGdHfg.png"
    },
    {
        'msg': '2019高分榜外语电影', "data": [
        {"rank": 1, "title": "何以为家", "score": 9.1},
        {"rank": 2, "title": "绿皮书", "score": 8.9},
        {"rank": 3, "title": "小丑", "score": 8.7}],
        "cover": "https://z3.ax1x.com/2021/07/17/WlmBWj.png",
		"bigcover": "https://z3.ax1x.com/2021/07/19/WGdvmq.png"
    },
    {
        'msg': '2019高分榜冷门佳片', "data": [
        {"rank": 1, "title": "爱尔兰人", "score": 8.8},
        {"rank": 2, "title": "婚姻故事", "score": 8.6},
        {"rank": 3, "title": "死无对证", "score": 7.7}],
        "cover": "https://z3.ax1x.com/2021/07/17/Wlm6O0.png",
		"bigcover": "https://z3.ax1x.com/2021/07/19/WGdx00.png"
    },
    {
        'msg': '豆瓣读书虚构类周榜', "data": [
        {"rank": 1, "title": "记忆记忆", "score": 9.1},
        {"rank": 2, "title": "凡人之心", "score": 8.5},
        {"rank": 3, "title": "仙症", "score": 8.4}],
        "cover": "https://z3.ax1x.com/2021/07/17/WlmfkF.png",
		"bigcover": "https://z3.ax1x.com/2021/07/19/WGdLlj.png"
    },
    {
        'msg': '豆瓣读书非虚构类周榜', "data": [
        {"rank": 1, "title": "碎片", "score": 9.2},
        {"rank": 2, "title": "文化失忆", "score": 9.2},
        {"rank": 3, "title": "偏见的本质", "score": 9.1}],
        "cover": "https://z3.ax1x.com/2021/07/17/Wlm4fJ.png",
		"bigcover": "https://z3.ax1x.com/2021/07/19/WGwpkT.png"
    },
    {
        'msg': '豆瓣读书top250', "data": [
        {"rank": 1, "title": "红楼梦", "score": 9.6},
        {"rank": 2, "title": "活着", "score": 9.4},
        {"rank": 3, "title": "1984", "score": 9.3}],
        "cover": "https://z3.ax1x.com/2021/07/17/WlmIp9.png",
		"bigcover": "https://z3.ax1x.com/2021/07/19/WGdz7V.png"
    }
  ]
}


module.exports.board = data