let data = {
  "count": 20,
  "start": 0,
  "total": 11,
  "selected_collections": [
      {
          "cover_url": "https://img1.doubanio.com/dae/screenshot/image/html/14bf14d183c6a7ea.jpg?window_size=300,300&format=png",
          "subtitle": "豆瓣榜单",
          "description": "每周五更新；关注榜单，第一时间了解最新口碑佳片。",
          "header_fg_image": "https://img9.doubanio.com/img/roboport/files/file-movie_weekly_best-big_cover.png?ts=1635316420.62",
          "url": "",
          "items": [
              {
                  "rating": {
                      "count": 7394,
                      "max": 10,
                      "star_count": 4,
                      "value": 8.1
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2021-07-11(戛纳电影节)"
                  ],
                  "rank_value": 1,
                  "pic": {
                      "large": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p2639821491.jpg",
                      "normal": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2639821491.jpg"
                  },
                  "is_show": false,
                  "year": "2021",
                  "card_subtitle": "2021 / 日本 / 剧情 / 滨口龙介 / 西岛秀俊 冈田将生",
                  "id": "35235502",
                  "genres": [
                      "剧情"
                  ],
                  "trend_down": false,
                  "title": "驾驶我的车",
                  "trend_equal": true,
                  "trend_up": false,
                  "is_released": true,
                  "rank_value_changed": 0,
                  "actors": [
                      {
                          "name": "西岛秀俊"
                      },
                      {
                          "name": "冈田将生"
                      },
                      {
                          "name": "雾岛丽香"
                      },
                      {
                          "name": "三浦透子"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "9d9fa5",
                      "_base_color": [
                          0.6333333333333334,
                          0.048543689320388314,
                          0.807843137254902
                      ],
                      "secondary_color": "f4f5f9",
                      "_avg_color": [
                          0.8888888888888893,
                          0.05421686746987949,
                          0.6509803921568628
                      ],
                      "primary_color_dark": "797a7f"
                  },
                  "type": "movie",
                  "has_linewatch": false,
                  "cover_url": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p2639821491.jpg",
                  "sharing_url": "https://movie.douban.com/subject/35235502/",
                  "url": "https://movie.douban.com/subject/35235502/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/35235502",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "滨口龙介"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 28015,
                      "max": 10,
                      "star_count": 4,
                      "value": 8.1
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2021-07-28(韩国)"
                  ],
                  "rank_value": 2,
                  "pic": {
                      "large": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2697816056.jpg",
                      "normal": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2697816056.jpg"
                  },
                  "is_show": false,
                  "year": "2021",
                  "card_subtitle": "2021 / 韩国 / 剧情 动作 / 柳昇完 / 金允石 赵寅成",
                  "id": "33457594",
                  "genres": [
                      "剧情",
                      "动作"
                  ],
                  "trend_down": false,
                  "title": "摩加迪沙",
                  "trend_equal": true,
                  "trend_up": false,
                  "is_released": true,
                  "rank_value_changed": 0,
                  "actors": [
                      {
                          "name": "金允石"
                      },
                      {
                          "name": "赵寅成"
                      },
                      {
                          "name": "许峻豪"
                      },
                      {
                          "name": "具教焕"
                      },
                      {
                          "name": "金素真"
                      },
                      {
                          "name": "郑满植"
                      },
                      {
                          "name": "金在华"
                      },
                      {
                          "name": "朴庆惠"
                      },
                      {
                          "name": "尹敬浩"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "7c94a5",
                      "_base_color": [
                          0.5698924731182795,
                          0.25000000000000006,
                          0.48627450980392156
                      ],
                      "secondary_color": "f4f7f9",
                      "_avg_color": [
                          0.5396825396825395,
                          0.15217391304347824,
                          0.5411764705882353
                      ],
                      "primary_color_dark": "5f727f"
                  },
                  "type": "movie",
                  "has_linewatch": false,
                  "cover_url": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2697816056.jpg",
                  "sharing_url": "https://movie.douban.com/subject/33457594/",
                  "url": "https://movie.douban.com/subject/33457594/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/33457594",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "柳昇完"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 1959,
                      "max": 10,
                      "star_count": 4,
                      "value": 7.6
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2020-12-17(荷兰)"
                  ],
                  "rank_value": 3,
                  "pic": {
                      "large": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2697678847.jpg",
                      "normal": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2697678847.jpg"
                  },
                  "is_show": false,
                  "year": "2020",
                  "card_subtitle": "2020 / 荷兰 立陶宛 比利时 / 剧情 战争 / 马蒂耶斯·范·小海因根 / 吉斯·布洛姆 杰米·福雷特斯",
                  "id": "34803835",
                  "genres": [
                      "剧情",
                      "战争"
                  ],
                  "trend_down": false,
                  "title": "被遗忘的战役",
                  "trend_equal": false,
                  "trend_up": true,
                  "is_released": true,
                  "rank_value_changed": 8,
                  "actors": [
                      {
                          "name": "吉斯·布洛姆"
                      },
                      {
                          "name": "杰米·福雷特斯"
                      },
                      {
                          "name": "苏珊·雷德尔"
                      },
                      {
                          "name": "扬·贝弗特"
                      },
                      {
                          "name": "汤姆·费尔顿"
                      },
                      {
                          "name": "科恩·布里尔"
                      },
                      {
                          "name": "西奥·巴克利姆-比格斯"
                      },
                      {
                          "name": "斯科特·里德"
                      },
                      {
                          "name": "Marthe Schneider"
                      },
                      {
                          "name": "Ronald Kalter"
                      },
                      {
                          "name": "Hayo Bruins"
                      },
                      {
                          "name": "尤斯图斯·冯·多赫纳尼"
                      },
                      {
                          "name": "Joep Paddenburg"
                      },
                      {
                          "name": "马克·范·伊文"
                      },
                      {
                          "name": "Vincent van den Berg"
                      },
                      {
                          "name": "Bianca Krijgsman"
                      },
                      {
                          "name": "皮特·布科夫斯基"
                      },
                      {
                          "name": "罗吉尔·席佩斯"
                      },
                      {
                          "name": "罗伯特·内勒"
                      },
                      {
                          "name": "戈登·莫里斯"
                      },
                      {
                          "name": "理查德·迪兰"
                      },
                      {
                          "name": "雅各布·迪尔"
                      },
                      {
                          "name": "Simon Lee Phillips"
                      },
                      {
                          "name": "马蒂克斯·舍佩斯"
                      },
                      {
                          "name": "戴兰·史密斯"
                      },
                      {
                          "name": "Ilja Roßbander"
                      },
                      {
                          "name": "丹·希尔斯特"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "a59e93",
                      "_base_color": [
                          0.09999999999999994,
                          0.11235955056179768,
                          0.6980392156862745
                      ],
                      "secondary_color": "f9f7f4",
                      "_avg_color": [
                          0.07777777777777779,
                          0.10489510489510492,
                          0.5607843137254902
                      ],
                      "primary_color_dark": "7f7971"
                  },
                  "type": "movie",
                  "has_linewatch": false,
                  "cover_url": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2697678847.jpg",
                  "sharing_url": "https://movie.douban.com/subject/34803835/",
                  "url": "https://movie.douban.com/subject/34803835/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/34803835",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "马蒂耶斯·范·小海因根"
                      }
                  ],
                  "null_rating_reason": ""
              }
          ],
          "uri": "douban://douban.com/subject_collection/movie_weekly_best?type=rank&category=movie&rank_type=weekly",
          "updated_at": "2021-10-22 16:29:30",
          "covers": [
              "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2639821491.jpg",
              "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2697816056.jpg",
              "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2697678847.jpg"
          ],
          "name": "一周口碑电影榜",
          "icon_fg_image": null,
          "header_bg_image": "https://img3.doubanio.com/view/photo/photo/public/p2669288400.jpg",
          "type_text": "豆瓣周榜",
          "rank": true,
          "medium_name": "口碑电影",
          "total": 10,
          "type": "chart",
          "id": "movie_weekly_best",
          "background_color_scheme": {
              "is_dark": true,
              "primary_color_light": "727da5",
              "secondary_color": "f4f5f9",
              "primary_color_dark": "57607f"
          }
      },
      {
          "cover_url": "https://img9.doubanio.com/img/roboport/files/file-movie_top250-square_cover.png?ts=1635316466.89",
          "subtitle": "豆瓣榜单",
          "description": "根据“看过”人数、评分、评价等因素，通过算法得出的电影综合排名，每周更新。",
          "header_fg_image": "https://img9.doubanio.com/img/roboport/files/file-movie_top250-big_cover.png?ts=1635316466.89",
          "url": "",
          "items": [
              {
                  "rating": {
                      "count": 2472949,
                      "max": 10,
                      "star_count": 5,
                      "value": 9.7
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "1994-09-10(多伦多电影节)"
                  ],
                  "pic": {
                      "large": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p480747492.jpg",
                      "normal": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p480747492.jpg"
                  },
                  "is_show": false,
                  "year": "1994",
                  "card_subtitle": "1994 / 美国 / 犯罪 剧情 / 弗兰克·德拉邦特 / 蒂姆·罗宾斯 摩根·弗里曼",
                  "id": "1292052",
                  "genres": [
                      "犯罪",
                      "剧情"
                  ],
                  "title": "肖申克的救赎",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "蒂姆·罗宾斯"
                      },
                      {
                          "name": "摩根·弗里曼"
                      },
                      {
                          "name": "鲍勃·冈顿"
                      },
                      {
                          "name": "威廉姆·赛德勒"
                      },
                      {
                          "name": "克兰西·布朗"
                      },
                      {
                          "name": "吉尔·贝罗斯"
                      },
                      {
                          "name": "马克·罗斯顿"
                      },
                      {
                          "name": "詹姆斯·惠特摩"
                      },
                      {
                          "name": "杰弗里·德曼"
                      },
                      {
                          "name": "拉里·布兰登伯格"
                      },
                      {
                          "name": "尼尔·吉恩托利"
                      },
                      {
                          "name": "布赖恩·利比"
                      },
                      {
                          "name": "大卫·普罗瓦尔"
                      },
                      {
                          "name": "约瑟夫·劳格诺"
                      },
                      {
                          "name": "祖德·塞克利拉"
                      },
                      {
                          "name": "保罗·麦克兰尼"
                      },
                      {
                          "name": "芮妮·布莱恩"
                      },
                      {
                          "name": "阿方索·弗里曼"
                      },
                      {
                          "name": "V·J·福斯特"
                      },
                      {
                          "name": "弗兰克·梅德拉诺"
                      },
                      {
                          "name": "马克·迈尔斯"
                      },
                      {
                          "name": "尼尔·萨默斯"
                      },
                      {
                          "name": "耐德·巴拉米"
                      },
                      {
                          "name": "布赖恩·戴拉特"
                      },
                      {
                          "name": "唐·麦克马纳斯"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "723b2c",
                      "_base_color": [
                          0.03508771929824561,
                          0.6129032258064516,
                          0.12156862745098039
                      ],
                      "secondary_color": "f9f5f4",
                      "_avg_color": [
                          0.06060606060606061,
                          0.4125,
                          0.3137254901960784
                      ],
                      "primary_color_dark": "4c271d"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p480747492.jpg",
                  "sharing_url": "https://movie.douban.com/subject/1292052/",
                  "url": "https://movie.douban.com/subject/1292052/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/1292052",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "弗兰克·德拉邦特"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 1838242,
                      "max": 10,
                      "star_count": 5,
                      "value": 9.6
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "1993-07-26(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img3.doubanio.com/view/photo/m_ratio_poster/public/p2561716440.jpg",
                      "normal": "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2561716440.jpg"
                  },
                  "is_show": false,
                  "year": "1993",
                  "card_subtitle": "1993 / 中国大陆 中国香港 / 剧情 爱情 同性 / 陈凯歌 / 张国荣 张丰毅",
                  "id": "1291546",
                  "genres": [
                      "剧情",
                      "爱情",
                      "同性"
                  ],
                  "title": "霸王别姬",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "张国荣"
                      },
                      {
                          "name": "张丰毅"
                      },
                      {
                          "name": "巩俐"
                      },
                      {
                          "name": "葛优"
                      },
                      {
                          "name": "英达"
                      },
                      {
                          "name": "蒋雯丽"
                      },
                      {
                          "name": "吴大维"
                      },
                      {
                          "name": "吕齐"
                      },
                      {
                          "name": "雷汉"
                      },
                      {
                          "name": "尹治"
                      },
                      {
                          "name": "马明威"
                      },
                      {
                          "name": "费振翔"
                      },
                      {
                          "name": "智一桐"
                      },
                      {
                          "name": "李春"
                      },
                      {
                          "name": "赵海龙"
                      },
                      {
                          "name": "李丹"
                      },
                      {
                          "name": "童弟"
                      },
                      {
                          "name": "沈慧芬"
                      },
                      {
                          "name": "黄斐"
                      },
                      {
                          "name": "徐杰"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "a5a39e",
                      "_base_color": [
                          0.10606060606060595,
                          0.044715447154471614,
                          0.9647058823529412
                      ],
                      "secondary_color": "f9f8f4",
                      "_avg_color": [
                          0.01388888888888882,
                          0.054298642533936715,
                          0.8666666666666667
                      ],
                      "primary_color_dark": "7f7d79"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img3.doubanio.com/view/photo/m_ratio_poster/public/p2561716440.jpg",
                  "sharing_url": "https://movie.douban.com/subject/1291546/",
                  "url": "https://movie.douban.com/subject/1291546/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/1291546",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "陈凯歌"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 1858410,
                      "max": 10,
                      "star_count": 5,
                      "value": 9.5
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "1994-06-23(洛杉矶首映)"
                  ],
                  "pic": {
                      "large": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p2372307693.jpg",
                      "normal": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2372307693.jpg"
                  },
                  "is_show": false,
                  "year": "1994",
                  "card_subtitle": "1994 / 美国 / 剧情 爱情 / 罗伯特·泽米吉斯 / 汤姆·汉克斯 罗宾·怀特",
                  "id": "1292720",
                  "genres": [
                      "剧情",
                      "爱情"
                  ],
                  "title": "阿甘正传",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "汤姆·汉克斯"
                      },
                      {
                          "name": "罗宾·怀特"
                      },
                      {
                          "name": "加里·西尼斯"
                      },
                      {
                          "name": "麦凯尔泰·威廉逊"
                      },
                      {
                          "name": "莎莉·菲尔德"
                      },
                      {
                          "name": "海利·乔·奥斯蒙"
                      },
                      {
                          "name": "迈克尔·康纳·亨弗里斯"
                      },
                      {
                          "name": "哈罗德·G·赫瑟姆"
                      },
                      {
                          "name": "山姆·安德森"
                      },
                      {
                          "name": "伊俄涅·M·特雷奇"
                      },
                      {
                          "name": "彼得·道博森"
                      },
                      {
                          "name": "希博汗·法隆"
                      },
                      {
                          "name": "伊丽莎白·汉克斯"
                      },
                      {
                          "name": "汉娜·豪尔"
                      },
                      {
                          "name": "克里斯托弗·琼斯"
                      },
                      {
                          "name": "罗布·兰德里"
                      },
                      {
                          "name": "杰森·麦克奎尔"
                      },
                      {
                          "name": "桑尼·施罗耶"
                      },
                      {
                          "name": "艾德·戴维斯"
                      },
                      {
                          "name": "丹尼尔C.斯瑞派克"
                      },
                      {
                          "name": "大卫·布里斯宾"
                      },
                      {
                          "name": "德博拉·麦克蒂尔"
                      },
                      {
                          "name": "艾尔·哈林顿"
                      },
                      {
                          "name": "阿非莫·奥米拉"
                      },
                      {
                          "name": "约翰·沃德斯塔德"
                      },
                      {
                          "name": "迈克尔·伯吉斯"
                      },
                      {
                          "name": "埃里克·安德伍德"
                      },
                      {
                          "name": "拜伦·明斯"
                      },
                      {
                          "name": "斯蒂芬·布吉格沃特"
                      },
                      {
                          "name": "约翰·威廉·高尔特"
                      },
                      {
                          "name": "希拉里·沙普兰"
                      },
                      {
                          "name": "伊莎贝尔·罗斯"
                      },
                      {
                          "name": "理查德·达历山德罗"
                      },
                      {
                          "name": "迪克·史迪威"
                      },
                      {
                          "name": "迈克尔-杰斯"
                      },
                      {
                          "name": "杰弗里·布莱克"
                      },
                      {
                          "name": "瓦妮莎·罗斯"
                      },
                      {
                          "name": "迪克·卡维特"
                      },
                      {
                          "name": "马拉·苏查雷特扎"
                      },
                      {
                          "name": "乔·阿拉斯奇"
                      },
                      {
                          "name": "W·本森·泰瑞"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "a53f6b",
                      "_base_color": [
                          0.9285714285714286,
                          0.6176470588235294,
                          0.13333333333333333
                      ],
                      "secondary_color": "f9f4f7",
                      "_avg_color": [
                          0.04166666666666652,
                          0.03636363636363636,
                          0.8627450980392157
                      ],
                      "primary_color_dark": "7f3052"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p2372307693.jpg",
                  "sharing_url": "https://movie.douban.com/subject/1292720/",
                  "url": "https://movie.douban.com/subject/1292720/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/1292720",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "罗伯特·泽米吉斯"
                      }
                  ],
                  "null_rating_reason": ""
              }
          ],
          "uri": "douban://douban.com/subject_collection/movie_top250?type=rank&category=movie&rank_type=top250",
          "updated_at": null,
          "covers": [
              "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p480747492.jpg",
              "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2561716440.jpg",
              "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2372307693.jpg"
          ],
          "name": "豆瓣电影 Top250",
          "icon_fg_image": "https://img1.doubanio.com/img/files/file-1543460329.png",
          "header_bg_image": "https://img3.doubanio.com/view/photo/photo/public/p456482220.jpg",
          "type_text": "",
          "rank": true,
          "type": "chart",
          "medium_name": "豆瓣 Top250",
          "total": 250,
          "background_color": "#E1A01A",
          "id": "movie_top250",
          "background_color_scheme": {
              "is_dark": true,
              "primary_color_light": "32323B",
              "secondary_color": "32323B",
              "primary_color_dark": "32323B"
          }
      },
      {
          "subtitle": "豆瓣榜单",
          "description": "每周三更新；关注榜单，第一时间了解最新华语口碑好剧。",
          "header_fg_image": "https://img9.doubanio.com/img/roboport/files/file-tv_chinese_best_weekly-big_cover.png?ts=1635316473.74",
          "url": "",
          "items": [
              {
                  "rating": {
                      "count": 37484,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 9.3
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2021-08-08(中国台湾)"
                  ],
                  "rank_value": 1,
                  "pic": {
                      "large": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2676295767.jpg",
                      "normal": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2676295767.jpg"
                  },
                  "is_show": false,
                  "year": "2021",
                  "card_subtitle": "2021 / 中国台湾 / 剧情 喜剧 / 陈长纶 严艺文 / 谢盈萱 吴以涵",
                  "id": "35215517",
                  "genres": [
                      "剧情",
                      "喜剧"
                  ],
                  "trend_down": false,
                  "title": "俗女养成记2",
                  "trend_equal": true,
                  "trend_up": false,
                  "is_released": true,
                  "rank_value_changed": 0,
                  "actors": [
                      {
                          "name": "谢盈萱"
                      },
                      {
                          "name": "吴以涵"
                      },
                      {
                          "name": "天心"
                      },
                      {
                          "name": "夏靖庭"
                      },
                      {
                          "name": "杨丽音"
                      },
                      {
                          "name": "陈竹昇"
                      },
                      {
                          "name": "于子育"
                      },
                      {
                          "name": "蓝苇华"
                      },
                      {
                          "name": "陈家逵"
                      },
                      {
                          "name": "杨铭威"
                      },
                      {
                          "name": "宋伟恩"
                      },
                      {
                          "name": "李国毅"
                      },
                      {
                          "name": "朱宥丞"
                      },
                      {
                          "name": "阙铭佑"
                      },
                      {
                          "name": "温升豪"
                      },
                      {
                          "name": "朱芷莹"
                      },
                      {
                          "name": "施名帅"
                      },
                      {
                          "name": "金美满"
                      },
                      {
                          "name": "林芷薰"
                      },
                      {
                          "name": "赵自强"
                      },
                      {
                          "name": "杨宸宥"
                      },
                      {
                          "name": "王宥谦"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "589aa5",
                      "_base_color": [
                          0.5245614035087719,
                          0.46798029556650245,
                          0.796078431372549
                      ],
                      "secondary_color": "f4f9f9",
                      "_avg_color": [
                          0.5196078431372549,
                          0.268421052631579,
                          0.7450980392156863
                      ],
                      "primary_color_dark": "43767f"
                  },
                  "type": "tv",
                  "has_linewatch": false,
                  "cover_url": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2676295767.jpg",
                  "sharing_url": "https://movie.douban.com/subject/35215517/",
                  "url": "https://movie.douban.com/subject/35215517/",
                  "release_date": null,
                  "uri": "douban://douban.com/tv/35215517",
                  "subtype": "tv",
                  "directors": [
                      {
                          "name": "陈长纶"
                      },
                      {
                          "name": "严艺文"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 38463,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 9.1
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2021-09-26(中国大陆)"
                  ],
                  "rank_value": 2,
                  "pic": {
                      "large": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p2689493412.jpg",
                      "normal": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2689493412.jpg"
                  },
                  "is_show": false,
                  "year": "2021",
                  "card_subtitle": "2021 / 中国大陆 / 剧情 传记 / 郑晓龙 毛卫宁 沈严 康洪雷 杨阳 林楠 杨文军 阎建钢 / 王雷 雷佳音",
                  "id": "34951103",
                  "genres": [
                      "剧情",
                      "传记"
                  ],
                  "trend_down": false,
                  "title": "功勋",
                  "trend_equal": true,
                  "trend_up": false,
                  "is_released": true,
                  "rank_value_changed": 0,
                  "actors": [
                      {
                          "name": "王雷"
                      },
                      {
                          "name": "雷佳音"
                      },
                      {
                          "name": "郭涛"
                      },
                      {
                          "name": "黄晓明"
                      },
                      {
                          "name": "蒋欣"
                      },
                      {
                          "name": "佟大为"
                      },
                      {
                          "name": "周迅"
                      },
                      {
                          "name": "黄志忠"
                      },
                      {
                          "name": "邵汶"
                      },
                      {
                          "name": "郝荣光"
                      },
                      {
                          "name": "鲁诺"
                      },
                      {
                          "name": "孙锡堃"
                      },
                      {
                          "name": "倪妮"
                      },
                      {
                          "name": "杨烁"
                      },
                      {
                          "name": "王骁"
                      },
                      {
                          "name": "是安"
                      },
                      {
                          "name": "田小洁"
                      },
                      {
                          "name": "柯宇"
                      },
                      {
                          "name": "李添诺"
                      },
                      {
                          "name": "尤勇智"
                      },
                      {
                          "name": "胡可"
                      },
                      {
                          "name": "李野萍"
                      },
                      {
                          "name": "白凡"
                      },
                      {
                          "name": "刚毅"
                      },
                      {
                          "name": "马佳玛尧"
                      },
                      {
                          "name": "孙茜"
                      },
                      {
                          "name": "丁勇岱"
                      },
                      {
                          "name": "娄乃鸣"
                      },
                      {
                          "name": "迟蓬"
                      },
                      {
                          "name": "罗京民"
                      },
                      {
                          "name": "刘小蕙"
                      },
                      {
                          "name": "德姬"
                      },
                      {
                          "name": "陈好"
                      },
                      {
                          "name": "章贺"
                      },
                      {
                          "name": "黄小蕾"
                      },
                      {
                          "name": "王洛勇"
                      },
                      {
                          "name": "宿宇杰"
                      },
                      {
                          "name": "管云鹏"
                      },
                      {
                          "name": "陈震"
                      },
                      {
                          "name": "夷永定"
                      },
                      {
                          "name": "王鑫"
                      },
                      {
                          "name": "张凯丽"
                      },
                      {
                          "name": "倪萍"
                      },
                      {
                          "name": "孟阿赛"
                      },
                      {
                          "name": "张洪杰"
                      },
                      {
                          "name": "左小青"
                      },
                      {
                          "name": "迟帅"
                      },
                      {
                          "name": "李光洁"
                      },
                      {
                          "name": "陈赫"
                      },
                      {
                          "name": "王菁华"
                      },
                      {
                          "name": "邢岷山"
                      },
                      {
                          "name": "刘宇宁"
                      },
                      {
                          "name": "菅纫姿"
                      },
                      {
                          "name": "孙俪"
                      },
                      {
                          "name": "刘奕君"
                      },
                      {
                          "name": "王自健"
                      },
                      {
                          "name": "王亚楠"
                      },
                      {
                          "name": "朱刚日尧"
                      },
                      {
                          "name": "张颂文"
                      },
                      {
                          "name": "陈宝国"
                      },
                      {
                          "name": "奚美娟"
                      },
                      {
                          "name": "于荣光"
                      },
                      {
                          "name": "董洁"
                      },
                      {
                          "name": "任重"
                      },
                      {
                          "name": "蒋梦婕"
                      },
                      {
                          "name": "柴隽哲"
                      },
                      {
                          "name": "威力斯"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "72603e",
                      "_base_color": [
                          0.10833333333333332,
                          0.4524886877828055,
                          0.8666666666666667
                      ],
                      "secondary_color": "f9f8f4",
                      "_avg_color": [
                          0.028112449799196786,
                          0.7345132743362831,
                          0.44313725490196076
                      ],
                      "primary_color_dark": "4c4029"
                  },
                  "type": "tv",
                  "has_linewatch": true,
                  "cover_url": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p2689493412.jpg",
                  "sharing_url": "https://movie.douban.com/subject/34951103/",
                  "url": "https://movie.douban.com/subject/34951103/",
                  "release_date": null,
                  "uri": "douban://douban.com/tv/34951103",
                  "subtype": "tv",
                  "directors": [
                      {
                          "name": "郑晓龙"
                      },
                      {
                          "name": "毛卫宁"
                      },
                      {
                          "name": "沈严"
                      },
                      {
                          "name": "康洪雷"
                      },
                      {
                          "name": "杨阳"
                      },
                      {
                          "name": "林楠"
                      },
                      {
                          "name": "杨文军"
                      },
                      {
                          "name": "阎建钢"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 5617,
                      "max": 10,
                      "star_count": 5,
                      "value": 9.5
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2021-08-21(中国香港)"
                  ],
                  "rank_value": 3,
                  "pic": {
                      "large": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2678041238.jpg",
                      "normal": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2678041238.jpg"
                  },
                  "is_show": false,
                  "year": "2021",
                  "card_subtitle": "2021 / 中国香港 / 纪录片 / 陈贝儿",
                  "id": "35574495",
                  "genres": [
                      "纪录片"
                  ],
                  "trend_down": false,
                  "title": "无穷之路",
                  "trend_equal": true,
                  "trend_up": false,
                  "is_released": true,
                  "rank_value_changed": 0,
                  "actors": [
                      {
                          "name": "陈贝儿"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "a5a07c",
                      "_base_color": [
                          0.14516129032258066,
                          0.24603174603174605,
                          0.49411764705882355
                      ],
                      "secondary_color": "f9f9f4",
                      "_avg_color": [
                          0.1410256410256411,
                          0.1870503597122302,
                          0.5450980392156862
                      ],
                      "primary_color_dark": "7f7b60"
                  },
                  "type": "tv",
                  "has_linewatch": true,
                  "cover_url": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2678041238.jpg",
                  "sharing_url": "https://movie.douban.com/subject/35574495/",
                  "url": "https://movie.douban.com/subject/35574495/",
                  "release_date": null,
                  "uri": "douban://douban.com/tv/35574495",
                  "subtype": "tv",
                  "directors": [],
                  "null_rating_reason": ""
              }
          ],
          "uri": "douban://douban.com/subject_collection/tv_chinese_best_weekly?type=rank&category=movie&rank_type=weekly",
          "updated_at": "2021-10-20 16:20:15",
          "covers": [
              "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2676295767.jpg",
              "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2689493412.jpg",
              "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2678041238.jpg"
          ],
          "name": "华语口碑剧集榜",
          "icon_fg_image": null,
          "header_bg_image": "https://img1.doubanio.com/view/photo/photo/public/p2675871537.jpg",
          "type_text": "豆瓣周榜",
          "cover_url": "https://img1.doubanio.com/dae/screenshot/image/html/786fd597382d5957.jpg?window_size=300,300&format=png",
          "medium_name": "华语口碑剧集",
          "total": 10,
          "type": "chart",
          "id": "tv_chinese_best_weekly",
          "background_color_scheme": {
              "is_dark": true,
              "primary_color_light": "707242",
              "secondary_color": "f9f9f4",
              "primary_color_dark": "4a4c2c"
          }
      },
      {
          "subtitle": "豆瓣榜单",
          "description": "每周三更新；关注榜单，第一时间了解最新全球口碑好剧。",
          "header_fg_image": "https://img9.doubanio.com/img/roboport/files/file-tv_global_best_weekly-big_cover.png?ts=1635316423.14",
          "url": "",
          "items": [
              {
                  "rating": {
                      "count": 39699,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 8.8
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2021-08-28(韩国)"
                  ],
                  "rank_value": 1,
                  "pic": {
                      "large": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2675934255.jpg",
                      "normal": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2675934255.jpg"
                  },
                  "is_show": false,
                  "year": "2021",
                  "card_subtitle": "2021 / 韩国 / 剧情 爱情 / 柳济元 / 申敏儿 金宣虎",
                  "id": "35296153",
                  "genres": [
                      "剧情",
                      "爱情"
                  ],
                  "trend_down": false,
                  "title": "海岸村恰恰恰",
                  "trend_equal": false,
                  "trend_up": true,
                  "is_released": true,
                  "rank_value_changed": 2,
                  "actors": [
                      {
                          "name": "申敏儿"
                      },
                      {
                          "name": "金宣虎"
                      },
                      {
                          "name": "李相二"
                      },
                      {
                          "name": "金英玉"
                      },
                      {
                          "name": "赵汉哲"
                      },
                      {
                          "name": "孔敏晶"
                      },
                      {
                          "name": "李凤莲"
                      },
                      {
                          "name": "印乔镇"
                      },
                      {
                          "name": "车清华"
                      },
                      {
                          "name": "姜亨硕"
                      },
                      {
                          "name": "李容怡"
                      },
                      {
                          "name": "申仙爱"
                      },
                      {
                          "name": "尹硕贤"
                      },
                      {
                          "name": "金周妍"
                      },
                      {
                          "name": "洪智熙"
                      },
                      {
                          "name": "金成范"
                      },
                      {
                          "name": "徐尚沅"
                      },
                      {
                          "name": "禹美华"
                      },
                      {
                          "name": "朴艺荣"
                      },
                      {
                          "name": "李世亨"
                      },
                      {
                          "name": "金敏瑞"
                      },
                      {
                          "name": "奇恩侑"
                      },
                      {
                          "name": "高度妍"
                      },
                      {
                          "name": "边胜泰"
                      },
                      {
                          "name": "金贤佑"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "a58050",
                      "_base_color": [
                          0.09444444444444446,
                          0.5172413793103449,
                          0.22745098039215686
                      ],
                      "secondary_color": "f9f7f4",
                      "_avg_color": [
                          0.08602150537634412,
                          0.3179487179487179,
                          0.7647058823529411
                      ],
                      "primary_color_dark": "7f623d"
                  },
                  "type": "tv",
                  "has_linewatch": false,
                  "cover_url": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2675934255.jpg",
                  "sharing_url": "https://movie.douban.com/subject/35296153/",
                  "url": "https://movie.douban.com/subject/35296153/",
                  "release_date": null,
                  "uri": "douban://douban.com/tv/35296153",
                  "subtype": "tv",
                  "directors": [
                      {
                          "name": "柳济元"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 5281,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 9
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2021-10-15(日本)"
                  ],
                  "rank_value": 2,
                  "pic": {
                      "large": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2698432495.jpg",
                      "normal": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2698432495.jpg"
                  },
                  "is_show": false,
                  "year": "2021",
                  "card_subtitle": "2021 / 日本 / 爱情 犯罪 悬疑 / 冢原亚由子 / 吉高由里子 松下洸平",
                  "id": "35528931",
                  "genres": [
                      "爱情",
                      "犯罪",
                      "悬疑"
                  ],
                  "trend_down": false,
                  "title": "最爱",
                  "trend_equal": false,
                  "trend_up": true,
                  "is_released": true,
                  "rank_value_changed": 9,
                  "actors": [
                      {
                          "name": "吉高由里子"
                      },
                      {
                          "name": "松下洸平"
                      },
                      {
                          "name": "井浦新"
                      },
                      {
                          "name": "药师丸博子"
                      },
                      {
                          "name": "光石研"
                      },
                      {
                          "name": "及川光博"
                      },
                      {
                          "name": "田中美奈实"
                      },
                      {
                          "name": "佐久间由衣"
                      },
                      {
                          "name": "高桥文哉"
                      },
                      {
                          "name": "奥野瑛太"
                      },
                      {
                          "name": "酒向芳"
                      },
                      {
                          "name": "津田健次郎"
                      },
                      {
                          "name": "冈山天音"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "a5a5a5",
                      "_base_color": [
                          0,
                          0,
                          0.9058823529411765
                      ],
                      "secondary_color": "f9f4f4",
                      "_avg_color": [
                          0.8333333333333334,
                          0.004999999999999982,
                          0.7843137254901961
                      ],
                      "primary_color_dark": "7f7f7f"
                  },
                  "type": "tv",
                  "has_linewatch": false,
                  "cover_url": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2698432495.jpg",
                  "sharing_url": "https://movie.douban.com/subject/35528931/",
                  "url": "https://movie.douban.com/subject/35528931/",
                  "release_date": null,
                  "uri": "douban://douban.com/tv/35528931",
                  "subtype": "tv",
                  "directors": [
                      {
                          "name": "冢原亚由子"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 5078,
                      "max": 10,
                      "star_count": 5,
                      "value": 9.6
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2021-09-16(英国)"
                  ],
                  "rank_value": 3,
                  "pic": {
                      "large": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2684224665.jpg",
                      "normal": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2684224665.jpg"
                  },
                  "is_show": false,
                  "year": "2021",
                  "card_subtitle": "2021 / 英国 美国 / 剧情 喜剧 / 布莱恩·派西维尔 萨莎·兰塞姆 / 尼古拉斯·瑞夫 瑞秋·申顿",
                  "id": "35274831",
                  "genres": [
                      "剧情",
                      "喜剧"
                  ],
                  "trend_down": true,
                  "title": "万物生灵 第二季",
                  "trend_equal": false,
                  "trend_up": false,
                  "is_released": true,
                  "rank_value_changed": 2,
                  "actors": [
                      {
                          "name": "尼古拉斯·瑞夫"
                      },
                      {
                          "name": "瑞秋·申顿"
                      },
                      {
                          "name": "卡勒姆·伍德豪斯"
                      },
                      {
                          "name": "萨缪尔·韦斯特"
                      },
                      {
                          "name": "安娜·梅德利"
                      },
                      {
                          "name": "菲利普·希尔·皮尔逊"
                      },
                      {
                          "name": "尤安·迈克纳顿"
                      },
                      {
                          "name": "朱恩·沃森"
                      },
                      {
                          "name": "托尼·皮茨"
                      },
                      {
                          "name": "Imogen Clawson"
                      },
                      {
                          "name": "Gabriel Quigley"
                      },
                      {
                          "name": "Drew Cain"
                      },
                      {
                          "name": "Seumas MacKinnon"
                      },
                      {
                          "name": "Heather Horsman"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "5d5972",
                      "_base_color": [
                          0.6923076923076924,
                          0.21666666666666662,
                          0.23529411764705882
                      ],
                      "secondary_color": "f5f4f9",
                      "_avg_color": [
                          0.0729166666666667,
                          0.13675213675213677,
                          0.4588235294117647
                      ],
                      "primary_color_dark": "3e3b4c"
                  },
                  "type": "tv",
                  "has_linewatch": false,
                  "cover_url": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2684224665.jpg",
                  "sharing_url": "https://movie.douban.com/subject/35274831/",
                  "url": "https://movie.douban.com/subject/35274831/",
                  "release_date": null,
                  "uri": "douban://douban.com/tv/35274831",
                  "subtype": "tv",
                  "directors": [
                      {
                          "name": "布莱恩·派西维尔"
                      },
                      {
                          "name": "萨莎·兰塞姆"
                      }
                  ],
                  "null_rating_reason": ""
              }
          ],
          "uri": "douban://douban.com/subject_collection/tv_global_best_weekly?type=rank&category=movie&rank_type=weekly",
          "updated_at": "2021-10-20 16:30:19",
          "covers": [
              "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2675934255.jpg",
              "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2698432495.jpg",
              "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2684224665.jpg"
          ],
          "name": "全球口碑剧集榜",
          "icon_fg_image": null,
          "header_bg_image": "https://img1.doubanio.com/view/photo/photo/public/p2675418577.jpg",
          "type_text": "豆瓣周榜",
          "cover_url": "https://img2.doubanio.com/dae/screenshot/image/html/3441a3c3b799c183.jpg?window_size=300,300&format=png",
          "medium_name": "全球口碑剧集",
          "total": 10,
          "type": "chart",
          "id": "tv_global_best_weekly",
          "background_color_scheme": {
              "is_dark": true,
              "primary_color_light": "6f6672",
              "secondary_color": "f8f4f9",
              "primary_color_dark": "4a444c"
          }
      },
      {
          "subtitle": "豆瓣榜单",
          "description": "",
          "url": "",
          "items": [
              {
                  "rating": {
                      "count": 1658344,
                      "max": 10,
                      "star_count": 4,
                      "value": 8.4
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2019-07-26(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2563780504.jpg",
                      "normal": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2563780504.jpg"
                  },
                  "is_show": false,
                  "year": "2019",
                  "card_subtitle": "2019 / 中国大陆 / 剧情 喜剧 动画 / 饺子 / 吕艳婷 囧森瑟夫",
                  "id": "26794435",
                  "genres": [
                      "剧情",
                      "喜剧",
                      "动画"
                  ],
                  "title": "哪吒之魔童降世",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "吕艳婷"
                      },
                      {
                          "name": "囧森瑟夫"
                      },
                      {
                          "name": "瀚墨"
                      },
                      {
                          "name": "陈浩"
                      },
                      {
                          "name": "绿绮"
                      },
                      {
                          "name": "张珈铭"
                      },
                      {
                          "name": "杨卫"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "a51a0e",
                      "_base_color": [
                          0.013274336283185842,
                          0.9112903225806451,
                          0.48627450980392156
                      ],
                      "secondary_color": "f9f5f4",
                      "_avg_color": [
                          0.02419354838709679,
                          0.8551724137931035,
                          0.5686274509803921
                      ],
                      "primary_color_dark": "7f140b"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2563780504.jpg",
                  "sharing_url": "https://movie.douban.com/subject/26794435/",
                  "url": "https://movie.douban.com/subject/26794435/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/26794435",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "饺子"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 1314945,
                      "max": 10,
                      "star_count": 4,
                      "value": 8.2
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2019-10-25(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p2572166063.jpg",
                      "normal": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2572166063.jpg"
                  },
                  "is_show": false,
                  "year": "2019",
                  "card_subtitle": "2019 / 中国大陆 中国香港 / 剧情 爱情 犯罪 / 曾国祥 / 周冬雨 易烊千玺",
                  "id": "30166972",
                  "genres": [
                      "剧情",
                      "爱情",
                      "犯罪"
                  ],
                  "title": "少年的你",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "周冬雨"
                      },
                      {
                          "name": "易烊千玺"
                      },
                      {
                          "name": "尹昉"
                      },
                      {
                          "name": "周也"
                      },
                      {
                          "name": "吴越"
                      },
                      {
                          "name": "黄觉"
                      },
                      {
                          "name": "张艺凡"
                      },
                      {
                          "name": "张耀"
                      },
                      {
                          "name": "张歆怡"
                      },
                      {
                          "name": "赵润南"
                      },
                      {
                          "name": "郜玄铭"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "4a6f72",
                      "_base_color": [
                          0.5144927536231885,
                          0.3484848484848485,
                          0.25882352941176473
                      ],
                      "secondary_color": "f4f9f9",
                      "_avg_color": [
                          0.4761904761904761,
                          0.13592233009708743,
                          0.403921568627451
                      ],
                      "primary_color_dark": "314a4c"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p2572166063.jpg",
                  "sharing_url": "https://movie.douban.com/subject/30166972/",
                  "url": "https://movie.douban.com/subject/30166972/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/30166972",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "曾国祥"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 337101,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 8.6
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2018-11-02(中国台湾)"
                  ],
                  "pic": {
                      "large": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p2546961193.jpg",
                      "normal": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2546961193.jpg"
                  },
                  "is_show": false,
                  "year": "2018",
                  "card_subtitle": "2018 / 中国台湾 / 剧情 喜剧 同性 / 徐誉庭 许智彦 / 邱泽 谢盈萱",
                  "id": "27119586",
                  "genres": [
                      "剧情",
                      "喜剧",
                      "同性"
                  ],
                  "title": "谁先爱上他的",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "邱泽"
                      },
                      {
                          "name": "谢盈萱"
                      },
                      {
                          "name": "陈如山"
                      },
                      {
                          "name": "黄圣球"
                      },
                      {
                          "name": "周洺甫"
                      },
                      {
                          "name": "梁正群"
                      },
                      {
                          "name": "杨丽音"
                      },
                      {
                          "name": "安哲"
                      },
                      {
                          "name": "高隽雅"
                      },
                      {
                          "name": "吴定谦"
                      },
                      {
                          "name": "禾语辰"
                      },
                      {
                          "name": "钟欣凌"
                      },
                      {
                          "name": "万芳"
                      },
                      {
                          "name": "高爱伦"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "0f76a5",
                      "_base_color": [
                          0.5525793650793651,
                          0.9081081081081082,
                          0.7254901960784313
                      ],
                      "secondary_color": "f4f8f9",
                      "_avg_color": [
                          0.5373563218390806,
                          0.3647798742138365,
                          0.6235294117647059
                      ],
                      "primary_color_dark": "0b5a7f"
                  },
                  "type": "movie",
                  "has_linewatch": false,
                  "cover_url": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p2546961193.jpg",
                  "sharing_url": "https://movie.douban.com/subject/27119586/",
                  "url": "https://movie.douban.com/subject/27119586/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/27119586",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "徐誉庭"
                      },
                      {
                          "name": "许智彦"
                      }
                  ],
                  "null_rating_reason": ""
              }
          ],
          "uri": "douban://douban.com/subject_collection/ECFYHQBWQ?type=rank&category=movie&rank_type=year",
          "updated_at": null,
          "covers": [
              "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2563780504.jpg",
              "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2572166063.jpg",
              "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2546961193.jpg"
          ],
          "name": "2019评分最高华语电影",
          "icon_fg_image": null,
          "header_bg_image": "https://img2.doubanio.com/view/photo/photo/public/p2563815623.jpg",
          "type_text": "2019高分榜",
          "cover_url": "https://img9.doubanio.com/dae/screenshot/image/html/90f756ab998f2714.jpg?window_size=300,300&format=png",
          "medium_name": "评分最高华语电影",
          "total": 10,
          "type": "chart",
          "id": "ECFYHQBWQ",
          "background_color_scheme": {
              "is_dark": true,
              "primary_color_light": "526672",
              "secondary_color": "f4f7f9",
              "primary_color_dark": "36444c"
          }
      },
      {
          "subtitle": "豆瓣榜单",
          "description": "",
          "url": "",
          "items": [
              {
                  "rating": {
                      "count": 877550,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 9.1
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2019-04-29(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2555295759.jpg",
                      "normal": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2555295759.jpg"
                  },
                  "is_show": false,
                  "year": "2018",
                  "card_subtitle": "2018 / 黎巴嫩 美国 法国 塞浦路斯 卡塔尔 英国 / 剧情 / 娜丁·拉巴基 / 赞恩·阿尔·拉菲亚 约丹诺斯·希费罗",
                  "id": "30170448",
                  "genres": [
                      "剧情"
                  ],
                  "title": "何以为家",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "赞恩·阿尔·拉菲亚"
                      },
                      {
                          "name": "约丹诺斯·希费罗"
                      },
                      {
                          "name": "博鲁瓦蒂夫·特雷杰·班科尔"
                      },
                      {
                          "name": "卡萨尔·艾尔·哈达德"
                      },
                      {
                          "name": "法迪·尤瑟夫"
                      },
                      {
                          "name": "海塔·塞德拉·伊扎姆"
                      },
                      {
                          "name": "阿拉·乔什涅"
                      },
                      {
                          "name": "娜丁·拉巴基"
                      },
                      {
                          "name": "埃利亚斯·库利"
                      },
                      {
                          "name": "努尔·艾尔·侯赛尼"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "a56f47",
                      "_base_color": [
                          0.07017543859649124,
                          0.5671641791044777,
                          0.5254901960784314
                      ],
                      "secondary_color": "f9f7f4",
                      "_avg_color": [
                          0.0666666666666667,
                          0.4482758620689655,
                          0.5686274509803921
                      ],
                      "primary_color_dark": "7f5537"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2555295759.jpg",
                  "sharing_url": "https://movie.douban.com/subject/30170448/",
                  "url": "https://movie.douban.com/subject/30170448/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/30170448",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "娜丁·拉巴基"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 1348594,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 8.9
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2019-03-01(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p2549177902.jpg",
                      "normal": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2549177902.jpg"
                  },
                  "is_show": false,
                  "year": "2018",
                  "card_subtitle": "2018 / 美国 中国大陆 / 剧情 喜剧 传记 / 彼得·法雷里 / 维果·莫腾森 马赫沙拉·阿里",
                  "id": "27060077",
                  "genres": [
                      "剧情",
                      "喜剧",
                      "传记"
                  ],
                  "title": "绿皮书",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "维果·莫腾森"
                      },
                      {
                          "name": "马赫沙拉·阿里"
                      },
                      {
                          "name": "琳达·卡德里尼"
                      },
                      {
                          "name": "塞巴斯蒂安·马尼斯科"
                      },
                      {
                          "name": "迪米特·D·马里诺夫"
                      },
                      {
                          "name": "迈克·哈顿"
                      },
                      {
                          "name": "P·J·伯恩"
                      },
                      {
                          "name": "乔·柯蒂斯"
                      },
                      {
                          "name": "玛姬·尼克松"
                      },
                      {
                          "name": "冯·刘易斯"
                      },
                      {
                          "name": "乔恩·索特兰"
                      },
                      {
                          "name": "唐·斯达克"
                      },
                      {
                          "name": "安东尼·曼加诺"
                      },
                      {
                          "name": "保罗·斯隆"
                      },
                      {
                          "name": "珍娜·劳伦索"
                      },
                      {
                          "name": "肯尼斯·以色列"
                      },
                      {
                          "name": "伊克博·塞巴"
                      },
                      {
                          "name": "尼克·瓦莱隆加"
                      },
                      {
                          "name": "大卫·安"
                      },
                      {
                          "name": "迈克·切罗内"
                      },
                      {
                          "name": "杰拉尔丁·辛格"
                      },
                      {
                          "name": "马丁·巴特斯·布拉德福德"
                      },
                      {
                          "name": "格拉伦·布莱恩特·班克斯"
                      },
                      {
                          "name": "汤姆·维图"
                      },
                      {
                          "name": "夏恩·帕特洛"
                      },
                      {
                          "name": "丹尼斯·W·霍尔"
                      },
                      {
                          "name": "吉姆·克洛克"
                      },
                      {
                          "name": "戴恩·罗兹"
                      },
                      {
                          "name": "布赖恩·斯特帕尼克"
                      },
                      {
                          "name": "乔恩·迈克尔·戴维斯"
                      },
                      {
                          "name": "布莱恩·库瑞"
                      },
                      {
                          "name": "托尼亚·马尔多纳多"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "1494a5",
                      "_base_color": [
                          0.5203836930455635,
                          0.8742138364779876,
                          0.6235294117647059
                      ],
                      "secondary_color": "f4f9f9",
                      "_avg_color": [
                          0.5144927536231885,
                          0.5380116959064327,
                          0.6705882352941176
                      ],
                      "primary_color_dark": "10717f"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p2549177902.jpg",
                  "sharing_url": "https://movie.douban.com/subject/27060077/",
                  "url": "https://movie.douban.com/subject/27060077/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/27060077",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "彼得·法雷里"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 852563,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 8.7
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2019-08-31(威尼斯电影节)"
                  ],
                  "pic": {
                      "large": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2567198874.jpg",
                      "normal": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2567198874.jpg"
                  },
                  "is_show": false,
                  "year": "2019",
                  "card_subtitle": "2019 / 美国 加拿大 / 剧情 犯罪 惊悚 / 托德·菲利普斯 / 华金·菲尼克斯 罗伯特·德尼罗",
                  "id": "27119724",
                  "genres": [
                      "剧情",
                      "犯罪",
                      "惊悚"
                  ],
                  "title": "小丑",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "华金·菲尼克斯"
                      },
                      {
                          "name": "罗伯特·德尼罗"
                      },
                      {
                          "name": "马克·马龙"
                      },
                      {
                          "name": "莎姬·贝兹"
                      },
                      {
                          "name": "谢伊·惠格姆"
                      },
                      {
                          "name": "弗兰西丝·康罗伊"
                      },
                      {
                          "name": "布莱恩·考伦"
                      },
                      {
                          "name": "布莱恩·泰里·亨利"
                      },
                      {
                          "name": "布莱特·卡伦"
                      },
                      {
                          "name": "道格拉斯·霍奇斯"
                      },
                      {
                          "name": "格伦·弗莱舍尔"
                      },
                      {
                          "name": "比尔·坎普"
                      },
                      {
                          "name": "乔什·帕斯"
                      },
                      {
                          "name": "但丁·佩雷拉-奥尔森"
                      },
                      {
                          "name": "玛丽·凯特·马拉特"
                      },
                      {
                          "name": "迈克尔·本茨"
                      },
                      {
                          "name": "莎珑·华盛顿"
                      },
                      {
                          "name": "桑德拉·詹姆斯"
                      },
                      {
                          "name": "托尼·赫德"
                      },
                      {
                          "name": "曼德拉·贝拉米"
                      },
                      {
                          "name": "乔·奥克曼"
                      },
                      {
                          "name": "卡尔·伦德施泰特"
                      },
                      {
                          "name": "米克·奥罗克"
                      },
                      {
                          "name": "大卫·吉布森"
                      },
                      {
                          "name": "伊万·罗萨多"
                      },
                      {
                          "name": "安妮·比萨比亚"
                      },
                      {
                          "name": "布莱斯·科里根"
                      },
                      {
                          "name": "乔恩·道格拉斯·雷尼"
                      },
                      {
                          "name": "艾恩斯利·丹恩"
                      },
                      {
                          "name": "杰森·约翰·奇卡莱塞"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "725c4d",
                      "_base_color": [
                          0.06666666666666667,
                          0.32786885245901637,
                          0.23921568627450981
                      ],
                      "secondary_color": "f9f6f4",
                      "_avg_color": [
                          0.09722222222222217,
                          0.22641509433962262,
                          0.41568627450980394
                      ],
                      "primary_color_dark": "4c3d33"
                  },
                  "type": "movie",
                  "has_linewatch": false,
                  "cover_url": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2567198874.jpg",
                  "sharing_url": "https://movie.douban.com/subject/27119724/",
                  "url": "https://movie.douban.com/subject/27119724/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/27119724",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "托德·菲利普斯"
                      }
                  ],
                  "null_rating_reason": ""
              }
          ],
          "uri": "douban://douban.com/subject_collection/ECFQHXCTQ?type=rank&category=movie&rank_type=year",
          "updated_at": null,
          "covers": [
              "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2555295759.jpg",
              "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2549177902.jpg",
              "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2567198874.jpg"
          ],
          "name": "2019评分最高外语电影",
          "icon_fg_image": null,
          "header_bg_image": "https://img2.doubanio.com/view/photo/photo/public/p2554897263.jpg",
          "type_text": "2019高分榜",
          "cover_url": "https://img1.doubanio.com/dae/screenshot/image/html/107c5b3301b43109.jpg?window_size=300,300&format=png",
          "medium_name": "评分最高外语电影",
          "total": 10,
          "type": "chart",
          "id": "ECFQHXCTQ",
          "background_color_scheme": {
              "is_dark": true,
              "primary_color_light": "726d72",
              "secondary_color": "f9f4f9",
              "primary_color_dark": "4c484c"
          }
      },
      {
          "subtitle": "豆瓣榜单",
          "description": "",
          "url": "",
          "items": [
              {
                  "rating": {
                      "count": 230157,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 8.8
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2019-09-27(纽约电影节)"
                  ],
                  "pic": {
                      "large": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2568902055.jpg",
                      "normal": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2568902055.jpg"
                  },
                  "is_show": false,
                  "year": "2019",
                  "card_subtitle": "2019 / 美国 / 剧情 传记 犯罪 / 马丁·斯科塞斯 / 罗伯特·德尼罗 阿尔·帕西诺",
                  "id": "6981153",
                  "genres": [
                      "剧情",
                      "传记",
                      "犯罪"
                  ],
                  "title": "爱尔兰人",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "罗伯特·德尼罗"
                      },
                      {
                          "name": "阿尔·帕西诺"
                      },
                      {
                          "name": "乔·佩西"
                      },
                      {
                          "name": "安娜·帕奎因"
                      },
                      {
                          "name": "杰西·普莱蒙"
                      },
                      {
                          "name": "哈威·凯特尔"
                      },
                      {
                          "name": "斯蒂芬·格拉汉姆"
                      },
                      {
                          "name": "鲍比·坎纳瓦尔"
                      },
                      {
                          "name": "杰克·休斯顿"
                      },
                      {
                          "name": "阿莱卡萨·帕拉迪诺"
                      },
                      {
                          "name": "凯瑟琳·纳杜奇"
                      },
                      {
                          "name": "多米尼克·隆巴多兹"
                      },
                      {
                          "name": "雷·罗马诺"
                      },
                      {
                          "name": "塞巴斯蒂安·马尼斯科"
                      },
                      {
                          "name": "杰克·霍夫曼"
                      },
                      {
                          "name": "保罗·本-维克托"
                      },
                      {
                          "name": "斯蒂芬妮·库尔特祖巴"
                      },
                      {
                          "name": "莎伦·菲弗"
                      },
                      {
                          "name": "路易斯·坎瑟米"
                      },
                      {
                          "name": "茵迪亚·恩能加"
                      },
                      {
                          "name": "J.C.麦肯泽"
                      },
                      {
                          "name": "巴里·普赖默斯"
                      },
                      {
                          "name": "吉姆·诺顿"
                      },
                      {
                          "name": "盖里·巴萨拉巴"
                      },
                      {
                          "name": "玛格丽特·安妮·佛罗伦斯"
                      },
                      {
                          "name": "约翰·斯库蒂"
                      },
                      {
                          "name": "约翰·塞纳迭姆博"
                      },
                      {
                          "name": "大卫·阿隆·贝克"
                      },
                      {
                          "name": "桃乐丝·麦卡锡"
                      },
                      {
                          "name": "凯文·凯恩"
                      },
                      {
                          "name": "加里·帕斯托雷"
                      },
                      {
                          "name": "约瑟夫·罗素"
                      },
                      {
                          "name": "凯文·奥罗克"
                      },
                      {
                          "name": "娜塔莎·罗曼诺娃"
                      },
                      {
                          "name": "杰里米·卢克"
                      },
                      {
                          "name": "凯莉·P·威廉姆斯"
                      },
                      {
                          "name": "詹妮弗·马奇"
                      },
                      {
                          "name": "保罗·鲍格才"
                      },
                      {
                          "name": "蒂姆·聂夫"
                      },
                      {
                          "name": "斯蒂芬·梅尔勒"
                      },
                      {
                          "name": "克雷格·文森特"
                      },
                      {
                          "name": "比利·史密斯"
                      },
                      {
                          "name": "布莱斯·科里根"
                      },
                      {
                          "name": "斯泰西·爱丽丝·科恩"
                      },
                      {
                          "name": "吉诺·卡法雷利"
                      },
                      {
                          "name": "拉里·罗曼诺"
                      },
                      {
                          "name": "罗伯特·富纳罗"
                      },
                      {
                          "name": "维罗妮卡·阿利奇诺"
                      },
                      {
                          "name": "克劳黛特·拉利"
                      },
                      {
                          "name": "詹姆斯·洛林兹"
                      },
                      {
                          "name": "阿什莉·诺斯"
                      },
                      {
                          "name": "肯·斯拉迪克"
                      },
                      {
                          "name": "帕特里克·加洛"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "566172",
                      "_base_color": [
                          0.6025641025641026,
                          0.24999999999999994,
                          0.20392156862745098
                      ],
                      "secondary_color": "f4f6f9",
                      "_avg_color": [
                          0.6481481481481483,
                          0.1363636363636364,
                          0.25882352941176473
                      ],
                      "primary_color_dark": "39404c"
                  },
                  "type": "movie",
                  "has_linewatch": false,
                  "cover_url": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2568902055.jpg",
                  "sharing_url": "https://movie.douban.com/subject/6981153/",
                  "url": "https://movie.douban.com/subject/6981153/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/6981153",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "马丁·斯科塞斯"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 275564,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 8.6
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2020-05-20(中国大陆网络)"
                  ],
                  "pic": {
                      "large": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2571760178.jpg",
                      "normal": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2571760178.jpg"
                  },
                  "is_show": false,
                  "year": "2019",
                  "card_subtitle": "2019 / 英国 美国 / 剧情 爱情 / 诺亚·鲍姆巴赫 / 斯嘉丽·约翰逊 亚当·德赖弗",
                  "id": "27202818",
                  "genres": [
                      "剧情",
                      "爱情"
                  ],
                  "title": "婚姻故事",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "斯嘉丽·约翰逊"
                      },
                      {
                          "name": "亚当·德赖弗"
                      },
                      {
                          "name": "劳拉·邓恩"
                      },
                      {
                          "name": "艾奇·罗伯逊"
                      },
                      {
                          "name": "梅里特·韦弗"
                      },
                      {
                          "name": "阿伦·阿尔达"
                      },
                      {
                          "name": "朱丽·哈基提"
                      },
                      {
                          "name": "雷·利奥塔"
                      },
                      {
                          "name": "马克·奥布莱恩"
                      },
                      {
                          "name": "华莱士·肖恩"
                      },
                      {
                          "name": "凯尔·柏海莫"
                      },
                      {
                          "name": "米奇·萨姆纳"
                      },
                      {
                          "name": "马修·马希尔"
                      },
                      {
                          "name": "罗伯特·斯密戈尔"
                      },
                      {
                          "name": "艾登·梅耶里"
                      },
                      {
                          "name": "布洛克·布罗姆"
                      },
                      {
                          "name": "玛莎·凯莉"
                      },
                      {
                          "name": "阿尔伯特·琼斯"
                      },
                      {
                          "name": "汉娜·邓恩"
                      },
                      {
                          "name": "桑德拉·罗斯科"
                      },
                      {
                          "name": "麦金利·贝尔彻三世"
                      },
                      {
                          "name": "戈登·格里克"
                      },
                      {
                          "name": "马修·希尔"
                      },
                      {
                          "name": "阿米尔·塔莱"
                      },
                      {
                          "name": "萨拉·琼斯"
                      },
                      {
                          "name": "文尼·希伯"
                      },
                      {
                          "name": "胡安·阿方索"
                      },
                      {
                          "name": "洛蕾塔·谢诺斯基"
                      },
                      {
                          "name": "滕德·艾德比佩"
                      },
                      {
                          "name": "贾思敏·赛法斯·琼斯"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "a5593f",
                      "_base_color": [
                          0.041666666666666664,
                          0.6153846153846154,
                          0.15294117647058825
                      ],
                      "secondary_color": "f9f6f4",
                      "_avg_color": [
                          0.06910569105691056,
                          0.28671328671328666,
                          0.5607843137254902
                      ],
                      "primary_color_dark": "7f4431"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2571760178.jpg",
                  "sharing_url": "https://movie.douban.com/subject/27202818/",
                  "url": "https://movie.douban.com/subject/27202818/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/27202818",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "诺亚·鲍姆巴赫"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 55064,
                      "max": 10,
                      "star_count": 4,
                      "value": 7.5
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2020-09-18(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2620256769.jpg",
                      "normal": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2620256769.jpg"
                  },
                  "is_show": false,
                  "year": "2018",
                  "card_subtitle": "2018 / 意大利 / 剧情 犯罪 悬疑 / 斯蒂法诺·摩尔蒂尼 / 里卡多·斯卡马乔 米丽娅姆·莱昂内",
                  "id": "30384019",
                  "genres": [
                      "剧情",
                      "犯罪",
                      "悬疑"
                  ],
                  "title": "死无对证",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "里卡多·斯卡马乔"
                      },
                      {
                          "name": "米丽娅姆·莱昂内"
                      },
                      {
                          "name": "马丽娅·派雅托"
                      },
                      {
                          "name": "法布里齐奥·本蒂沃利奥"
                      },
                      {
                          "name": "萨拉·卡迪纳莱蒂"
                      },
                      {
                          "name": "尼古拉·潘内利"
                      },
                      {
                          "name": "塞尔吉奥·罗马诺"
                      },
                      {
                          "name": "阿斯卡尼奥·巴尔博"
                      },
                      {
                          "name": "葆拉桑博"
                      },
                      {
                          "name": "格拉多德布拉西奥"
                      },
                      {
                          "name": "亚历山德拉·卡里略"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "414b72",
                      "_base_color": [
                          0.6319444444444443,
                          0.42857142857142855,
                          0.2196078431372549
                      ],
                      "secondary_color": "f4f5f9",
                      "_avg_color": [
                          0.6428571428571428,
                          0.3043478260869565,
                          0.27058823529411763
                      ],
                      "primary_color_dark": "2b324c"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2620256769.jpg",
                  "sharing_url": "https://movie.douban.com/subject/30384019/",
                  "url": "https://movie.douban.com/subject/30384019/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/30384019",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "斯蒂法诺·摩尔蒂尼"
                      }
                  ],
                  "null_rating_reason": ""
              }
          ],
          "uri": "douban://douban.com/subject_collection/ECOUHS3TY?type=rank&category=movie&rank_type=year",
          "updated_at": null,
          "covers": [
              "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2568902055.jpg",
              "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2571760178.jpg",
              "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2620256769.jpg"
          ],
          "name": "2019年度冷门佳片",
          "icon_fg_image": null,
          "header_bg_image": "https://img3.doubanio.com/view/photo/photo/public/p2566085820.jpg",
          "type_text": "2019高分榜",
          "cover_url": "https://img2.doubanio.com/dae/screenshot/image/html/aee6667d88e4f9d2.jpg?window_size=300,300&format=png",
          "medium_name": "年度冷门佳片",
          "total": 10,
          "type": "chart",
          "id": "ECOUHS3TY",
          "background_color_scheme": {
              "is_dark": true,
              "primary_color_light": "726c6f",
              "secondary_color": "f9f4f7",
              "primary_color_dark": "4c484a"
          }
      },
      {
          "subtitle": "豆瓣榜单",
          "description": "",
          "header_fg_image": "https://img9.doubanio.com/img/roboport/files/file-movie_scifi-big_cover.png?ts=1635316468.58",
          "url": "",
          "items": [
              {
                  "rating": {
                      "count": 1462403,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 9.3
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2014-11-12(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2614988097.jpg",
                      "normal": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614988097.jpg"
                  },
                  "is_show": false,
                  "year": "2014",
                  "card_subtitle": "2014 / 美国 英国 加拿大 / 剧情 科幻 冒险 / 克里斯托弗·诺兰 / 马修·麦康纳 安妮·海瑟薇",
                  "id": "1889243",
                  "genres": [
                      "剧情",
                      "科幻",
                      "冒险"
                  ],
                  "title": "星际穿越",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "马修·麦康纳"
                      },
                      {
                          "name": "安妮·海瑟薇"
                      },
                      {
                          "name": "杰西卡·查斯坦"
                      },
                      {
                          "name": "麦肯吉·弗依"
                      },
                      {
                          "name": "卡西·阿弗莱克"
                      },
                      {
                          "name": "迈克尔·凯恩"
                      },
                      {
                          "name": "马特·达蒙"
                      },
                      {
                          "name": "蒂莫西·柴勒梅德"
                      },
                      {
                          "name": "艾伦·伯斯汀"
                      },
                      {
                          "name": "约翰·利思戈"
                      },
                      {
                          "name": "韦斯·本特利"
                      },
                      {
                          "name": "大卫·吉亚西"
                      },
                      {
                          "name": "比尔·欧文"
                      },
                      {
                          "name": "托弗·戈瑞斯"
                      },
                      {
                          "name": "科莱特·沃夫"
                      },
                      {
                          "name": "弗朗西斯·X.麦卡蒂"
                      },
                      {
                          "name": "安德鲁·博尔巴"
                      },
                      {
                          "name": "乔什·斯图沃特"
                      },
                      {
                          "name": "莱雅·卡里恩斯"
                      },
                      {
                          "name": "利亚姆·迪金森"
                      },
                      {
                          "name": "杰夫·赫普内尔"
                      },
                      {
                          "name": "伊莱耶斯·加贝尔"
                      },
                      {
                          "name": "布鲁克·史密斯"
                      },
                      {
                          "name": "大卫·奥伊罗"
                      },
                      {
                          "name": "威廉姆·德瓦内"
                      },
                      {
                          "name": "拉什·费加"
                      },
                      {
                          "name": "格里芬·弗雷泽"
                      },
                      {
                          "name": "弗洛拉·诺兰"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "4d6472",
                      "_base_color": [
                          0.5625,
                          0.32876712328767116,
                          0.28627450980392155
                      ],
                      "secondary_color": "f4f8f9",
                      "_avg_color": [
                          0.22222222222222276,
                          0.023809523809523836,
                          0.49411764705882355
                      ],
                      "primary_color_dark": "33434c"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2614988097.jpg",
                  "sharing_url": "https://movie.douban.com/subject/1889243/",
                  "url": "https://movie.douban.com/subject/1889243/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/1889243",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "克里斯托弗·诺兰"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 699587,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 9.1
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "1999-03-31(美国)"
                  ],
                  "pic": {
                      "large": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p451926968.jpg",
                      "normal": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p451926968.jpg"
                  },
                  "is_show": false,
                  "year": "1999",
                  "card_subtitle": "1999 / 美国 / 动作 科幻 / 莉莉·沃卓斯基 拉娜·沃卓斯基 / 基努·里维斯 劳伦斯·菲什伯恩",
                  "id": "1291843",
                  "genres": [
                      "动作",
                      "科幻"
                  ],
                  "title": "黑客帝国",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "基努·里维斯"
                      },
                      {
                          "name": "劳伦斯·菲什伯恩"
                      },
                      {
                          "name": "凯瑞-安·莫斯"
                      },
                      {
                          "name": "雨果·维文"
                      },
                      {
                          "name": "格洛丽亚·福斯特"
                      },
                      {
                          "name": "乔·潘托里亚诺"
                      },
                      {
                          "name": "马库斯·钟"
                      },
                      {
                          "name": "朱利安·阿拉汗加"
                      },
                      {
                          "name": "马特·多兰"
                      },
                      {
                          "name": "贝琳达·麦克洛里"
                      },
                      {
                          "name": "安东尼雷派克"
                      },
                      {
                          "name": "罗伯特·泰勒"
                      },
                      {
                          "name": "阿达·尼科德莫"
                      },
                      {
                          "name": "罗温·维特"
                      },
                      {
                          "name": "塔玛拉·布朗"
                      },
                      {
                          "name": "纳塔莉·特珍"
                      },
                      {
                          "name": "比尔·扬"
                      },
                      {
                          "name": "克里斯·斯科特"
                      },
                      {
                          "name": "纳许·埃哲顿"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "2d724a",
                      "_base_color": [
                          0.40277777777777773,
                          0.6,
                          0.0784313725490196
                      ],
                      "secondary_color": "f4f9f6",
                      "_avg_color": [
                          0.3850574712643678,
                          0.4393939393939394,
                          0.25882352941176473
                      ],
                      "primary_color_dark": "1e4c31"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p451926968.jpg",
                  "sharing_url": "https://movie.douban.com/subject/1291843/",
                  "url": "https://movie.douban.com/subject/1291843/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/1291843",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "莉莉·沃卓斯基"
                      },
                      {
                          "name": "拉娜·沃卓斯基"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 1181103,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 8.7
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2018-03-30(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2516578307.jpg",
                      "normal": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2516578307.jpg"
                  },
                  "is_show": false,
                  "year": "2018",
                  "card_subtitle": "2018 / 美国 / 动作 科幻 冒险 / 史蒂文·斯皮尔伯格 / 泰伊·谢里丹 奥利维亚·库克",
                  "id": "4920389",
                  "genres": [
                      "动作",
                      "科幻",
                      "冒险"
                  ],
                  "title": "头号玩家",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "泰伊·谢里丹"
                      },
                      {
                          "name": "奥利维亚·库克"
                      },
                      {
                          "name": "本·门德尔森"
                      },
                      {
                          "name": "马克·里朗斯"
                      },
                      {
                          "name": "丽娜·维特"
                      },
                      {
                          "name": "森崎温"
                      },
                      {
                          "name": "赵家正"
                      },
                      {
                          "name": "西蒙·佩吉"
                      },
                      {
                          "name": "T·J·米勒"
                      },
                      {
                          "name": "汉娜·乔恩-卡门"
                      },
                      {
                          "name": "拉尔夫·伊内森"
                      },
                      {
                          "name": "苏珊·林奇"
                      },
                      {
                          "name": "克莱尔·希金斯"
                      },
                      {
                          "name": "劳伦斯·斯佩尔曼"
                      },
                      {
                          "name": "佩蒂塔·维克斯"
                      },
                      {
                          "name": "艾萨克·安德鲁斯"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "948aa5",
                      "_base_color": [
                          0.7285714285714285,
                          0.16203703703703698,
                          0.8470588235294118
                      ],
                      "secondary_color": "f6f4f9",
                      "_avg_color": [
                          0.6515151515151515,
                          0.34375,
                          0.5019607843137255
                      ],
                      "primary_color_dark": "726a7f"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p2516578307.jpg",
                  "sharing_url": "https://movie.douban.com/subject/4920389/",
                  "url": "https://movie.douban.com/subject/4920389/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/4920389",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "史蒂文·斯皮尔伯格"
                      }
                  ],
                  "null_rating_reason": ""
              }
          ],
          "uri": "douban://douban.com/subject_collection/movie_scifi?type=rank&category=movie&rank_type=film_genre",
          "updated_at": "2020-08-11 19:43:22",
          "covers": [
              "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614988097.jpg",
              "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p451926968.jpg",
              "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2516578307.jpg"
          ],
          "name": "高分经典科幻片榜",
          "icon_fg_image": null,
          "header_bg_image": "https://img9.doubanio.com/view/photo/photo/public/p2211063036.jpg",
          "type_text": "豆瓣高分榜",
          "cover_url": "https://img2.doubanio.com/img/files/file-1581519943.png",
          "medium_name": "高分经典",
          "total": 20,
          "type": "chart",
          "id": "movie_scifi",
          "background_color_scheme": {
              "is_dark": true,
              "primary_color_light": "4c5262",
              "secondary_color": "4c5262",
              "primary_color_dark": "4c5262"
          }
      },
      {
          "subtitle": "豆瓣榜单",
          "description": "",
          "header_fg_image": "https://img9.doubanio.com/img/roboport/files/file-movie_comedy-big_cover.png?ts=1635316468.6",
          "url": "",
          "items": [
              {
                  "rating": {
                      "count": 1626418,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 9.2
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2011-12-08(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p579729551.jpg",
                      "normal": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p579729551.jpg"
                  },
                  "is_show": false,
                  "year": "2009",
                  "card_subtitle": "2009 / 印度 / 剧情 喜剧 爱情 / 拉吉库马尔·希拉尼 / 阿米尔·汗 卡琳娜·卡普尔",
                  "id": "3793023",
                  "genres": [
                      "剧情",
                      "喜剧",
                      "爱情"
                  ],
                  "title": "三傻大闹宝莱坞",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "阿米尔·汗"
                      },
                      {
                          "name": "卡琳娜·卡普尔"
                      },
                      {
                          "name": "马达范"
                      },
                      {
                          "name": "沙尔曼·乔希"
                      },
                      {
                          "name": "奥米·瓦依达"
                      },
                      {
                          "name": "博曼·伊拉尼"
                      },
                      {
                          "name": "莫娜·辛格"
                      },
                      {
                          "name": "拉杰夫·拉宾德拉纳特安"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "8fa556",
                      "_base_color": [
                          0.21428571428571427,
                          0.4772727272727273,
                          0.17254901960784313
                      ],
                      "secondary_color": "f8f9f4",
                      "_avg_color": [
                          0.13117283950617284,
                          0.5934065934065934,
                          0.7137254901960784
                      ],
                      "primary_color_dark": "6e7f42"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p579729551.jpg",
                  "sharing_url": "https://movie.douban.com/subject/3793023/",
                  "url": "https://movie.douban.com/subject/3793023/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/3793023",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "拉吉库马尔·希拉尼"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 1055050,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 9
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2014-10-24(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p2561721372.jpg",
                      "normal": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2561721372.jpg"
                  },
                  "is_show": false,
                  "year": "1995",
                  "card_subtitle": "1995 / 中国香港 中国大陆 / 喜剧 爱情 奇幻 / 刘镇伟 / 周星驰 吴孟达",
                  "id": "1299398",
                  "genres": [
                      "喜剧",
                      "爱情",
                      "奇幻"
                  ],
                  "title": "大话西游之月光宝盒",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "周星驰"
                      },
                      {
                          "name": "吴孟达"
                      },
                      {
                          "name": "罗家英"
                      },
                      {
                          "name": "蓝洁瑛"
                      },
                      {
                          "name": "莫文蔚"
                      },
                      {
                          "name": "江约诚"
                      },
                      {
                          "name": "陆树铭"
                      },
                      {
                          "name": "刘镇伟"
                      },
                      {
                          "name": "朱茵"
                      },
                      {
                          "name": "李健仁"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "723520",
                      "_base_color": [
                          0.043624161073825496,
                          0.7198067632850242,
                          0.8117647058823529
                      ],
                      "secondary_color": "f9f6f4",
                      "_avg_color": [
                          0.030701754385964914,
                          0.6551724137931034,
                          0.4549019607843137
                      ],
                      "primary_color_dark": "4c2315"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img2.doubanio.com/view/photo/m_ratio_poster/public/p2561721372.jpg",
                  "sharing_url": "https://movie.douban.com/subject/1299398/",
                  "url": "https://movie.douban.com/subject/1299398/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/1299398",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "刘镇伟"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 517889,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 9.1
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "1998-08-28(英国)"
                  ],
                  "pic": {
                      "large": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p792443418.jpg",
                      "normal": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p792443418.jpg"
                  },
                  "is_show": false,
                  "year": "1998",
                  "card_subtitle": "1998 / 英国 / 剧情 喜剧 犯罪 / 盖·里奇 / 杰森·弗莱明 德克斯特·弗莱彻",
                  "id": "1293350",
                  "genres": [
                      "剧情",
                      "喜剧",
                      "犯罪"
                  ],
                  "title": "两杆大烟枪",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "杰森·弗莱明"
                      },
                      {
                          "name": "德克斯特·弗莱彻"
                      },
                      {
                          "name": "尼克·莫兰"
                      },
                      {
                          "name": "杰森·斯坦森"
                      },
                      {
                          "name": "斯蒂文·麦金托什"
                      },
                      {
                          "name": "斯汀"
                      },
                      {
                          "name": "维尼·琼斯"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "721a13",
                      "_base_color": [
                          0.01202749140893472,
                          0.8326180257510729,
                          0.9137254901960784
                      ],
                      "secondary_color": "f9f5f4",
                      "_avg_color": [
                          0.009433962264150941,
                          0.4732142857142857,
                          0.4392156862745098
                      ],
                      "primary_color_dark": "4c110c"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p792443418.jpg",
                  "sharing_url": "https://movie.douban.com/subject/1293350/",
                  "url": "https://movie.douban.com/subject/1293350/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/1293350",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "盖·里奇"
                      }
                  ],
                  "null_rating_reason": ""
              }
          ],
          "uri": "douban://douban.com/subject_collection/movie_comedy?type=rank&category=movie&rank_type=film_genre",
          "updated_at": "2020-08-11 19:38:44",
          "covers": [
              "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p579729551.jpg",
              "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2561721372.jpg",
              "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p792443418.jpg"
          ],
          "name": "高分经典喜剧片榜",
          "icon_fg_image": null,
          "header_bg_image": "https://img2.doubanio.com/view/photo/photo/public/p2571368413.jpg",
          "type_text": "豆瓣高分榜",
          "cover_url": "https://img9.doubanio.com/img/files/file-1581519974.png",
          "medium_name": "高分经典",
          "total": 20,
          "type": "chart",
          "id": "movie_comedy",
          "background_color_scheme": {
              "is_dark": true,
              "primary_color_light": "5b3e42",
              "secondary_color": "5b3e42",
              "primary_color_dark": "5b3e42"
          }
      },
      {
          "subtitle": "豆瓣榜单",
          "description": "",
          "header_fg_image": "https://img9.doubanio.com/img/roboport/files/file-movie_action-big_cover.png?ts=1635316452.66",
          "url": "",
          "items": [
              {
                  "rating": {
                      "count": 613186,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 8.8
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2012-08-27(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p1706428744.jpg",
                      "normal": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1706428744.jpg"
                  },
                  "is_show": false,
                  "year": "2012",
                  "card_subtitle": "2012 / 美国 英国 / 剧情 动作 科幻 / 克里斯托弗·诺兰 / 克里斯蒂安·贝尔 汤姆·哈迪",
                  "id": "3395373",
                  "genres": [
                      "剧情",
                      "动作",
                      "科幻"
                  ],
                  "title": "蝙蝠侠：黑暗骑士崛起",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "克里斯蒂安·贝尔"
                      },
                      {
                          "name": "汤姆·哈迪"
                      },
                      {
                          "name": "安妮·海瑟薇"
                      },
                      {
                          "name": "约瑟夫·高登-莱维特"
                      },
                      {
                          "name": "玛丽昂·歌迪亚"
                      },
                      {
                          "name": "加里·奥德曼"
                      },
                      {
                          "name": "迈克尔·凯恩"
                      },
                      {
                          "name": "摩根·弗里曼"
                      },
                      {
                          "name": "朱诺·坦普尔"
                      },
                      {
                          "name": "乔什·平茨"
                      },
                      {
                          "name": "丹尼尔·逊亚塔"
                      },
                      {
                          "name": "内斯特·卡博内尔"
                      },
                      {
                          "name": "伯恩·戈曼"
                      },
                      {
                          "name": "连姆·尼森"
                      },
                      {
                          "name": "乔伊·金"
                      },
                      {
                          "name": "艾丹·吉伦"
                      },
                      {
                          "name": "基里安·墨菲"
                      },
                      {
                          "name": "乔什·斯图沃特"
                      },
                      {
                          "name": "马修·莫迪恩"
                      },
                      {
                          "name": "本·门德尔森"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "72553f",
                      "_base_color": [
                          0.07216494845360823,
                          0.44907407407407407,
                          0.8470588235294118
                      ],
                      "secondary_color": "f9f7f4",
                      "_avg_color": [
                          0.05376344086021504,
                          0.4626865671641791,
                          0.2627450980392157
                      ],
                      "primary_color_dark": "4c392a"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p1706428744.jpg",
                  "sharing_url": "https://movie.douban.com/subject/3395373/",
                  "url": "https://movie.douban.com/subject/3395373/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/3395373",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "克里斯托弗·诺兰"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 364400,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 8.8
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2007-11-15(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p792223507.jpg",
                      "normal": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p792223507.jpg"
                  },
                  "is_show": false,
                  "year": "2007",
                  "card_subtitle": "2007 / 美国 德国 / 动作 悬疑 惊悚 / 保罗·格林格拉斯 / 马特·达蒙 朱丽娅·斯蒂尔斯",
                  "id": "1578507",
                  "genres": [
                      "动作",
                      "悬疑",
                      "惊悚"
                  ],
                  "title": "谍影重重3",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "马特·达蒙"
                      },
                      {
                          "name": "朱丽娅·斯蒂尔斯"
                      },
                      {
                          "name": "大卫·斯特雷泽恩"
                      },
                      {
                          "name": "斯科特·格伦"
                      },
                      {
                          "name": "帕迪·康斯戴恩"
                      },
                      {
                          "name": "埃德加·拉米雷兹"
                      },
                      {
                          "name": "阿尔伯特·芬尼"
                      },
                      {
                          "name": "琼·艾伦"
                      },
                      {
                          "name": "Tom Gallop"
                      },
                      {
                          "name": "克里·约翰逊"
                      },
                      {
                          "name": "丹尼尔·布鲁赫"
                      },
                      {
                          "name": "乔伊·安沙"
                      },
                      {
                          "name": "科林·斯廷顿"
                      },
                      {
                          "name": "丹·弗雷登堡"
                      },
                      {
                          "name": "Lucy Liemann"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "3473a5",
                      "_base_color": [
                          0.5740740740740741,
                          0.6835443037974684,
                          0.30980392156862746
                      ],
                      "secondary_color": "f4f7f9",
                      "_avg_color": [
                          0.5592592592592592,
                          0.3333333333333333,
                          0.5294117647058824
                      ],
                      "primary_color_dark": "28587f"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img1.doubanio.com/view/photo/m_ratio_poster/public/p792223507.jpg",
                  "sharing_url": "https://movie.douban.com/subject/1578507/",
                  "url": "https://movie.douban.com/subject/1578507/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/1578507",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "保罗·格林格拉斯"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 965913,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 8.5
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2019-04-24(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2552058346.jpg",
                      "normal": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2552058346.jpg"
                  },
                  "is_show": false,
                  "year": "2019",
                  "card_subtitle": "2019 / 美国 / 剧情 动作 科幻 / 安东尼·罗素 乔·罗素 / 小罗伯特·唐尼 克里斯·埃文斯",
                  "id": "26100958",
                  "genres": [
                      "剧情",
                      "动作",
                      "科幻"
                  ],
                  "title": "复仇者联盟4：终局之战",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "小罗伯特·唐尼"
                      },
                      {
                          "name": "克里斯·埃文斯"
                      },
                      {
                          "name": "马克·鲁弗洛"
                      },
                      {
                          "name": "克里斯·海姆斯沃斯"
                      },
                      {
                          "name": "乔什·布洛林"
                      },
                      {
                          "name": "保罗·路德"
                      },
                      {
                          "name": "凯伦·吉兰"
                      },
                      {
                          "name": "杰瑞米·雷纳"
                      },
                      {
                          "name": "斯嘉丽·约翰逊"
                      },
                      {
                          "name": "唐·钱德尔"
                      },
                      {
                          "name": "布丽·拉尔森"
                      },
                      {
                          "name": "布莱德利·库珀"
                      },
                      {
                          "name": "泰莎·汤普森"
                      },
                      {
                          "name": "汤姆·赫兰德"
                      },
                      {
                          "name": "伊丽莎白·奥尔森"
                      },
                      {
                          "name": "本尼迪克特·康伯巴奇"
                      },
                      {
                          "name": "蒂尔达·斯文顿"
                      },
                      {
                          "name": "格温妮斯·帕特洛"
                      },
                      {
                          "name": "蕾妮·罗素"
                      },
                      {
                          "name": "约翰·斯拉特里"
                      },
                      {
                          "name": "查德维克·博斯曼"
                      },
                      {
                          "name": "安东尼·麦凯"
                      },
                      {
                          "name": "塞巴斯蒂安·斯坦"
                      },
                      {
                          "name": "克里斯·帕拉特"
                      },
                      {
                          "name": "汤姆·希德勒斯顿"
                      },
                      {
                          "name": "佐伊·索尔达娜"
                      },
                      {
                          "name": "丹娜·奎里拉"
                      },
                      {
                          "name": "本尼迪克特·王"
                      },
                      {
                          "name": "庞·克莱门捷夫"
                      },
                      {
                          "name": "戴夫·巴蒂斯塔"
                      },
                      {
                          "name": "利蒂希娅·赖特"
                      },
                      {
                          "name": "伊万杰琳·莉莉"
                      },
                      {
                          "name": "乔恩·费儒"
                      },
                      {
                          "name": "海莉·阿特维尔"
                      },
                      {
                          "name": "娜塔莉·波特曼"
                      },
                      {
                          "name": "玛丽莎·托梅"
                      },
                      {
                          "name": "塔伊加·维迪提"
                      },
                      {
                          "name": "安吉拉·贝塞特"
                      },
                      {
                          "name": "迈克尔·道格拉斯"
                      },
                      {
                          "name": "米歇尔·菲佛"
                      },
                      {
                          "name": "威廉·赫特"
                      },
                      {
                          "name": "寇碧·史莫德斯"
                      },
                      {
                          "name": "肖恩·古恩"
                      },
                      {
                          "name": "温斯顿·杜克"
                      },
                      {
                          "name": "琳达·卡德里尼"
                      },
                      {
                          "name": "马克斯米利亚诺·赫尔南德斯"
                      },
                      {
                          "name": "弗兰克·格里罗"
                      },
                      {
                          "name": "真田广之"
                      },
                      {
                          "name": "汤姆-沃恩-劳勒"
                      },
                      {
                          "name": "詹姆斯·达西"
                      },
                      {
                          "name": "雅各布·巴特朗"
                      },
                      {
                          "name": "范·迪塞尔"
                      },
                      {
                          "name": "罗伯特·雷德福"
                      },
                      {
                          "name": "塞缪尔·杰克逊"
                      },
                      {
                          "name": "伊薇特·尼科尔·布朗"
                      },
                      {
                          "name": "卡梅伦·布鲁姆布罗"
                      },
                      {
                          "name": "蒂莫西·卡尔"
                      },
                      {
                          "name": "凯瑞·康顿"
                      },
                      {
                          "name": "迈克尔·A·库克"
                      },
                      {
                          "name": "凯莉·库恩"
                      },
                      {
                          "name": "艾玛·福尔曼"
                      },
                      {
                          "name": "雷纳·加拉赫"
                      },
                      {
                          "name": "丹妮拉·加斯基"
                      },
                      {
                          "name": "郑肯"
                      },
                      {
                          "name": "小弗洛伊德·安东尼·约翰"
                      },
                      {
                          "name": "斯坦·李"
                      },
                      {
                          "name": "罗斯·马昆德"
                      },
                      {
                          "name": "布伦特·麦吉"
                      },
                      {
                          "name": "迈克尔·皮耶里诺·米勒"
                      },
                      {
                          "name": "卡兰·马尔韦"
                      },
                      {
                          "name": "泰瑞·诺塔里"
                      },
                      {
                          "name": "吉米·雷·皮肯斯"
                      },
                      {
                          "name": "迈克尔·詹姆斯·肖"
                      },
                      {
                          "name": "泰·辛普金斯"
                      },
                      {
                          "name": "格雷格·蒂芬"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "4f4872",
                      "_base_color": [
                          0.6944444444444445,
                          0.36923076923076914,
                          0.2549019607843137
                      ],
                      "secondary_color": "f5f4f9",
                      "_avg_color": [
                          0.7083333333333334,
                          0.2285714285714286,
                          0.4117647058823529
                      ],
                      "primary_color_dark": "34304c"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2552058346.jpg",
                  "sharing_url": "https://movie.douban.com/subject/26100958/",
                  "url": "https://movie.douban.com/subject/26100958/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/26100958",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "安东尼·罗素"
                      },
                      {
                          "name": "乔·罗素"
                      }
                  ],
                  "null_rating_reason": ""
              }
          ],
          "uri": "douban://douban.com/subject_collection/movie_action?type=rank&category=movie&rank_type=film_genre",
          "updated_at": "2020-08-11 19:36:56",
          "covers": [
              "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1706428744.jpg",
              "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p792223507.jpg",
              "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2552058346.jpg"
          ],
          "name": "高分经典动作片榜",
          "icon_fg_image": null,
          "header_bg_image": "https://img2.doubanio.com/view/photo/photo/public/p1688900402.jpg",
          "type_text": "豆瓣高分榜",
          "cover_url": "https://img2.doubanio.com/img/files/file-1581519902.png",
          "medium_name": "高分经典",
          "total": 20,
          "type": "chart",
          "id": "movie_action",
          "background_color_scheme": {
              "is_dark": true,
              "primary_color_light": "35465d",
              "secondary_color": "35465d",
              "primary_color_dark": "35465d"
          }
      },
      {
          "subtitle": "豆瓣榜单",
          "description": "",
          "header_fg_image": "https://img9.doubanio.com/img/roboport/files/file-movie_love-big_cover.png?ts=1635316450.88",
          "url": "",
          "items": [
              {
                  "rating": {
                      "count": 1820326,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 9.4
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "1998-04-03(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p457760035.jpg",
                      "normal": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p457760035.jpg"
                  },
                  "is_show": false,
                  "year": "1997",
                  "card_subtitle": "1997 / 美国 墨西哥 澳大利亚 加拿大 / 剧情 爱情 灾难 / 詹姆斯·卡梅隆 / 莱昂纳多·迪卡普里奥 凯特·温丝莱特",
                  "id": "1292722",
                  "genres": [
                      "剧情",
                      "爱情",
                      "灾难"
                  ],
                  "title": "泰坦尼克号",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "莱昂纳多·迪卡普里奥"
                      },
                      {
                          "name": "凯特·温丝莱特"
                      },
                      {
                          "name": "比利·赞恩"
                      },
                      {
                          "name": "凯西·贝茨"
                      },
                      {
                          "name": "弗兰西丝·费舍"
                      },
                      {
                          "name": "格劳瑞亚·斯图尔特"
                      },
                      {
                          "name": "比尔·帕克斯顿"
                      },
                      {
                          "name": "伯纳德·希尔"
                      },
                      {
                          "name": "大卫·沃纳"
                      },
                      {
                          "name": "维克多·加博"
                      },
                      {
                          "name": "乔纳森·海德"
                      },
                      {
                          "name": "苏茜·爱米斯"
                      },
                      {
                          "name": "刘易斯·阿伯内西"
                      },
                      {
                          "name": "尼古拉斯·卡斯柯恩"
                      },
                      {
                          "name": "阿那托利·萨加洛维奇"
                      },
                      {
                          "name": "丹尼·努齐"
                      },
                      {
                          "name": "杰森·贝瑞"
                      },
                      {
                          "name": "伊万·斯图尔特"
                      },
                      {
                          "name": "艾恩·格拉法德"
                      },
                      {
                          "name": "乔纳森·菲利普斯"
                      },
                      {
                          "name": "马克·林赛·查普曼"
                      },
                      {
                          "name": "理查德·格拉翰"
                      },
                      {
                          "name": "保罗·布赖特威尔"
                      },
                      {
                          "name": "艾瑞克·布里登"
                      },
                      {
                          "name": "夏洛特·查顿"
                      },
                      {
                          "name": "博纳德·福克斯"
                      },
                      {
                          "name": "迈克尔·英塞恩"
                      },
                      {
                          "name": "法妮·布雷特"
                      },
                      {
                          "name": "马丁·贾维斯"
                      },
                      {
                          "name": "罗莎琳·艾尔斯"
                      },
                      {
                          "name": "罗切尔·罗斯"
                      },
                      {
                          "name": "乔纳森·伊万斯-琼斯"
                      },
                      {
                          "name": "西蒙·克雷恩"
                      },
                      {
                          "name": "爱德华德·弗莱彻"
                      },
                      {
                          "name": "斯科特·安德森"
                      },
                      {
                          "name": "马丁·伊斯特"
                      },
                      {
                          "name": "克雷格·凯利"
                      },
                      {
                          "name": "格雷戈里·库克"
                      },
                      {
                          "name": "利亚姆·图伊"
                      },
                      {
                          "name": "詹姆斯·兰开斯特"
                      },
                      {
                          "name": "艾尔莎·瑞雯"
                      },
                      {
                          "name": "卢·帕尔特"
                      },
                      {
                          "name": "泰瑞·佛瑞斯塔"
                      },
                      {
                          "name": "凯文·德·拉·诺伊"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "a59890",
                      "_base_color": [
                          0.06547619047619037,
                          0.12727272727272732,
                          0.8627450980392157
                      ],
                      "secondary_color": "f9f6f4",
                      "_avg_color": [
                          0.05882352941176464,
                          0.13281249999999997,
                          0.5019607843137255
                      ],
                      "primary_color_dark": "7f756f"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p457760035.jpg",
                  "sharing_url": "https://movie.douban.com/subject/1292722/",
                  "url": "https://movie.douban.com/subject/1292722/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/1292722",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "詹姆斯·卡梅隆"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 1323857,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 9.2
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "2014-10-24(中国大陆)"
                  ],
                  "pic": {
                      "large": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2455050536.jpg",
                      "normal": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2455050536.jpg"
                  },
                  "is_show": false,
                  "year": "1995",
                  "card_subtitle": "1995 / 中国香港 中国大陆 / 喜剧 爱情 奇幻 / 刘镇伟 / 周星驰 吴孟达",
                  "id": "1292213",
                  "genres": [
                      "喜剧",
                      "爱情",
                      "奇幻"
                  ],
                  "title": "大话西游之大圣娶亲",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "周星驰"
                      },
                      {
                          "name": "吴孟达"
                      },
                      {
                          "name": "朱茵"
                      },
                      {
                          "name": "蔡少芬"
                      },
                      {
                          "name": "蓝洁瑛"
                      },
                      {
                          "name": "莫文蔚"
                      },
                      {
                          "name": "罗家英"
                      },
                      {
                          "name": "刘镇伟"
                      },
                      {
                          "name": "陆树铭"
                      },
                      {
                          "name": "李健仁"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "a55f42",
                      "_base_color": [
                          0.04927536231884059,
                          0.5989583333333334,
                          0.7529411764705882
                      ],
                      "secondary_color": "f9f6f4",
                      "_avg_color": [
                          0.057017543859649134,
                          0.5135135135135136,
                          0.5803921568627451
                      ],
                      "primary_color_dark": "7f4933"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2455050536.jpg",
                  "sharing_url": "https://movie.douban.com/subject/1292213/",
                  "url": "https://movie.douban.com/subject/1292213/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/1292213",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "刘镇伟"
                      }
                  ],
                  "null_rating_reason": ""
              },
              {
                  "rating": {
                      "count": 592884,
                      "max": 10,
                      "star_count": 4.5,
                      "value": 9.3
                  },
                  "controversy_reason": "",
                  "pubdate": [
                      "1939-12-15(亚特兰大首映)"
                  ],
                  "pic": {
                      "large": "https://img3.doubanio.com/view/photo/m_ratio_poster/public/p1963126880.jpg",
                      "normal": "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1963126880.jpg"
                  },
                  "is_show": false,
                  "year": "1939",
                  "card_subtitle": "1939 / 美国 / 剧情 历史 爱情 / 维克多·弗莱明 乔治·库克 山姆·伍德 / 费雯·丽 克拉克·盖博",
                  "id": "1300267",
                  "genres": [
                      "剧情",
                      "历史",
                      "爱情"
                  ],
                  "title": "乱世佳人",
                  "is_released": true,
                  "actors": [
                      {
                          "name": "费雯·丽"
                      },
                      {
                          "name": "克拉克·盖博"
                      },
                      {
                          "name": "奥利维娅·德哈维兰"
                      },
                      {
                          "name": "托马斯·米切尔"
                      },
                      {
                          "name": "芭芭拉·欧内尔"
                      },
                      {
                          "name": "伊夫林·凯耶斯"
                      },
                      {
                          "name": "安·卢瑟福德"
                      },
                      {
                          "name": "乔治·里弗斯"
                      },
                      {
                          "name": "弗莱德·克莱恩"
                      },
                      {
                          "name": "海蒂·麦克丹尼尔斯"
                      },
                      {
                          "name": "奥斯卡·波尔克"
                      },
                      {
                          "name": "巴特弗莱·麦昆"
                      },
                      {
                          "name": "维克托·乔里"
                      },
                      {
                          "name": "埃弗雷特·布朗"
                      },
                      {
                          "name": "霍华德·C·希克曼"
                      },
                      {
                          "name": "艾丽西亚·瑞特"
                      },
                      {
                          "name": "莱斯利·霍华德"
                      },
                      {
                          "name": "兰德·布鲁克斯"
                      },
                      {
                          "name": "卡洛尔·奈"
                      },
                      {
                          "name": "劳拉·霍普·克鲁斯"
                      },
                      {
                          "name": "埃迪·安德森"
                      },
                      {
                          "name": "哈里·达文波特"
                      },
                      {
                          "name": "利昂娜·罗伯特"
                      },
                      {
                          "name": "简·达威尔"
                      },
                      {
                          "name": "欧娜·满森"
                      },
                      {
                          "name": "保罗·赫斯特"
                      },
                      {
                          "name": "伊莎贝尔·朱尔"
                      },
                      {
                          "name": "卡米·金·肯伦"
                      },
                      {
                          "name": "艾瑞克·林登"
                      },
                      {
                          "name": "J·M·克里根"
                      },
                      {
                          "name": "沃德·邦德"
                      },
                      {
                          "name": "莉莲·肯布尔-库珀"
                      }
                  ],
                  "color_scheme": {
                      "is_dark": true,
                      "primary_color_light": "a53114",
                      "_base_color": [
                          0.03264604810996561,
                          0.8738738738738738,
                          0.43529411764705883
                      ],
                      "secondary_color": "f9f5f4",
                      "_avg_color": [
                          0.07253086419753085,
                          0.574468085106383,
                          0.7372549019607844
                      ],
                      "primary_color_dark": "7f2510"
                  },
                  "type": "movie",
                  "has_linewatch": true,
                  "cover_url": "https://img3.doubanio.com/view/photo/m_ratio_poster/public/p1963126880.jpg",
                  "sharing_url": "https://movie.douban.com/subject/1300267/",
                  "url": "https://movie.douban.com/subject/1300267/",
                  "release_date": null,
                  "uri": "douban://douban.com/movie/1300267",
                  "subtype": "movie",
                  "directors": [
                      {
                          "name": "维克多·弗莱明"
                      },
                      {
                          "name": "乔治·库克"
                      },
                      {
                          "name": "山姆·伍德"
                      }
                  ],
                  "null_rating_reason": ""
              }
          ],
          "uri": "douban://douban.com/subject_collection/movie_love?type=rank&category=movie&rank_type=film_genre",
          "updated_at": "2021-06-23 16:11:46",
          "covers": [
              "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p457760035.jpg",
              "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2455050536.jpg",
              "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1963126880.jpg"
          ],
          "name": "高分经典爱情片榜",
          "icon_fg_image": null,
          "header_bg_image": "https://img2.doubanio.com/view/photo/photo/public/p457875621.jpg",
          "type_text": "豆瓣高分榜",
          "cover_url": "https://img1.doubanio.com/img/files/file-1581519787.png",
          "medium_name": "高分经典",
          "total": 20,
          "type": "chart",
          "id": "movie_love",
          "background_color_scheme": {
              "is_dark": true,
              "primary_color_light": "713d3c",
              "secondary_color": "713d3c",
              "primary_color_dark": "713d3c"
          }
      }
  ],
  "title": "豆瓣榜单"
}