let data =  {
  "count": 20,
  "items": [
      {
          "type_name": "电影",
          "layout": "subject",
          "target": {
              "rating": {
                  "count": 443562,
                  "max": 10,
                  "star_count": 3.5,
                  "value": 7.4
              },
              "controversy_reason": "",
              "title": "长津湖",
              "abstract": "",
              "has_linewatch": false,
              "uri": "douban://douban.com/movie/25845392",
              "cover_url": "https://qnmob3.doubanio.com/view/photo/large/public/p2681329386.jpg?imageView2/0/q/80/w/9999/h/120/format/jpg",
              "year": "2021",
              "card_subtitle": "7.4分 / 2021 / 中国大陆 中国香港 / 剧情 历史 战争 / 陈凯歌 徐克 林超贤 / 吴京 易烊千玺",
              "id": "25845392",
              "null_rating_reason": ""
          },
          "target_type": "movie"
      },
      {
          "type_name": "电影",
          "layout": "subject",
          "target": {
              "rating": {
                  "count": 972,
                  "max": 10,
                  "star_count": 4,
                  "value": 7.9
              },
              "controversy_reason": "",
              "title": "长津湖",
              "abstract": "",
              "has_linewatch": false,
              "uri": "douban://douban.com/movie/26996628",
              "cover_url": "https://qnmob3.doubanio.com/view/photo/large/public/p2446633455.jpg?imageView2/0/q/80/w/9999/h/120/format/jpg",
              "year": "2010",
              "card_subtitle": "7.9分 / 2010 / 美国 / 历史 战争 纪录片 / Brian Iglesias",
              "id": "26996628",
              "null_rating_reason": ""
          },
          "target_type": "movie"
      },
      {
          "type_name": "电影",
          "layout": "subject",
          "target": {
              "rating": {
                  "count": 519,
                  "max": 10,
                  "star_count": 4,
                  "value": 7.6
              },
              "controversy_reason": "",
              "title": "长津湖大突围",
              "abstract": "",
              "has_linewatch": false,
              "uri": "douban://douban.com/movie/11521799",
              "cover_url": "https://qnmob3.doubanio.com/view/photo/large/public/p2559533672.jpg?imageView2/0/q/80/w/9999/h/120/format/jpg",
              "year": "2010",
              "card_subtitle": "7.6分 / 2010 / 美国 / 纪录片 战争 / Ted Poole / Chew-Een Lee",
              "id": "11521799",
              "null_rating_reason": ""
          },
          "target_type": "movie"
      },
      {
          "type_name": "电影",
          "layout": "subject",
          "target": {
              "rating": {
                  "count": 175,
                  "max": 10,
                  "star_count": 3,
                  "value": 6.2
              },
              "controversy_reason": "",
              "title": "长津湖：火焰洗礼",
              "abstract": "",
              "has_linewatch": false,
              "uri": "douban://douban.com/movie/26935448",
              "cover_url": "https://qnmob3.doubanio.com/view/photo/large/public/p2405498741.jpg?imageView2/0/q/80/w/9999/h/120/format/jpg",
              "year": "2014",
              "card_subtitle": "6.2分 / 2014 / 美国 / 历史 战争 动画 / Chris DiFiore / Tim Cronin",
              "id": "26935448",
              "null_rating_reason": ""
          },
          "target_type": "movie"
      },
      {
          "type_name": "电影",
          "layout": "subject",
          "target": {
              "rating": {
                  "count": 10674,
                  "max": 10,
                  "star_count": 4.5,
                  "value": 9.3
              },
              "controversy_reason": "",
              "title": "冰血长津湖",
              "abstract": "",
              "has_linewatch": true,
              "uri": "douban://douban.com/movie/6129689",
              "cover_url": "https://qnmob3.doubanio.com/view/photo/large/public/p2691478511.jpg?imageView2/0/q/80/w/9999/h/120/format/jpg",
              "year": "2011",
              "card_subtitle": "9.3分 / 2011 / 中国大陆 / 纪录片 / 颜品 付勇 刘治寰",
              "id": "6129689",
              "null_rating_reason": ""
          },
          "target_type": "movie"
      },
      {
          "type_name": "图书",
          "layout": "subject",
          "target": {
              "rating": {
                  "count": 52,
                  "max": 10,
                  "star_count": 4,
                  "value": 7.7
              },
              "controversy_reason": "",
              "title": "长津湖",
              "abstract": "",
              "uri": "douban://douban.com/book/10452435",
              "cover_url": "https://img2.doubanio.com/view/subject/m/public/s7659053.jpg",
              "has_ebook": false,
              "card_subtitle": "7.7分 / 王筠 / 2011 / 湖南文艺出版社",
              "id": "10452435",
              "null_rating_reason": ""
          },
          "target_type": "book"
      },
      {
          "type_name": "电视剧",
          "layout": "subject",
          "target": {
              "rating": {
                  "count": 120,
                  "max": 10,
                  "star_count": 4,
                  "value": 8.3
              },
              "controversy_reason": "",
              "title": "血色军魂——长津湖战役纪实",
              "abstract": "",
              "has_linewatch": false,
              "uri": "douban://douban.com/tv/26644203",
              "cover_url": "https://qnmob3.doubanio.com/view/photo/large/public/p2559390876.jpg?imageView2/0/q/80/w/9999/h/120/format/jpg",
              "year": "2010",
              "card_subtitle": "8.3分 / 2010 / 中国香港 / 战争 纪录片",
              "id": "26644203",
              "null_rating_reason": ""
          },
          "target_type": "tv"
      },
      {
          "type_name": "图书",
          "layout": "subject",
          "target": {
              "rating": {
                  "count": 0,
                  "max": 10,
                  "star_count": 0,
                  "value": 0
              },
              "controversy_reason": "",
              "title": "长津湖",
              "abstract": "",
              "uri": "douban://douban.com/book/35585175",
              "cover_url": "https://img9.doubanio.com/view/subject/m/public/s33996295.jpg",
              "has_ebook": false,
              "card_subtitle": "暂无评分 / 王筠 / 2021 / 北京十月文艺出版社",
              "id": "35585175",
              "null_rating_reason": "暂无评分"
          },
          "target_type": "book"
      },
      {
          "type_name": "电影",
          "layout": "subject",
          "target": {
              "rating": {
                  "count": 0,
                  "max": 10,
                  "star_count": 0,
                  "value": 0
              },
              "controversy_reason": "",
              "title": "水门桥",
              "abstract": "",
              "has_linewatch": false,
              "uri": "douban://douban.com/movie/35613853",
              "cover_url": "https://qnmob3.doubanio.com/view/photo/large/public/p2691443889.jpg?imageView2/0/q/80/w/9999/h/120/format/jpg",
              "year": "2022",
              "card_subtitle": "尚未上映 / 2022 / 中国大陆 / 剧情 历史 战争 / 陈凯歌 徐克 林超贤 / 吴京 易烊千玺",
              "id": "35613853",
              "null_rating_reason": "尚未上映"
          },
          "target_type": "movie"
      },
      {
          "type_name": "图书",
          "layout": "subject",
          "target": {
              "rating": {
                  "count": 174,
                  "max": 10,
                  "star_count": 3.5,
                  "value": 7.4
              },
              "controversy_reason": "",
              "title": "血战长津湖",
              "abstract": "",
              "uri": "douban://douban.com/book/35596538",
              "cover_url": "https://img9.doubanio.com/view/subject/m/public/s34008036.jpg",
              "has_ebook": false,
              "card_subtitle": "7.4分 / 何楚舞 凤鸣 陆宏宇 / 2021 / 现代出版社",
              "id": "35596538",
              "null_rating_reason": ""
          },
          "target_type": "book"
      },
      {
          "type_name": "图书",
          "layout": "subject",
          "target": {
              "rating": {
                  "count": 10,
                  "max": 10,
                  "star_count": 3.5,
                  "value": 7.2
              },
              "controversy_reason": "",
              "title": "亮剑长津湖-第二次战役战事报告",
              "abstract": "",
              "uri": "douban://douban.com/book/2052676",
              "cover_url": "https://img1.doubanio.com/view/subject/m/public/s9000798.jpg",
              "has_ebook": false,
              "card_subtitle": "7.2分 / 胡海波 / 2007 / 军事科学",
              "id": "2052676",
              "null_rating_reason": ""
          },
          "target_type": "book"
      },
      {
          "type_name": "图书",
          "layout": "subject",
          "target": {
              "rating": {
                  "count": 0,
                  "max": 10,
                  "star_count": 0,
                  "value": 0
              },
              "controversy_reason": "",
              "title": "(DVD)长津湖战役",
              "abstract": "",
              "uri": "douban://douban.com/book/6826966",
              "cover_url": "https://img1.doubanio.com/f/frodo/b9c30c34e0a0c4697919a65783703492eaf8b674/pics/subject/book_normal.png",
              "has_ebook": false,
              "card_subtitle": "暂无评分 / ",
              "id": "6826966",
              "null_rating_reason": "暂无评分"
          },
          "target_type": "book"
      },
      {
          "type_name": "图书",
          "layout": "subject",
          "target": {
              "rating": {
                  "count": 0,
                  "max": 10,
                  "star_count": 0,
                  "value": 0
              },
              "controversy_reason": "",
              "title": "亮剑长津湖/第二次战役战事报告",
              "abstract": "",
              "uri": "douban://douban.com/book/3491604",
              "cover_url": "https://img1.doubanio.com/f/frodo/b9c30c34e0a0c4697919a65783703492eaf8b674/pics/subject/book_normal.png",
              "has_ebook": false,
              "card_subtitle": "暂无评分 / ",
              "id": "3491604",
              "null_rating_reason": "暂无评分"
          },
          "target_type": "book"
      }
  ],
  "total": 14,
  "start": 0
}