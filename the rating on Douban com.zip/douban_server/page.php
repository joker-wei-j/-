<?php




    $f=fopen("./data/1.首页影院热映信息.json","r");
    $data=fread($f,filesize("./data/1.首页影院热映信息.json"));
    echo $data;
?>
