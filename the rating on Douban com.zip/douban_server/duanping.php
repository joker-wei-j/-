<?php


$page = $_GET["currentPage"];
$path="./data/长津湖详情页数据/短评/详情页长津湖数据短评"."第".$page."页.json";
$f = @fopen($path, "r") or die("[]");
$data = fread($f, filesize($path));
echo $data;
?>
