<?php
$nickName = $_GET["nickName"];
$title = $_GET["title"];
# 1. 数据库链接 mysql -u root -p root
$conn = mysqli_connect("localhost","root","root");
# 2. 选择数据库进行操作 use douban
mysqli_select_db($conn,"douban");
# 3. 执行sql命令 select id,titles from top250 limit 0,20; 返回一个包含结果的对象
$sql = "select * from comment where nickName = '".$nickName."' and title = '".$title."';";
$result = mysqli_query($conn,$sql);
# 4. 从结果对象中取数据 mysqli_fetch_all返回一个数组
$row = mysqli_fetch_assoc($result);
# 5. 关闭链接
mysqli_close($conn);
# 6. 构造接口向前端返回
if($row){
    $data = ["code"=>0,"msg"=>"success","isHas"=>true,"content"=>$row["content"],"score"=>$row["score"]];
    echo json_encode($data);
}else{
    $data = ["code"=>0,"msg"=>"success","isHas"=>false,"content"=>"","score"=>""];
    echo json_encode($data);
}
