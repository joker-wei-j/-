<?php


$f=fopen("data/长津湖详情页数据/影评/详情页长津湖数据影评第1页.json","r");
$data=fread($f,filesize("data/长津湖详情页数据/影评/详情页长津湖数据影评第1页.json"));
echo $data;

?>


