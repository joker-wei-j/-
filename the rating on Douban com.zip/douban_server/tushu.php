<?php
$f=fopen("./data/4.畅销图书.json","r");
$data=fread($f,filesize("./data/4.畅销图书.json"));
echo $data;
?>


