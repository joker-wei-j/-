<?php
$nickName = $_GET["nickName"];
$avatarUrl = $_GET["avatarUrl"];
$date = $_GET["date"];
$title = $_GET["title"];
$score = $_GET["score"];
$content = $_GET["content"];


# 1. 数据库链接 mysql -u root -p root
$conn = mysqli_connect("localhost","root","root");
# 2. 选择数据库进行操作 use douban
mysqli_select_db($conn,"douban");
# 3. 执行sql命令 select id,title from top250 limit 0,20; 返回一个包含结果的对象
$sql = "insert into comment (nickName,avatarUrl,date,title,score,content) values ('".$nickName."','".$avatarUrl."','".$date."','".$title."',".$score.",'".$content."');";
$result = mysqli_query($conn,$sql);
echo '{"code":0,"msg":"success"}';
?>
