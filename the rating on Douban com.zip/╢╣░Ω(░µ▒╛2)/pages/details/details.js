const app = getApp();
//加载本地数据
const shuju = require("../豆瓣电影临时本地数据data/详情页数据/1.详情页主要数据.js")
const juzhao = require("../豆瓣电影临时本地数据data/详情页数据/2.电影演员剧照.js")
const actor = require("../豆瓣电影临时本地数据data/详情页数据/7.演员详情.js")
// 推荐电影
const tuijian = require("../豆瓣电影临时本地数据data/详情页数据/6.推荐电影.js")
// 影评
// const critics=require("../豆瓣电影临时本地数据data/详情页数据/5.影评.js")
// 短评
const duanping = require("../豆瓣电影临时本地数据data/详情页数据/4.短评.js")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    shuju: {
      shuju: shuju.xiangqing
    },
    //剧照
    juzhao: {
      juzhao: juzhao.juzhao
    },
    // 影人演员
    actor: {
      dataList: actor.yanyuan
    },
    // 推荐
    tuijian: {
      tuijian: tuijian.tuijian
    },
    // 影评

    critics: [],

    // 短评
    duanping: {
      duanping: duanping.duanping
    },
    img: "",
    title: {},
    rate: "",
    currentPage: 0,

    title: undefined,
    imgurl: undefined,
    isHas: false,
    content: "",
    score: 0
  },
  back() {
    wx.navigateBack({
      delta: 1,
    })
  },
  index() {
    wx.switchTab({
      url: '/pages/index1/index1',
    })
  },
  toStill() {
    wx.navigateTo({
      url: '../still/still',
    })
  },
  // 向短评页面传评分和标题
  toEssay(e){
    let rate=e.currentTarget.dataset.rate
    let title=e.currentTarget.dataset.title
    wx.navigateTo({
      url: `../essay/essay?rate=${rate}&title=${title}`,
    })
  },
  toComment: function (e) {
    let title = e.currentTarget.dataset.title;
    let {
      content,
      score
    } = this.data;
    if (wx.getStorageSync('userInfo')) {
      wx.navigateTo({
        url: `../comment/comment?title=${title}&&content=${content}&score=${score}`,
      })
    } else {
      wx.navigateTo({
        url: '../mine/mine',
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
        img: options.img,
        title: options.title,
        rate: options.rate
      }),
      wx.setNavigationBarTitle({
        title: options.title,
      })

    wx.request({
      url: 'http://www.doubanppp.com/yingpingTop.php',
      success: (res) => {
        let data = res.data;
        this.setData({
          critics: data
        });
      }
    })

    let {
      title,
      imgurl,
      rate,
      url
    } = options;
    this.setData({
      title,
      imgurl
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 请求接口 判定当前电影用户有没有评论过
    wx.request({
      url: app.globalData.href + '/getcomment.php',
      data: {
        title: this.data.title,
        nickName: "56"
      },
      success: (res) => {
        console.log(res.data);
        let {
          isHas,
          content,
          score
        } = res.data;
        this.setData({
          isHas,
          content,
          score
        });
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.setData({
      currentPage: this.data.currentPage += 1
    });
    wx.request({
      url: 'http://www.doubanppp.com/yingping.php',
      data: {
        currentPage: this.data.currentPage,
      },
      success: (res) => {
        // console.log(res.data);
        let newdata = res.data;
        // console.log(newdata);
        this.setData({
          critics: this.data.critics.concat(newdata)
        })
      }
    })
  },
})