let app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        userInfo: {},
        collect: {},
        //收藏数量
        collectNumber: 0,
        logint: false,
        avatarUrl: "",
        nickName: ""
    },

    //登录按钮事件
    toEnter: function () {
        wx.navigateTo({
            url: '../enter/enter',
        })
    },
    onLoad: function (options) {
        //提出登录数据
        let userInfo = wx.getStorageSync("userInfo")
        this.setData({
            userInfo
        })
        // console.log(userInfo);
        //设置昵称、图片
        this.setData({
            nickName: userInfo.nickName
        })
        this.setData({
            avatarUrl: userInfo.avatarUrl
        })
        //状态
        this.setData({
            logint: app.globalData.logint
        })
        // console.log(app.globalData.logint);
    },
    exit() {
        this.setData({
            logint: false
        })
    },

    //退出
    tuichu: function () {
        this.setData({
            userInfo: {},
            collect: {}
        })
        wx.removeStorageSync('userInfo');
    }
})