// pages/search/search.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchResult: [],
    currentPage: 1,
    keyword: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  confirm: function (e) {
    console.log(e.detail.value);
    this.setData({
      keyword: e.detail.value
    });
    wx.request({
      url: 'http://www.doubanppp.com/search.php',
      data: {
        page: this.data.currentPage,
        keyword: e.detail.value
      },
      success: (res) => {
        console.log(res.data);
        this.setData({
          searchResult: res.data
        });
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.setData({
      currentPage: this.data.currentPage += 1
    });
    wx.request({
      url: 'http://www.doubanppp.com/search.php',
      data: {
        page: this.data.currentPage,
        keyword: this.data.keyword
      },
      success: (res) => {
        let newDataList = res.data;
        this.setData({
          searchResult: this.data.searchResult.concat(newDataList)
        });
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})