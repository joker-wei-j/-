// pages/top250/top250.js
const hotdoubanTop250 = require("../豆瓣电影临时本地数据data/榜单详情页豆瓣电影top250/8.豆瓣电影Top250数据第1页.js")
// console.log(hotdoubanTop250.doubanTop250);

Page({

  /**
   * 页面的初始数据
   */
  data: {
    // hotdoubanTop250: {
    //   topic: "影院熱映",
    //   dataLIst: hotdoubanTop250.hotdoubanTop250
    // }
    dataLIst: hotdoubanTop250.doubanTop250,
    dataList: [],
    currentPage: 1,
  },

  onReachBottom: function () {
    // console.log(dataLIst);
    if (this.data.currentPage < 10) {
      // 更新页码
      this.setData({
        currentPage: this.data.currentPage += 1
      });
      // 模拟ajax
     let newDataList = require(`../豆瓣电影临时本地数据data/榜单详情页豆瓣电影top250/8.豆瓣电影Top250数据第${this.data.currentPage}页.js`).doubanTop250;
     this.setData({dataLIst:this.data.dataLIst.concat(newDataList)});
    }
    //  把新数据合并到老数据上面
  },
})