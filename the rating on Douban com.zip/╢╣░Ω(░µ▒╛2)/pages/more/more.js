const app=getApp();
// pages/more/more.js
const hotShowing = require("../豆瓣电影临时本地数据data/1.首页影院热映信息.js")
const doubanHot = require("../豆瓣电影临时本地数据data/2.豆瓣热门.js")
const hotTV = require("../豆瓣电影临时本地数据data/3.近期热门剧集")
const hotShow = require("../豆瓣电影临时本地数据data/4.近期热门综艺.js")
const tushu= require("../豆瓣电影临时本地数据data/6.畅销图书.js");
const danqu=require("../豆瓣电影临时本地数据data/7.热门单曲榜.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    topic2data: {
      "影院热映": hotShowing.hotShowing,
      "豆瓣热门": doubanHot.doubanHot.subjects,
      "近期热门剧集": hotTV.hotTV.subjects,
      "近期热门综艺节目": hotShow.hotShow.subjects,
      "畅销图书":tushu.tushu,
      "热门单曲榜":danqu.danqu
    },
    dataList: [],
    // dataList1:[],
    currentPage: 1,//单曲，热门
    wenzi: '',
  },

  toMore() {
    wx.navigateBack({
      delta: 1,
    })
  },
  toMore2() {
    wx.switchTab({
      url: '../index1/index1'
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let dataList = this.data.topic2data[options.topic];
    console.log(dataList);
    this.setData({
      dataList: this.data.topic2data[options.topic],
      // dataList1: this.data.topic2data[options.topic],
      wenzi:options.topic
    });
    },
    // 下拉刷新
  onReachBottom: function () {
    let dataName = this.data.wenzi;
    console.log(dataName);
    this.setData({
      currentPage: this.data.currentPage += 1
    });
    wx.request({
      url: 'http://www.doubanppp.com/move.php',
      data: {
        page: this.data.currentPage,
        wenzi: dataName,
      },
      success: (res) => {
        let newdata = res.data;
        // console.log(newdata);
        this.setData({
          dataList: this.data.dataList.concat(newdata)
        })
      }
    })













    //   if(this.data.currentPage < 5){
    //     // 更新页码
    //     this.setData({currentPage:this.data.currentPage += 1});
    //     // 模拟ajax
    //     let newDataList = require(`../豆瓣电影临时本地数据data/豆瓣热门前五页数据/2.豆瓣热门第${this.data.currentPage}页.js`).doubanHot.subjects;
    //     //  把新数据合并到老数据上面
    //     this.setData({dataList:this.data.dataList.concat(newDataList)});
    //   }
  },
})