let data = [{
    "rank": "1",
    "cover": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p480747492.jpg",
    "title": "肖申克的救赎",
    "actor": "\n                            导演: 弗兰克·德拉邦特 Frank Darabont   主演: 蒂姆·罗宾斯 Tim Robbins /...",
    "score": "9.7",
    "display": "希望让人自由。",
    "url": "https://movie.douban.com/subject/1292052/"
}, {
    "rank": "2",
    "cover": "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2561716440.jpg",
    "title": "霸王别姬",
    "actor": "\n                            导演: 陈凯歌 Kaige Chen   主演: 张国荣 Leslie Cheung / 张丰毅 Fengyi Zha...",
    "score": "9.6",
    "display": "风华绝代。",
    "url": "https://movie.douban.com/subject/1291546/"
}, {
    "rank": "3",
    "cover": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2372307693.jpg",
    "title": "阿甘正传",
    "actor": "\n                            导演: 罗伯特·泽米吉斯 Robert Zemeckis   主演: 汤姆·汉克斯 Tom Hanks / ...",
    "score": "9.5",
    "display": "一部美国近现代史。",
    "url": "https://movie.douban.com/subject/1292720/"
}, {
    "rank": "4",
    "cover": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p511118051.jpg",
    "title": "这个杀手不太冷",
    "actor": "\n                            导演: 吕克·贝松 Luc Besson   主演: 让·雷诺 Jean Reno / 娜塔莉·波特曼 ...",
    "score": "9.4",
    "display": "怪蜀黍和小萝莉不得不说的故事。",
    "url": "https://movie.douban.com/subject/1295644/"
}, {
    "rank": "5",
    "cover": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p457760035.jpg",
    "title": "泰坦尼克号",
    "actor": "\n                            导演: 詹姆斯·卡梅隆 James Cameron   主演: 莱昂纳多·迪卡普里奥 Leonardo...",
    "score": "9.4",
    "display": "失去的才是永恒的。 ",
    "url": "https://movie.douban.com/subject/1292722/"
}, {
    "rank": "6",
    "cover": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2578474613.jpg",
    "title": "美丽人生",
    "actor": "\n                            导演: 罗伯托·贝尼尼 Roberto Benigni   主演: 罗伯托·贝尼尼 Roberto Beni...",
    "score": "9.6",
    "display": "最美的谎言。",
    "url": "https://movie.douban.com/subject/1292063/"
}, {
    "rank": "7",
    "cover": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2557573348.jpg",
    "title": "千与千寻",
    "actor": "\n                            导演: 宫崎骏 Hayao Miyazaki   主演: 柊瑠美 Rumi Hîragi / 入野自由 Miy...",
    "score": "9.4",
    "display": "最好的宫崎骏，最好的久石让。 ",
    "url": "https://movie.douban.com/subject/1291561/"
}, {
    "rank": "8",
    "cover": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p492406163.jpg",
    "title": "辛德勒的名单",
    "actor": "\n                            导演: 史蒂文·斯皮尔伯格 Steven Spielberg   主演: 连姆·尼森 Liam Neeson...",
    "score": "9.5",
    "display": "拯救一个人，就是拯救整个世界。",
    "url": "https://movie.douban.com/subject/1295124/"
}, {
    "rank": "9",
    "cover": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2616355133.jpg",
    "title": "盗梦空间",
    "actor": "\n                            导演: 克里斯托弗·诺兰 Christopher Nolan   主演: 莱昂纳多·迪卡普里奥 Le...",
    "score": "9.3",
    "display": "诺兰给了我们一场无法盗取的梦。",
    "url": "https://movie.douban.com/subject/3541415/"
}, {
    "rank": "10",
    "cover": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p524964039.jpg",
    "title": "忠犬八公的故事",
    "actor": "\n                            导演: 莱塞·霍尔斯道姆 Lasse Hallström   主演: 理查·基尔 Richard Ger...",
    "score": "9.4",
    "display": "永远都不能忘记你所爱的人。",
    "url": "https://movie.douban.com/subject/3011091/"
}, {
    "rank": "11",
    "cover": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614988097.jpg",
    "title": "星际穿越",
    "actor": "\n                            导演: 克里斯托弗·诺兰 Christopher Nolan   主演: 马修·麦康纳 Matthew Mc...",
    "score": "9.3",
    "display": "爱是一种力量，让我们超越时空感知它的存在。",
    "url": "https://movie.douban.com/subject/1889243/"
}, {
    "rank": "12",
    "cover": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p479682972.jpg",
    "title": "楚门的世界",
    "actor": "\n                            导演: 彼得·威尔 Peter Weir   主演: 金·凯瑞 Jim Carrey / 劳拉·琳妮 Lau...",
    "score": "9.3",
    "display": "如果再也不能见到你，祝你早安，午安，晚安。",
    "url": "https://movie.douban.com/subject/1292064/"
}, {
    "rank": "13",
    "cover": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2574551676.jpg",
    "title": "海上钢琴师",
    "actor": "\n                            导演: 朱塞佩·托纳多雷 Giuseppe Tornatore   主演: 蒂姆·罗斯 Tim Roth / ...",
    "score": "9.3",
    "display": "每个人都要走一条自己坚定了的路，就算是粉身碎骨。 ",
    "url": "https://movie.douban.com/subject/1292001/"
}, {
    "rank": "14",
    "cover": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p579729551.jpg",
    "title": "三傻大闹宝莱坞",
    "actor": "\n                            导演: 拉库马·希拉尼 Rajkumar Hirani   主演: 阿米尔·汗 Aamir Khan / 卡...",
    "score": "9.2",
    "display": "英俊版憨豆，高情商版谢耳朵。",
    "url": "https://movie.douban.com/subject/3793023/"
}, {
    "rank": "15",
    "cover": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p1461851991.jpg",
    "title": "机器人总动员",
    "actor": "\n                            导演: 安德鲁·斯坦顿 Andrew Stanton   主演: 本·贝尔特 Ben Burtt / 艾丽...",
    "score": "9.3",
    "display": "小瓦力，大人生。",
    "url": "https://movie.douban.com/subject/2131459/"
}, {
    "rank": "16",
    "cover": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p1910824951.jpg",
    "title": "放牛班的春天",
    "actor": "\n                            导演: 克里斯托夫·巴拉蒂 Christophe Barratier   主演: 热拉尔·朱尼奥 Gé...",
    "score": "9.3",
    "display": "天籁一般的童声，是最接近上帝的存在。 ",
    "url": "https://movie.douban.com/subject/1291549/"
}, {
    "rank": "17",
    "cover": "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2564556863.jpg",
    "title": "无间道",
    "actor": "\n                            导演: 刘伟强 / 麦兆辉   主演: 刘德华 / 梁朝伟 / 黄秋生",
    "score": "9.3",
    "display": "香港电影史上永不过时的杰作。",
    "url": "https://movie.douban.com/subject/1307914/"
}, {
    "rank": "18",
    "cover": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614500649.jpg",
    "title": "疯狂动物城",
    "actor": "\n                            导演: 拜伦·霍华德 Byron Howard / 瑞奇·摩尔 Rich Moore   主演: 金妮弗·...",
    "score": "9.2",
    "display": "迪士尼给我们营造的乌托邦就是这样，永远善良勇敢，永远出乎意料。",
    "url": "https://movie.douban.com/subject/25662329/"
}, {
    "rank": "19",
    "cover": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2455050536.jpg",
    "title": "大话西游之大圣娶亲",
    "actor": "\n                            导演: 刘镇伟 Jeffrey Lau   主演: 周星驰 Stephen Chow / 吴孟达 Man Tat Ng...",
    "score": "9.2",
    "display": "一生所爱。",
    "url": "https://movie.douban.com/subject/1292213/"
}, {
    "rank": "20",
    "cover": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1363250216.jpg",
    "title": "熔炉",
    "actor": "\n                            导演: 黄东赫 Dong-hyuk Hwang   主演: 孔侑 Yoo Gong / 郑有美 Yu-mi Jung /...",
    "score": "9.3",
    "display": "我们一路奋战不是为了改变世界，而是为了不让世界改变我们。",
    "url": "https://movie.douban.com/subject/5912992/"
}, {
    "rank": "21",
    "cover": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p616779645.jpg",
    "title": "教父",
    "actor": "\n                            导演: 弗朗西斯·福特·科波拉 Francis Ford Coppola   主演: 马龙·白兰度 M...",
    "score": "9.3",
    "display": "千万不要记恨你的对手，这样会让你失去理智。",
    "url": "https://movie.douban.com/subject/1291841/"
}, {
    "rank": "22",
    "cover": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2614359276.jpg",
    "title": "当幸福来敲门",
    "actor": "\n                            导演: 加布里尔·穆奇诺 Gabriele Muccino   主演: 威尔·史密斯 Will Smith ...",
    "score": "9.1",
    "display": "平民励志片。 ",
    "url": "https://movie.douban.com/subject/1849031/"
}, {
    "rank": "23",
    "cover": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2540924496.jpg",
    "title": "龙猫",
    "actor": "\n                            导演: 宫崎骏 Hayao Miyazaki   主演: 日高法子 Noriko Hidaka / 坂本千夏 Ch...",
    "score": "9.2",
    "display": "人人心中都有个龙猫，童年就永远不会消失。",
    "url": "https://movie.douban.com/subject/1291560/"
}, {
    "rank": "24",
    "cover": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p501177648.jpg",
    "title": "怦然心动",
    "actor": "\n                            导演: 罗伯·莱纳 Rob Reiner   主演: 玛德琳·卡罗尔 Madeline Carroll / 卡...",
    "score": "9.1",
    "display": "真正的幸福是来自内心深处。",
    "url": "https://movie.douban.com/subject/3319755/"
}, {
    "rank": "25",
    "cover": "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1505392928.jpg",
    "title": "控方证人",
    "actor": "\n                            导演: 比利·怀尔德 Billy Wilder   主演: 泰隆·鲍华 Tyrone Power / 玛琳·...",
    "score": "9.6",
    "display": "比利·怀德满分作品。",
    "url": "https://movie.douban.com/subject/1296141/"
}]

module.exports.doubanTop250 = data