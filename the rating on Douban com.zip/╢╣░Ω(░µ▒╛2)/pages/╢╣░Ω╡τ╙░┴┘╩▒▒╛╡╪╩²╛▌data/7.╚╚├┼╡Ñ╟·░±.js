let data=[
  {
    "original_price": null,
    "pubdate": [
      "2021-10-15"
    ],
    "rating": {
      "count": 5148,
      "max": 10,
      "value": 6.92956,
      "star_count": 3.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "Adele \/ 2021",
    "recommend_comment": "cheesy on me —— Blues Bill的短评",
    "id": "35621782",
    "title": "Easy On Me",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "Adele\/流行\/2021-10-15",
    "singer": [
      "Adele"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35621782\/",
    "release_date": null,
    "cover": {
      "url": "https://img9.doubanio.com\/view\/subject\/m\/public\/s34017965.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35621782",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-19"
    ],
    "rating": {
      "count": 1276,
      "max": 10,
      "value": 5.7248,
      "star_count": 3.0
    },
    "actions": [],
    "year": null,
    "card_subtitle": "IU 아이유 李知恩 \/ 2021",
    "recommend_comment": "她嗓子怎么这么难听 —— kiminimuchu的短评",
    "id": "35621284",
    "title": "strawberry moon",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "IU\/流行\/2021-10-19",
    "singer": [
      "IU"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35621284\/",
    "release_date": null,
    "cover": {
      "url": "https://img9.doubanio.com\/view\/subject\/m\/public\/s34021944.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35621284",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-18"
    ],
    "rating": {
      "count": 867,
      "max": 10,
      "value": 8.17822,
      "star_count": 4.0
    },
    "actions": [],
    "year": null,
    "card_subtitle": "鞠婧祎 \/ 2021",
    "recommend_comment": "口水歌5分高高的了 —— 某人Safety的短评",
    "id": "35629116",
    "title": "莫离",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "鞠婧祎\/流行\/2021-10-18",
    "singer": [
      "鞠婧祎"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35629116\/",
    "release_date": null,
    "cover": {
      "url": "https://img9.doubanio.com\/view\/subject\/m\/public\/s34019225.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35629116",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-14"
    ],
    "rating": {
      "count": 862,
      "max": 10,
      "value": 7.02754,
      "star_count": 3.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "艾怡良 EVe Ai \/ 2021",
    "recommend_comment": "时隔三年，艾怡良终于要带着她的新专辑《偏偏我却都记得》回来了。文案【要提起勇氣再愛之前，先好好懺悔。】，点出专辑核心词【忏悔】，表明这将是一张专注于自省的作品。拥有太多爱的本能，却用错误的方式走在爱的路上，最后落得的是满身看不懂的伤。越爱越错越伤，那么该如何停止这样的循环呢？艾怡良拿出了专辑第一波主打歌《贪》来亲手撕开那些长久隐于心中的爱之罪。 —— 英子的短评",
    "id": "35624603",
    "title": "贪",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "艾怡良 EVe Ai\/流行\/2021-10-14",
    "singer": [
      "艾怡良 EVe Ai"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35624603\/",
    "release_date": null,
    "cover": {
      "url": "https://img9.doubanio.com\/view\/subject\/m\/public\/s34017624.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35624603",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-09-30"
    ],
    "rating": {
      "count": 1102,
      "max": 10,
      "value": 8.75862,
      "star_count": 4.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "王一博 \/ 2021",
    "recommend_comment": "在舒缓弦乐和温柔奶音中，听到了晶莹闪烁的万家灯火，织连星光倾入山河，好治愈啊~~~ —— 又一村的短评",
    "id": "35620242",
    "title": "山河星光",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "王一博\/流行\/2021-09-30",
    "singer": [
      "王一博"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35620242\/",
    "release_date": null,
    "cover": {
      "url": "https://img1.doubanio.com\/view\/subject\/m\/public\/s34012598.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35620242",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-08"
    ],
    "rating": {
      "count": 974,
      "max": 10,
      "value": 8.58882,
      "star_count": 4.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "王一博 \/ 2021",
    "recommend_comment": "好听 —— ditouwenrou的短评",
    "id": "35621103",
    "title": "平凡中的不平凡",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "王一博\/流行\/2021-10-08",
    "singer": [
      "王一博"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35621103\/",
    "release_date": null,
    "cover": {
      "url": "https://img1.doubanio.com\/view\/subject\/m\/public\/s34013658.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35621103",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-20"
    ],
    "rating": {
      "count": 378,
      "max": 10,
      "value": 8.04508,
      "star_count": 4.0
    },
    "actions": [],
    "year": null,
    "card_subtitle": "王一博 \/ 2021",
    "recommend_comment": "1首歌曲，3分钟。令我反感的营销趋势不可阻挡，但我必须必可阻挡地表达我的反感。 —— 金莲喜欢银联的短评",
    "id": "35630789",
    "title": "不可阻挡",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "王一博\/流行\/2021-10-20",
    "singer": [
      "王一博"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35630789\/",
    "release_date": null,
    "cover": {
      "url": "https://img1.doubanio.com\/view\/subject\/m\/public\/s34020857.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35630789",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-09-25"
    ],
    "rating": {
      "count": 2053,
      "max": 10,
      "value": 7.70172,
      "star_count": 4.0
    },
    "actions": [],
    "year": null,
    "card_subtitle": "王菲 Faye Wong \/ 2021",
    "recommend_comment": "所以这些年唱了这么多烂词，是为了给长期使用伟文赎罪吗？ —— 舒农的短评",
    "id": "35608237",
    "title": "如愿",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "王菲 Faye Wong\/原声\/2021-09-25",
    "singer": [
      "王菲 Faye Wong"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35608237\/",
    "release_date": null,
    "cover": {
      "url": "https://img2.doubanio.com\/view\/subject\/m\/public\/s34003483.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35608237",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-21"
    ],
    "rating": {
      "count": 173,
      "max": 10,
      "value": 6.61518,
      "star_count": 3.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "蔡依林 Jolin Tsai Steve Aoki MAX \/ 2021",
    "recommend_comment": "我反而更喜欢中文版，英文版有点把蔡依林声音吃掉 —— 锐利修蕊的短评",
    "id": "35630755",
    "title": "都没差 (Equal in the Darkness)",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "蔡依林 Jolin Tsai\/电子\/2021-10-21",
    "singer": [
      "蔡依林 Jolin Tsai"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35630755\/",
    "release_date": null,
    "cover": {
      "url": "https://img2.doubanio.com\/view\/subject\/m\/public\/s34023251.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35630755",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-20"
    ],
    "rating": {
      "count": 293,
      "max": 10,
      "value": 9.01342,
      "star_count": 4.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "周深 \/ 2021",
    "recommend_comment": "救命啊，我疯了 —— 给我吧唧亲两口的短评",
    "id": "35623287",
    "title": "美好的世界",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "周深\/2021-10-20",
    "singer": [
      "周深"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35623287\/",
    "release_date": null,
    "cover": {
      "url": "https://img2.doubanio.com\/view\/subject\/m\/public\/s34021941.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35623287",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-09-23"
    ],
    "rating": {
      "count": 8157,
      "max": 10,
      "value": 7.22238,
      "star_count": 3.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "刘耀文 \/ 2021",
    "recommend_comment": "难听 —— 不搞丑人的短评",
    "id": "35604817",
    "title": "Got You",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "刘耀文\/流行\/2021-09-23",
    "singer": [
      "刘耀文"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35604817\/",
    "release_date": null,
    "cover": {
      "url": "https://img3.doubanio.com\/view\/subject\/m\/public\/s34001400.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35604817",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-18"
    ],
    "rating": {
      "count": 205,
      "max": 10,
      "value": 7.49138,
      "star_count": 3.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "傻子与白痴 Fool and Idiot \/ 2021",
    "recommend_comment": "什么玩意儿 —— 锐利修蕊的短评",
    "id": "35629699",
    "title": "OY",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "傻子与白痴 Fool and Idiot\/流行\/2021-10-18",
    "singer": [
      "傻子与白痴 Fool and Idiot"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35629699\/",
    "release_date": null,
    "cover": {
      "url": "https://img9.doubanio.com\/view\/subject\/m\/public\/s34020126.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35629699",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-22"
    ],
    "rating": {
      "count": 166,
      "max": 10,
      "value": 4.57884,
      "star_count": 2.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "DJ Snake Ozuna Megan Thee Stallion LISA \/ 2021",
    "recommend_comment": "好土好难听 —— kiminimuchu的短评",
    "id": "35629422",
    "title": "SG (Explicit)",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "DJ Snake\/流行\/2021-10-22",
    "singer": [
      "DJ Snake"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35629422\/",
    "release_date": null,
    "cover": {
      "url": "https://img9.doubanio.com\/view\/subject\/m\/public\/s34023346.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35629422",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-18"
    ],
    "rating": {
      "count": 182,
      "max": 10,
      "value": 7.39508,
      "star_count": 3.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "范丞丞 \/ 2021",
    "recommend_comment": "歌很汪苏泷 范丞丞演绎的也很范丞丞 甜蜜中带点青涩的少年心事 是范丞丞唱情歌的风格 —— 的短评",
    "id": "35630311",
    "title": "秘密",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "范丞丞\/流行\/2021-10-18",
    "singer": [
      "范丞丞"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35630311\/",
    "release_date": null,
    "cover": {
      "url": "https://img1.doubanio.com\/view\/subject\/m\/public\/s34020487.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35630311",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-12"
    ],
    "rating": {
      "count": 375,
      "max": 10,
      "value": 8.59992,
      "star_count": 4.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "周深 \/ 2021",
    "recommend_comment": "非常喜欢这首歌的和声，效果很好 —— 给我吧唧亲两口的短评",
    "id": "35622997",
    "title": "只为真相",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "周深\/原声\/2021-10-12",
    "singer": [
      "周深"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35622997\/",
    "release_date": null,
    "cover": {
      "url": "https://img1.doubanio.com\/view\/subject\/m\/public\/s34015299.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35622997",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-25"
    ],
    "rating": {
      "count": 139,
      "max": 10,
      "value": 8.8433,
      "star_count": 4.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "鞠婧祎 曾舜晞 \/ 2021",
    "recommend_comment": "剧里宁谦太好嗑了，合唱的歌曲也很好听。 —— 江湖骗子的短评",
    "id": "35637565",
    "title": "念思雨",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "鞠婧祎\/流行\/2021-10-25",
    "singer": [
      "鞠婧祎"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35637565\/",
    "release_date": null,
    "cover": {
      "url": "https://img1.doubanio.com\/view\/subject\/m\/public\/s34026008.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35637565",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-13"
    ],
    "rating": {
      "count": 256,
      "max": 10,
      "value": 6.3209,
      "star_count": 3.0
    },
    "actions": [],
    "year": null,
    "card_subtitle": "LIGHTSUM \/ 2021",
    "recommend_comment": "完全就是照着矮歌的结构模式写出来的，每个起承转合都精准模仿了，歌不差，就是这种相似度让人…… —— 夏日扬帆的短评",
    "id": "35605622",
    "title": "Light a Wish",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "LIGHTSUM\/流行\/2021-10-13",
    "singer": [
      "LIGHTSUM"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35605622\/",
    "release_date": null,
    "cover": {
      "url": "https://img3.doubanio.com\/view\/subject\/m\/public\/s34016680.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35605622",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-16"
    ],
    "rating": {
      "count": 136,
      "max": 10,
      "value": 8.57848,
      "star_count": 4.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "周深 \/ 2021",
    "recommend_comment": "温暖 —— Hello_Way的短评",
    "id": "35626793",
    "title": "最好的礼物",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "周深\/2021-10-16",
    "singer": [
      "周深"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35626793\/",
    "release_date": null,
    "cover": {
      "url": "https://img2.doubanio.com\/view\/subject\/m\/public\/s34019533.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35626793",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-09-24"
    ],
    "rating": {
      "count": 1150,
      "max": 10,
      "value": 4.93368,
      "star_count": 2.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "Coldplay 防弹少年团 BTS \/ 2021",
    "recommend_comment": "有些东西可以不用存在 —— SUBEER的短评",
    "id": "35596275",
    "title": "My Universe",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "Coldplay\/摇滚\/2021-09-24",
    "singer": [
      "Coldplay"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35596275\/",
    "release_date": null,
    "cover": {
      "url": "https://img9.doubanio.com\/view\/subject\/m\/public\/s34002515.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35596275",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  },
  {
    "original_price": null,
    "pubdate": [
      "2021-10-15"
    ],
    "rating": {
      "count": 131,
      "max": 10,
      "value": 5.13778,
      "star_count": 2.5
    },
    "actions": [],
    "year": null,
    "card_subtitle": "莫文蔚 Karen Mok \/ 2021",
    "recommend_comment": "内物比封面还糟糕。 —— 熟客思春期的短评",
    "id": "35626301",
    "title": "完美不完美",
    "label": null,
    "interest": null,
    "type": "music",
    "description": "",
    "price": null,
    "date": null,
    "info": "莫文蔚 Karen Mok\/流行\/2021-10-15",
    "singer": [
      "莫文蔚 Karen Mok"
    ],
    "url": "https:\/\/music.douban.com\/subject\/35626301\/",
    "release_date": null,
    "cover": {
      "url": "https://img2.doubanio.com\/view\/subject\/m\/public\/s34017592.jpg",
      "width": 0,
      "shape": "square",
      "height": 0
    },
    "uri": "douban:\/\/douban.com\/music\/35626301",
    "subtype": "",
    "reviewer_name": "",
    "null_rating_reason": ""
  }
]
module.exports.danqu = data