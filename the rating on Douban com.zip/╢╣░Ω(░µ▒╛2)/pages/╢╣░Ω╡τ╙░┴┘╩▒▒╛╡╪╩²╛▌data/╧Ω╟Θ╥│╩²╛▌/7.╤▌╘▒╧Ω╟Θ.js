let data={
    "directors": [
        {
            "user": null,
            "roles": [
                "导演",
                "编剧",
                "演员",
                "制片人",
                "美术"
            ],
            "latin_name": "Kaige Chen",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1023040/",
            "abstract": "陈凯歌出身于艺术家庭，少年时期经历过文革和插队。1970年，陈凯歌参军。1974年复员转业1976年到北京电...",
            "title": "陈凯歌（同名）中国,北京影视演员",
            "character": "导演",
            "uri": "douban://douban.com/celebrity/1023040?subject_id=27228768",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1451727734.81.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1451727734.81.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1451727734.81.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1023040/",
            "type": "celebrity",
            "id": "1023040",
            "name": "陈凯歌"
        },
        {
            "user": null,
            "roles": [
                "制片人",
                "编剧",
                "导演",
                "演员",
                "剪辑"
            ],
            "latin_name": "Hark Tsui",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1007152/",
            "abstract": "　　1950年2月15日生于越南西贡市，祖籍广东省海丰县，出身自华侨的大家庭，共有16名兄弟姐妹。在他十岁...",
            "title": "徐克（同名）越南,西贡影视演员",
            "character": "导演",
            "uri": "douban://douban.com/celebrity/1007152?subject_id=27212843",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p1393840734.39.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p1393840734.39.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p1393840734.39.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1007152/",
            "type": "celebrity",
            "id": "1007152",
            "name": "徐克"
        },
        {
            "user": null,
            "roles": [
                "导演",
                "编剧",
                "制片人",
                "副导演",
                "演员"
            ],
            "latin_name": "Dante Lam",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1275075/",
            "abstract": "林超贤，香港著名导演。80年代末期开始为陈嘉上做副导，从《逃学威龙》、《霹雳火》、《天地雄心》到与...",
            "title": "林超贤（同名）中国香港影视演员",
            "character": "导演",
            "uri": "douban://douban.com/celebrity/1275075?subject_id=27504161",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p1520776058.19.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p1520776058.19.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p1520776058.19.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1275075/",
            "type": "celebrity",
            "id": "1275075",
            "name": "林超贤"
        }
    ],
    "total": 131,
    "actors": [
        {
            "user": null,
            "roles": [
                "演员",
                "导演",
                "制片人",
                "编剧",
                "配音"
            ],
            "latin_name": "Jing Wu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1000525/",
            "abstract": "吴京，被誉为“功夫小子”，从1995年就开始接拍电视剧和电影，其引路人便是《少林寺》以及《少林武王》...",
            "title": "吴京（同名）中国,北京影视演员",
            "character": "饰 伍千里",
            "uri": "douban://douban.com/celebrity/1000525?subject_id=27206215",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p1569518817.34.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p1569518817.34.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p1569518817.34.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1000525/",
            "type": "celebrity",
            "id": "1000525",
            "name": "吴京"
        },
        {
            "user": null,
            "roles": [
                "演员",
                "配音",
                "音乐"
            ],
            "latin_name": "Jackson Yee",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1340022/",
            "abstract": "易烊千玺，2000年11月28日出生于湖南怀化，中国内地新生代男歌手、演员、舞者、TFBOYS成员。  2005年...",
            "title": "易烊千玺（同名）中国,湖南,怀化影视演员",
            "character": "饰 伍万里",
            "uri": "douban://douban.com/celebrity/1340022?subject_id=27489156",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p1558665007.28.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p1558665007.28.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p1558665007.28.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1340022/",
            "type": "celebrity",
            "id": "1340022",
            "name": "易烊千玺"
        },
        {
            "user": null,
            "roles": [
                "演员",
                "制片人"
            ],
            "latin_name": "Yihong Duan",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1274291/",
            "abstract": "　　段奕宏，中国男演员。从小喜欢看电影，一向调皮的段奕宏也唯独在看电影时能安静下来，有时还会和妈...",
            "title": "段奕宏（同名）中国,新疆,伊宁影视演员",
            "character": "饰 谈子为",
            "uri": "douban://douban.com/celebrity/1274291?subject_id=27480240",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1514470669.12.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1514470669.12.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1514470669.12.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1274291/",
            "type": "celebrity",
            "id": "1274291",
            "name": "段奕宏"
        },
        {
            "user": null,
            "roles": [
                "演员",
                "配音",
                "主持人"
            ],
            "latin_name": "Yawen Zhu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1312699/",
            "abstract": "朱亚文，江苏盐城人，父亲是盐城某单位局长，母亲是盐城卫校教师，一个文化之家，正在走红的朱亚文是北...",
            "title": "朱亚文（同名）中国,江苏,盐城影视演员",
            "character": "饰 梅生",
            "uri": "douban://douban.com/celebrity/1312699?subject_id=27482431",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1491562114.43.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1491562114.43.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1491562114.43.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1312699/",
            "type": "celebrity",
            "id": "1312699",
            "name": "朱亚文"
        },
        {
            "user": null,
            "roles": [
                "演员",
                "编剧",
                "配音",
                "主持人",
                "导演"
            ],
            "latin_name": "Chen Li",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1274252/",
            "abstract": "　　1997年《十七岁不哭》 17岁，刚刚考入艺术学院的李晨，还没有开始系统的表演学习，便经过数千人的竞...",
            "title": "李晨（同名）中国,北京影视演员",
            "character": "饰 余从戎",
            "uri": "douban://douban.com/celebrity/1274252?subject_id=27480237",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1537891533.92.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1537891533.92.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1537891533.92.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1274252/",
            "type": "celebrity",
            "id": "1274252",
            "name": "李晨"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Elvis Han",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1348542/",
            "abstract": "韩东君，出生于黑龙江哈尔滨市，中国内地男演员、赛车手，就读于上海戏剧学院2012级表演系。2013年正式...",
            "title": "韩东君（同名）中国,黑龙江,哈尔滨影视演员",
            "character": "饰 平河",
            "uri": "douban://douban.com/celebrity/1348542?subject_id=27503425",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1606048200.42.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1606048200.42.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1606048200.42.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1348542/",
            "type": "celebrity",
            "id": "1348542",
            "name": "韩东君"
        },
        {
            "user": null,
            "roles": [
                "演员",
                "导演",
                "配音",
                "制片人"
            ],
            "latin_name": "Jun Hu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1032540/",
            "abstract": "胡军，中国内地著名演员。1987年考入中央戏剧学院表演系，同学有徐帆、何冰、江珊、陈小艺，王斑，李洪...",
            "title": "胡军（同名）中国,北京影视演员",
            "character": "饰 雷公 / 雷睢生",
            "uri": "douban://douban.com/celebrity/1032540?subject_id=27238280",
            "cover_url": "https://img3.doubanio.com/view/celebrity/raw/public/p20960.jpg",
            "avatar": {
                "large": "https://img3.doubanio.com/view/celebrity/raw/public/p20960.jpg",
                "normal": "https://img3.doubanio.com/view/celebrity/raw/public/p20960.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1032540/",
            "type": "celebrity",
            "id": "1032540",
            "name": "胡军"
        },
        {
            "user": null,
            "roles": [
                "演员",
                "配音",
                "制片人"
            ],
            "latin_name": "Hanyu Zhang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1274319/",
            "abstract": "配音演员出身的张涵予曾为《指环王》、《特洛伊》等大片配过音，而近年也不断“触电”，在《贻笑大方》...",
            "title": "张涵予（同名）中国,北京影视演员",
            "character": "饰 宋时轮",
            "uri": "douban://douban.com/celebrity/1274319?subject_id=27496360",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p49047.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p49047.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p49047.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1274319/",
            "type": "celebrity",
            "id": "1274319",
            "name": "张涵予"
        },
        {
            "user": null,
            "roles": [
                "演员",
                "制片人"
            ],
            "latin_name": "Xuan Huang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1276105/",
            "abstract": "黄轩，青年演员。2007年他在自己的首部电影、张弛执导的《地下天空》中饰演忧郁内向的矿区少年井生，后...",
            "title": "黄轩（同名）中国,甘肃,兰州影视演员",
            "character": "饰 毛岸英",
            "uri": "douban://douban.com/celebrity/1276105?subject_id=27504421",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1623134422.73.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1623134422.73.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1623134422.73.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1276105/",
            "type": "celebrity",
            "id": "1276105",
            "name": "黄轩"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Oho Ou",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1337644/",
            "abstract": "欧豪（Oho Ou） ，1992年10月13日出生于福建省福州市平潭县，中国内地流行乐男歌手、影视演员。 2013...",
            "title": "欧豪（同名）中国,福建,福州影视演员",
            "character": "饰 杨根思",
            "uri": "douban://douban.com/celebrity/1337644?subject_id=27568621",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p1588936165.78.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p1588936165.78.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p1588936165.78.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1337644/",
            "type": "celebrity",
            "id": "1337644",
            "name": "欧豪"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Pengyuan Shi",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1342395/",
            "abstract": "史彭元，2005年8月16日出生，祖籍为素有书画之乡的辽宁北镇，电影小演员。因其形象气质与华语界著名影星...",
            "title": "史彭元（同名）辽宁省北镇市影视演员",
            "character": "饰 张小山",
            "uri": "douban://douban.com/celebrity/1342395?subject_id=27553806",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1593181458.11.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1593181458.11.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1593181458.11.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1342395/",
            "type": "celebrity",
            "id": "1342395",
            "name": "史彭元"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Mincheng Li",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1318702/",
            "abstract": "李岷城，原名李成，一直活跃在话剧舞台，成功塑造了黄凯“救赎三部曲”中的经典角色。2011年签约华谊兄...",
            "title": "李岷城（同名）中国,辽宁,盘锦影视演员",
            "character": "饰 柯大川",
            "uri": "douban://douban.com/celebrity/1318702?subject_id=27493096",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1398314807.63.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1398314807.63.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1398314807.63.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1318702/",
            "type": "celebrity",
            "id": "1318702",
            "name": "李岷城"
        },
        {
            "user": null,
            "roles": [
                "演员",
                "导演",
                "制片人",
                "编剧"
            ],
            "latin_name": "Guoqiang Tang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1152771/",
            "abstract": "唐国强，中国影视男演员。现为中国国家话剧院一级演员。曾在《南海风云》、《走在战争前面》等影片中饰...",
            "title": "唐国强（同名）中国,山东,青岛影视演员",
            "character": "饰 毛泽东",
            "uri": "douban://douban.com/celebrity/1152771?subject_id=27358652",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p37955.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p37955.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p37955.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1152771/",
            "type": "celebrity",
            "id": "1152771",
            "name": "唐国强"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Yiwei Yang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1344877/",
            "abstract": "杨一威（原名杨威），1982年出生于黑龙江，中国内地男演员，2002年毕业于中央戏剧学院。 2006年，杨一...",
            "title": "杨一威（同名）黑龙江影视演员",
            "character": "饰 何长贵",
            "uri": "douban://douban.com/celebrity/1344877?subject_id=27554176",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p1419323919.29.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p1419323919.29.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p1419323919.29.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1344877/",
            "type": "celebrity",
            "id": "1344877",
            "name": "杨一威"
        },
        {
            "user": null,
            "roles": [
                "演员",
                "导演"
            ],
            "latin_name": "Xiaobin Zhou",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1316604/",
            "abstract": "《咱家那些事》饰演王永顺",
            "title": "周小斌（同名）中国,黑龙江,齐齐哈尔影视演员",
            "character": "饰 彭德怀",
            "uri": "douban://douban.com/celebrity/1316604?subject_id=27547626",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p36956.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p36956.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p36956.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1316604/",
            "type": "celebrity",
            "id": "1316604",
            "name": "周小斌"
        },
        {
            "user": null,
            "roles": [
                "演员",
                "配音"
            ],
            "latin_name": "Yongjian Lin",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1274650/",
            "abstract": "著名演员 主要作品：《敌后武工队》、《金婚》、《高地》、《马文的战争》、《墨攻》、《王贵与安娜》",
            "title": "林永健（同名）中国,山东,青岛影视演员",
            "character": "饰 邓华",
            "uri": "douban://douban.com/celebrity/1274650?subject_id=27495167",
            "cover_url": "https://img1.doubanio.com/view/personage/raw/public/ebd75786236f19659aa03746e1cf6eea.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/personage/raw/public/ebd75786236f19659aa03746e1cf6eea.jpg",
                "normal": "https://img1.doubanio.com/view/personage/raw/public/ebd75786236f19659aa03746e1cf6eea.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1274650/",
            "type": "celebrity",
            "id": "1274650",
            "name": "林永健"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Ning Wang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1329168/",
            "abstract": "王宁，男，籍贯辽宁，北京人民艺术剧院演员。毕业于中央戏剧学院表演系87班。1991年进入北京人民艺术剧...",
            "title": "王宁（同名）中国,辽宁影视演员",
            "character": "饰 张师长",
            "uri": "douban://douban.com/celebrity/1329168?subject_id=27556902",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p1369132013.05.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p1369132013.05.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p1369132013.05.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1329168/",
            "type": "celebrity",
            "id": "1329168",
            "name": "王宁"
        },
        {
            "user": null,
            "roles": [
                "演员",
                "导演"
            ],
            "latin_name": "Jin Liu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1314473/",
            "abstract": "刘劲现为中国人民解放解放军总政治部话剧团演员，国家一级演员，中国电影家协会会员，中国电视家协会会...",
            "title": "刘劲（同名）中国,四川,阿坝影视演员",
            "character": "饰 周恩来",
            "uri": "douban://douban.com/celebrity/1314473?subject_id=27482760",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p28593.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p28593.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p28593.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1314473/",
            "type": "celebrity",
            "id": "1314473",
            "name": "刘劲"
        },
        {
            "user": null,
            "roles": [
                "演员",
                "导演"
            ],
            "latin_name": "Qi Lu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1314435/",
            "abstract": "卢奇，生于1953年，是四川甘洛人。1970年中学毕业后考入部队文工团，先后做过报幕员、拉过二胡、演过歌...",
            "title": "卢奇（同名）四川甘洛影视演员",
            "character": "饰 邓小平",
            "uri": "douban://douban.com/celebrity/1314435?subject_id=27482746",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p1553969670.25.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p1553969670.25.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p1553969670.25.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1314435/",
            "type": "celebrity",
            "id": "1314435",
            "name": "卢奇"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Wufu Wang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1314011/",
            "abstract": "王伍福，中国人民解放军北京军区战友话剧团国家一级演员。被誉为“全国第一朱德特型”。曾受到中央首长...",
            "title": "王伍福（同名）None影视演员",
            "character": "饰 朱德",
            "uri": "douban://douban.com/celebrity/1314011?subject_id=27487476",
            "cover_url": "https://img3.doubanio.com/view/celebrity/raw/public/p21300.jpg",
            "avatar": {
                "large": "https://img3.doubanio.com/view/celebrity/raw/public/p21300.jpg",
                "normal": "https://img3.doubanio.com/view/celebrity/raw/public/p21300.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1314011/",
            "type": "celebrity",
            "id": "1314011",
            "name": "王伍福"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Le Geng",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1274576/",
            "abstract": "　　耿乐，中国内地年轻男演员，拍摄电影较多的一位，据称很多导演的处女作请他担纲就是看中了他那张轮...",
            "title": "耿乐（同名）中国,北京影视演员",
            "character": "饰 老杨 / 杨营长",
            "uri": "douban://douban.com/celebrity/1274576?subject_id=27501552",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p1370503685.74.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p1370503685.74.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p1370503685.74.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1274576/",
            "type": "celebrity",
            "id": "1274576",
            "name": "耿乐"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Yang Cao",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1421020/",
            "abstract": "长春话剧院演员",
            "title": "曹阳（同名）长春影视演员",
            "character": "饰 伍母",
            "uri": "douban://douban.com/celebrity/1421020?subject_id=34785624",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1606723586.81.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1606723586.81.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1606723586.81.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1421020/",
            "type": "celebrity",
            "id": "1421020",
            "name": "曹阳"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Jun Li",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462310/",
            "abstract": "",
            "title": "李军（同名）None影视演员",
            "character": "饰 伍十里",
            "uri": "douban://douban.com/celebrity/1462310?subject_id=35613912",
            "cover_url": "https://img2.doubanio.com/view/personage/raw/public/66799f5e8c01e84735ab08ab333c8543.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/personage/raw/public/66799f5e8c01e84735ab08ab333c8543.jpg",
                "normal": "https://img2.doubanio.com/view/personage/raw/public/66799f5e8c01e84735ab08ab333c8543.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462310/",
            "type": "celebrity",
            "id": "1462310",
            "name": "李军"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Tonghui Wang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1317526/",
            "abstract": "演戏经历 　　王同辉是谁？很多人都一时想不出问题的答案。但如果告诉您他就是电视剧《二马》里的马威...",
            "title": "王同辉（同名）中国,陕西,西安影视演员",
            "character": "饰 断臂站长",
            "uri": "douban://douban.com/celebrity/1317526?subject_id=27480722",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p1621494838.98.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p1621494838.98.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p1621494838.98.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1317526/",
            "type": "celebrity",
            "id": "1317526",
            "name": "王同辉"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Aimee",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1396876/",
            "abstract": "艾米（Aimee） 生日：7月13日 职业：学生，演员 代表作：电影篇 《歌带你回家》饰演女一百灵 《侍...",
            "title": "艾米（同名）None影视演员",
            "character": "饰 红围巾女兵",
            "uri": "douban://douban.com/celebrity/1396876?subject_id=30267775",
            "cover_url": "https://img3.doubanio.com/view/personage/raw/public/227622576efabe3ef63f9fd5da7ed25d.jpg",
            "avatar": {
                "large": "https://img3.doubanio.com/view/personage/raw/public/227622576efabe3ef63f9fd5da7ed25d.jpg",
                "normal": "https://img3.doubanio.com/view/personage/raw/public/227622576efabe3ef63f9fd5da7ed25d.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1396876/",
            "type": "celebrity",
            "id": "1396876",
            "name": "艾米"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Haozheng Shi",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1352902/",
            "abstract": "毕业于中央戏剧学院。他的主要影视作品有：《天地情缘》，《雪鹰》，《乱世烟雨》，《末日情人》，《撞...",
            "title": "石昊正（同名）北京影视演员",
            "character": "饰 二排长",
            "uri": "douban://douban.com/celebrity/1352902?subject_id=27573085",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p1456715430.9.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p1456715430.9.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p1456715430.9.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1352902/",
            "type": "celebrity",
            "id": "1352902",
            "name": "石昊正"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Tiger Xu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1325510/",
            "abstract": "演员，功夫明星，原中国国家武术队、北京武术队主力队员。8岁在山东淄博齐鲁武校开始习武，2000年由李连...",
            "title": "许明虎（同名）中国,山东,淄博影视演员",
            "character": "饰 沈海龙",
            "uri": "douban://douban.com/celebrity/1325510?subject_id=27483982",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p1387981154.54.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p1387981154.54.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p1387981154.54.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1325510/",
            "type": "celebrity",
            "id": "1325510",
            "name": "许明虎"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Sha Liu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1318686/",
            "abstract": "电影《建国大业》中饰演刘少奇。",
            "title": "刘沙（同名）None影视演员",
            "character": "饰 刘少奇",
            "uri": "douban://douban.com/celebrity/1318686?subject_id=27487574",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p44163.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p44163.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p44163.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1318686/",
            "type": "celebrity",
            "id": "1318686",
            "name": "刘沙"
        },
        {
            "user": null,
            "roles": [
                "演员",
                "编剧",
                "导演"
            ],
            "latin_name": "Jian Wang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1318552/",
            "abstract": "　任弼时同志的特型演员。 　　作品 　　《任弼时》——饰演：任弼时 　　《雄关漫道》——饰演：任...",
            "title": "王健（同名）None影视演员",
            "character": "饰 任弼时",
            "uri": "douban://douban.com/celebrity/1318552?subject_id=27483354",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p44051.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p44051.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p44051.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1318552/",
            "type": "celebrity",
            "id": "1318552",
            "name": "王健"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Tieliang Wu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462282/",
            "abstract": "",
            "title": "吴铁梁 （同名）None影视演员",
            "character": "饰 董必武",
            "uri": "douban://douban.com/celebrity/1462282?subject_id=35613860",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462282/",
            "type": "celebrity",
            "id": "1462282",
            "name": "吴铁梁 "
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Xiaojun Zhang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1317609/",
            "abstract": "电视剧 2011年《追捕渣滓洞刽子手》饰演：刘文龙 导演：张辉力 陈永歌 　　 2011年《杀狼花》饰演：织...",
            "title": "张笑君（同名）中国,山东,济南影视演员",
            "character": "饰 陈云",
            "uri": "douban://douban.com/celebrity/1317609?subject_id=27547833",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p40599.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p40599.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p40599.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1317609/",
            "type": "celebrity",
            "id": "1317609",
            "name": "张笑君"
        },
        {
            "user": null,
            "roles": [
                "演员",
                "导演",
                "编剧",
                "动作捕捉"
            ],
            "latin_name": "Weidong Wu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1316547/",
            "abstract": "吴卫东，著名青年导演、编剧。1992年毕业于中央戏剧学院表演系，现任职于中国国家话剧院。 \t吴卫...",
            "title": "吴卫东（同名）None影视演员",
            "character": "饰 彭真",
            "uri": "douban://douban.com/celebrity/1316547?subject_id=27551169",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p36752.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p36752.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p36752.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1316547/",
            "type": "celebrity",
            "id": "1316547",
            "name": "吴卫东"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Huilin Zhou",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1326045/",
            "abstract": "",
            "title": "周惠林（同名）中国,江苏,连云港影视演员",
            "character": "饰 罗荣桓",
            "uri": "douban://douban.com/celebrity/1326045?subject_id=27484018",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1359615509.61.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1359615509.61.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1359615509.61.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1326045/",
            "type": "celebrity",
            "id": "1326045",
            "name": "周惠林"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Qiang He",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1330885/",
            "abstract": "贺镪，中国大陆男演员。毕业于中央戏剧学院89表干班，国家一级演员，中国电影家协会会员。出演《苦菜花...",
            "title": "贺镪（同名）None影视演员",
            "character": "饰 聂荣臻",
            "uri": "douban://douban.com/celebrity/1330885?subject_id=27484453",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p1372905131.77.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p1372905131.77.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p1372905131.77.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1330885/",
            "type": "celebrity",
            "id": "1330885",
            "name": "贺镪"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Yongzhan Zhao",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1445009/",
            "abstract": "",
            "title": "赵永占（同名）中国,河北省,邢台市,南和县影视演员",
            "character": "饰 高岗",
            "uri": "douban://douban.com/celebrity/1445009?subject_id=35208993",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p3KjSyKQtoascel_avatar_uploaded1600574094.42.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p3KjSyKQtoascel_avatar_uploaded1600574094.42.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p3KjSyKQtoascel_avatar_uploaded1600574094.42.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1445009/",
            "type": "celebrity",
            "id": "1445009",
            "name": "赵永占"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Hongtao Wang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1419000/",
            "abstract": "王洪涛,汉族，男，中国大陆男演员。身高：177cm，体重：65kg，经纪公司：华娱艺能明星经纪有限公司。 ...",
            "title": "王洪涛（同名）中国,山东,淄博影视演员",
            "character": "饰 邓子恢",
            "uri": "douban://douban.com/celebrity/1419000?subject_id=34450825",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/pMblc2143QPIcel_avatar_uploaded1561537137.44.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/pMblc2143QPIcel_avatar_uploaded1561537137.44.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/pMblc2143QPIcel_avatar_uploaded1561537137.44.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1419000/",
            "type": "celebrity",
            "id": "1419000",
            "name": "王洪涛"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Guodong Cheng",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1337225/",
            "abstract": "",
            "title": "成国栋（同名）None影视演员",
            "character": "饰 林伯渠",
            "uri": "douban://douban.com/celebrity/1337225?subject_id=27552878",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1486908387.71.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1486908387.71.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1486908387.71.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1337225/",
            "type": "celebrity",
            "id": "1337225",
            "name": "成国栋"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Jinglai Lin",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1318063/",
            "abstract": "1987年中央戏剧学院毕业。曾获第五届全军文艺戏剧汇演优秀表演奖、第一届全国电视小品大奖赛优秀表演奖...",
            "title": "林京来（同名）None影视演员",
            "character": "饰 李富春",
            "uri": "douban://douban.com/celebrity/1318063?subject_id=27483079",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p42543.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p42543.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p42543.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1318063/",
            "type": "celebrity",
            "id": "1318063",
            "name": "林京来"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Shuanzhong Chu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1318289/",
            "abstract": "电视作品 　　1997年 《危情时刻》 饰秦海 导演：滕华涛 合作演员：张国立、胡军等 　　1998年 《人子...",
            "title": "褚栓忠（同名）None影视演员",
            "character": "饰 张闻天",
            "uri": "douban://douban.com/celebrity/1318289?subject_id=27483209",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1465091353.41.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1465091353.41.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1465091353.41.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1318289/",
            "type": "celebrity",
            "id": "1318289",
            "name": "褚栓忠"
        },
        {
            "user": null,
            "roles": [
                "导演",
                "编剧",
                "演员"
            ],
            "latin_name": "Yiming Zhang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1382824/",
            "abstract": "张一鸣当代影视演员，导演，编剧，代表作品《大爱无言》、《第八辆自行车》 《爱情方程式》、《夫妻警务...",
            "title": "张一鸣（同名）江苏徐州影视演员",
            "character": "饰 胡乔木",
            "uri": "douban://douban.com/celebrity/1382824?subject_id=27582073",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p1508407813.67.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p1508407813.67.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p1508407813.67.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1382824/",
            "type": "celebrity",
            "id": "1382824",
            "name": "张一鸣"
        },
        {
            "user": null,
            "roles": [
                "美术",
                "演员"
            ],
            "latin_name": "Wei Lu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1386941/",
            "abstract": "",
            "title": "陆苇（同名）None影视演员",
            "character": "饰 杨尚昆",
            "uri": "douban://douban.com/celebrity/1386941?subject_id=27663394",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1515723040.71.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1515723040.71.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1515723040.71.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1386941/",
            "type": "celebrity",
            "id": "1386941",
            "name": "陆苇"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Zheng Tian",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1321276/",
            "abstract": "",
            "title": "田征（同名）None影视演员",
            "character": "饰 叶子龙",
            "uri": "douban://douban.com/celebrity/1321276?subject_id=27566516",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p1478331015.15.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p1478331015.15.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p1478331015.15.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1321276/",
            "type": "celebrity",
            "id": "1321276",
            "name": "田征"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Ningjiang Zhang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1321998/",
            "abstract": "张宁江，昵称小5，中国内地男演员，毕业于上海戏剧学院04级导本。代表作品有：电视剧《永不磨灭的番号》...",
            "title": "张宁江（同名）中国,浙江,嘉兴影视演员",
            "character": "饰 雷英夫",
            "uri": "douban://douban.com/celebrity/1321998?subject_id=27497512",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1566725235.82.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1566725235.82.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1566725235.82.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1321998/",
            "type": "celebrity",
            "id": "1321998",
            "name": "张宁江"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Yi Gang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1317991/",
            "abstract": "电视剧作品 　　《媳妇的美好时代》饰 旺发（潘美丽姐夫） 　　《黎明之前》饰 丁三 导演：刘江 合...",
            "title": "刚毅（同名）None影视演员",
            "character": "饰 洪学智",
            "uri": "douban://douban.com/celebrity/1317991?subject_id=27483019",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p42005.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p42005.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p42005.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1317991/",
            "type": "celebrity",
            "id": "1317991",
            "name": "刚毅"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Yanyang Wang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1351876/",
            "abstract": "王燕阳，1991年出生于山东青岛，中国内地男演员，毕业于北京电影学院。 2013年拍摄了古装大剧《琅琊榜》...",
            "title": "王燕阳（同名）山东青岛影视演员",
            "character": "饰 杨凤安",
            "uri": "douban://douban.com/celebrity/1351876?subject_id=27555572",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p1599788782.74.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p1599788782.74.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p1599788782.74.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1351876/",
            "type": "celebrity",
            "id": "1351876",
            "name": "王燕阳"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Xin Cai",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1404238/",
            "abstract": "",
            "title": "蔡心（同名）中国,北京影视演员",
            "character": "饰 高瑞欣",
            "uri": "douban://douban.com/celebrity/1404238?subject_id=30374945",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p1541821769.45.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p1541821769.45.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p1541821769.45.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1404238/",
            "type": "celebrity",
            "id": "1404238",
            "name": "蔡心"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Boyang Sun",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1357759/",
            "abstract": "",
            "title": "孙渤洋（同名）None影视演员",
            "character": "饰 参谋",
            "uri": "douban://douban.com/celebrity/1357759?subject_id=27576204",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p1465886350.59.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p1465886350.59.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p1465886350.59.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1357759/",
            "type": "celebrity",
            "id": "1357759",
            "name": "孙渤洋"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Jian Guo",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462283/",
            "abstract": "",
            "title": "郭建 （同名）None影视演员",
            "character": "饰 陶勇",
            "uri": "douban://douban.com/celebrity/1462283?subject_id=35613861",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462283/",
            "type": "celebrity",
            "id": "1462283",
            "name": "郭建 "
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1406636/",
            "abstract": "",
            "title": "李易泽（同名）None影视演员",
            "character": "饰 副参谋长",
            "uri": "douban://douban.com/celebrity/1406636?subject_id=30402154",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1544683093.63.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1544683093.63.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1544683093.63.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1406636/",
            "type": "celebrity",
            "id": "1406636",
            "name": "李易泽"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Lu Dai",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462284/",
            "abstract": "",
            "title": "戴路 （同名）None影视演员",
            "character": "饰 师参谋长",
            "uri": "douban://douban.com/celebrity/1462284?subject_id=35613862",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462284/",
            "type": "celebrity",
            "id": "1462284",
            "name": "戴路 "
        },
        {
            "user": null,
            "roles": [
                "演员",
                "配音"
            ],
            "latin_name": "Zhidong Na",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1326482/",
            "abstract": "",
            "title": "那志东（同名）None影视演员",
            "character": "饰 覃健",
            "uri": "douban://douban.com/celebrity/1326482?subject_id=27484082",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1502006286.61.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1502006286.61.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1502006286.61.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1326482/",
            "type": "celebrity",
            "id": "1326482",
            "name": "那志东"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Xinjie Liu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1408058/",
            "abstract": "2018年10月，出演电视剧《烈火战马》； 2018年11月，出演电影《盗客联盟》； 2018年，出演《古董局中...",
            "title": "刘欣杰（同名）中国影视演员",
            "character": "饰 谢有法",
            "uri": "douban://douban.com/celebrity/1408058?subject_id=30419572",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/pwIbvk0dJEiwcel_avatar_uploaded1546330453.76.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/pwIbvk0dJEiwcel_avatar_uploaded1546330453.76.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/pwIbvk0dJEiwcel_avatar_uploaded1546330453.76.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1408058/",
            "type": "celebrity",
            "id": "1408058",
            "name": "刘欣杰"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Bo Li",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1318613/",
            "abstract": "主要作品 　　《红岩》饰 胡浩 　　《血色浪漫》 客串 　　《激情燃烧的岁月》饰　小伍子 　　《...",
            "title": "李博（同名）中国,吉林影视演员",
            "character": "饰 张翼翔",
            "uri": "douban://douban.com/celebrity/1318613?subject_id=27483379",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p1377682919.66.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p1377682919.66.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p1377682919.66.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1318613/",
            "type": "celebrity",
            "id": "1318613",
            "name": "李博"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Bowei Han",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1402524/",
            "abstract": "",
            "title": "韩伯维（同名）None影视演员",
            "character": "饰 廖政国",
            "uri": "douban://douban.com/celebrity/1402524?subject_id=30347864",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p1543493445.6.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p1543493445.6.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p1543493445.6.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1402524/",
            "type": "celebrity",
            "id": "1402524",
            "name": "韩伯维"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Xinggang Jia",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462285/",
            "abstract": "",
            "title": "贾兴钢（同名）None影视演员",
            "character": "饰 张仁初",
            "uri": "douban://douban.com/celebrity/1462285?subject_id=35613863",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462285/",
            "type": "celebrity",
            "id": "1462285",
            "name": "贾兴钢"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Peng Yan",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1433697/",
            "abstract": "",
            "title": "闫鹏（同名）None影视演员",
            "character": "饰 李耀文",
            "uri": "douban://douban.com/celebrity/1433697?subject_id=34990598",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p1583929301.27.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p1583929301.27.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p1583929301.27.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1433697/",
            "type": "celebrity",
            "id": "1433697",
            "name": "闫鹏"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Lei Shi",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1330939/",
            "abstract": "史磊，中国内地小童星，主要作品有《中国式离婚》、 《家有宝贝》、《无极》、《麻辣女友》、《一江水谁...",
            "title": "史磊（同名）None影视演员",
            "character": "饰 彭德清",
            "uri": "douban://douban.com/celebrity/1330939?subject_id=27484458",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p1519046304.06.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p1519046304.06.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p1519046304.06.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1330939/",
            "type": "celebrity",
            "id": "1330939",
            "name": "史磊"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Guanqi Wang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1387972/",
            "abstract": "王冠淇（David King），原名王笑，1981年8月9日出生于黑龙江省哈尔滨市，中国内地影视男演员、模特，毕...",
            "title": "王冠淇（同名）中国,黑龙江,哈尔滨影视演员",
            "character": "饰 刘浩天",
            "uri": "douban://douban.com/celebrity/1387972?subject_id=30135179",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p1517400689.09.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p1517400689.09.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p1517400689.09.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1387972/",
            "type": "celebrity",
            "id": "1387972",
            "name": "王冠淇"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Zhigang Wang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1343119/",
            "abstract": "王志刚，1962年出生于黑龙江哈尔滨，毕业于上海戏剧学院，现为知名话剧演员。",
            "title": "王志刚（同名）中国,黑龙江,哈尔滨影视演员",
            "character": "饰 参谋",
            "uri": "douban://douban.com/celebrity/1343119?subject_id=27565381",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p63AMQsVBLj0cel_avatar_uploaded1410617297.37.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p63AMQsVBLj0cel_avatar_uploaded1410617297.37.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p63AMQsVBLj0cel_avatar_uploaded1410617297.37.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1343119/",
            "type": "celebrity",
            "id": "1343119",
            "name": "王志刚"
        },
        {
            "user": null,
            "roles": [
                "导演",
                "演员",
                "编剧"
            ],
            "latin_name": "Zilong Wang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1461607/",
            "abstract": "",
            "title": "王子龙（同名）None影视演员",
            "character": "饰 警卫员",
            "uri": "douban://douban.com/celebrity/1461607?subject_id=35593283",
            "cover_url": "https://img1.doubanio.com/view/personage/raw/public/4d029643f1e26806a84e5b8d6b425ba7.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/personage/raw/public/4d029643f1e26806a84e5b8d6b425ba7.jpg",
                "normal": "https://img1.doubanio.com/view/personage/raw/public/4d029643f1e26806a84e5b8d6b425ba7.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1461607/",
            "type": "celebrity",
            "id": "1461607",
            "name": "王子龙"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Chenyin Zhang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1434991/",
            "abstract": "张晨音，中国内地男演员。1993年5月生，四川南充人。2009年考入四川音乐学院影视表演专业。主要作品有《...",
            "title": "张晨音（同名）中国,四川,南充影视演员",
            "character": "饰 警卫员",
            "uri": "douban://douban.com/celebrity/1434991?subject_id=35011426",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1606639678.83.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1606639678.83.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1606639678.83.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1434991/",
            "type": "celebrity",
            "id": "1434991",
            "name": "张晨音"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Dongjian Wu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462286/",
            "abstract": "",
            "title": "吴东健（同名）None影视演员",
            "character": "饰 警卫员",
            "uri": "douban://douban.com/celebrity/1462286?subject_id=35613865",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462286/",
            "type": "celebrity",
            "id": "1462286",
            "name": "吴东健"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1424102/",
            "abstract": "李卓扬：1998年12月16日出生于黑龙江省佳木斯市，曾参与张艺谋导演执导的《影》，在电影《迷失1231》中...",
            "title": "李卓扬（同名）黑龙江，佳木斯影视演员",
            "character": "饰 李持正",
            "uri": "douban://douban.com/celebrity/1424102?subject_id=34853486",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/ph6LTVP6fzMkcel_avatar_uploaded1569364332.15.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/ph6LTVP6fzMkcel_avatar_uploaded1569364332.15.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/ph6LTVP6fzMkcel_avatar_uploaded1569364332.15.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1424102/",
            "type": "celebrity",
            "id": "1424102",
            "name": "李卓扬"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Zhiwei Liu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462287/",
            "abstract": "",
            "title": "刘治威（同名）None影视演员",
            "character": "饰 奇天行",
            "uri": "douban://douban.com/celebrity/1462287?subject_id=35613867",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462287/",
            "type": "celebrity",
            "id": "1462287",
            "name": "刘治威"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Yuefei He",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462288/",
            "abstract": "",
            "title": "何跃飞（同名）None影视演员",
            "character": "饰 广福生",
            "uri": "douban://douban.com/celebrity/1462288?subject_id=35613869",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462288/",
            "type": "celebrity",
            "id": "1462288",
            "name": "何跃飞"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Zhiqiang Tang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462289/",
            "abstract": "",
            "title": "唐志强（同名）None影视演员",
            "character": "饰 周捷行",
            "uri": "douban://douban.com/celebrity/1462289?subject_id=35613870",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462289/",
            "type": "celebrity",
            "id": "1462289",
            "name": "唐志强"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Xueliang Hu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462290/",
            "abstract": "",
            "title": "胡学良（同名）None影视演员",
            "character": "饰 宋庆生",
            "uri": "douban://douban.com/celebrity/1462290?subject_id=35613871",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462290/",
            "type": "celebrity",
            "id": "1462290",
            "name": "胡学良"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Yubo Xin",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462291/",
            "abstract": "",
            "title": "辛玉波（同名）None影视演员",
            "character": "饰 尹海峰",
            "uri": "douban://douban.com/celebrity/1462291?subject_id=35613872",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462291/",
            "type": "celebrity",
            "id": "1462291",
            "name": "辛玉波"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Yue Zhang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462292/",
            "abstract": "",
            "title": "张跃（同名）None影视演员",
            "character": "饰 刘志毅",
            "uri": "douban://douban.com/celebrity/1462292?subject_id=35613873",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462292/",
            "type": "celebrity",
            "id": "1462292",
            "name": "张跃"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Guangzhi He",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462293/",
            "abstract": "",
            "title": "贺广治 （同名）None影视演员",
            "character": "饰 古沧州",
            "uri": "douban://douban.com/celebrity/1462293?subject_id=35613913",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462293/",
            "type": "celebrity",
            "id": "1462293",
            "name": "贺广治 "
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Jingda Xie",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462294/",
            "abstract": "",
            "title": "谢京达（同名）None影视演员",
            "character": "饰 陈初生",
            "uri": "douban://douban.com/celebrity/1462294?subject_id=35613876",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462294/",
            "type": "celebrity",
            "id": "1462294",
            "name": "谢京达"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Lei Zhang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462295/",
            "abstract": "",
            "title": "张镭（同名）None影视演员",
            "character": "饰 李茂才",
            "uri": "douban://douban.com/celebrity/1462295?subject_id=35613878",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462295/",
            "type": "celebrity",
            "id": "1462295",
            "name": "张镭"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Jintong Liu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462296/",
            "abstract": "",
            "title": "刘津彤（同名）None影视演员",
            "character": "饰 宣强",
            "uri": "douban://douban.com/celebrity/1462296?subject_id=35613879",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462296/",
            "type": "celebrity",
            "id": "1462296",
            "name": "刘津彤"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Xiaohang Huang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462297/",
            "abstract": "",
            "title": "黄晓航（同名）None影视演员",
            "character": "饰 魏前进",
            "uri": "douban://douban.com/celebrity/1462297?subject_id=35613881",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462297/",
            "type": "celebrity",
            "id": "1462297",
            "name": "黄晓航"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462298/",
            "abstract": "",
            "title": "曹敖日格勒（同名）None影视演员",
            "character": "饰 望丁",
            "uri": "douban://douban.com/celebrity/1462298?subject_id=35613882",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462298/",
            "type": "celebrity",
            "id": "1462298",
            "name": "曹敖日格勒"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Zhikun Zhang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462299/",
            "abstract": "",
            "title": "张志坤（同名）None影视演员",
            "character": "饰 高大山",
            "uri": "douban://douban.com/celebrity/1462299?subject_id=35613883",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462299/",
            "type": "celebrity",
            "id": "1462299",
            "name": "张志坤"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Xiaolei Zhang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462300/",
            "abstract": "",
            "title": "章小磊（同名）None影视演员",
            "character": "饰 方华彰",
            "uri": "douban://douban.com/celebrity/1462300?subject_id=35613885",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462300/",
            "type": "celebrity",
            "id": "1462300",
            "name": "章小磊"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Yuechen Song",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462301/",
            "abstract": "",
            "title": "宋玉臣（同名）None影视演员",
            "character": "饰 梁有地 / 梁实",
            "uri": "douban://douban.com/celebrity/1462301?subject_id=35613887",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462301/",
            "type": "celebrity",
            "id": "1462301",
            "name": "宋玉臣"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Zhanzhan Pan",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462302/",
            "abstract": "",
            "title": "潘展展（同名）None影视演员",
            "character": "饰 魏前进",
            "uri": "douban://douban.com/celebrity/1462302?subject_id=35613888",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462302/",
            "type": "celebrity",
            "id": "1462302",
            "name": "潘展展"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Yi Sun",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462303/",
            "abstract": "",
            "title": "孙毅（同名）None影视演员",
            "character": "饰 小叶",
            "uri": "douban://douban.com/celebrity/1462303?subject_id=35613889",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462303/",
            "type": "celebrity",
            "id": "1462303",
            "name": "孙毅"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Xiaolong Zhuang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1361307/",
            "abstract": "",
            "title": "庄小龙（同名）None影视演员",
            "character": "饰 杨文健",
            "uri": "douban://douban.com/celebrity/1361307?subject_id=27578840",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1500605258.11.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1500605258.11.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1500605258.11.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1361307/",
            "type": "celebrity",
            "id": "1361307",
            "name": "庄小龙"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Zhenwei Wang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1331393/",
            "abstract": "",
            "title": "王振威（同名）中国,河北,邯郸影视演员",
            "character": "饰 吴秋生",
            "uri": "douban://douban.com/celebrity/1331393?subject_id=27482395",
            "cover_url": "https://img1.doubanio.com/view/celebrity/raw/public/p1610326881.39.jpg",
            "avatar": {
                "large": "https://img1.doubanio.com/view/celebrity/raw/public/p1610326881.39.jpg",
                "normal": "https://img1.doubanio.com/view/celebrity/raw/public/p1610326881.39.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1331393/",
            "type": "celebrity",
            "id": "1331393",
            "name": "王振威"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Zexuan Chen",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1405579/",
            "abstract": "艺考期间，以素人考生身份受到关注。 2017年9月入学就读于北京电影学院表演系本科班； 2018年11月参加...",
            "title": "陈泽轩（同名）中国,重庆影视演员",
            "character": "饰 田向南",
            "uri": "douban://douban.com/celebrity/1405579?subject_id=30390275",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p1614661136.96.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p1614661136.96.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p1614661136.96.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1405579/",
            "type": "celebrity",
            "id": "1405579",
            "name": "陈泽轩"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Xiaofeng Li",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462304/",
            "abstract": "",
            "title": "李小锋（同名）None影视演员",
            "character": "饰 钟定一",
            "uri": "douban://douban.com/celebrity/1462304?subject_id=35613890",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462304/",
            "type": "celebrity",
            "id": "1462304",
            "name": "李小锋"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Yhan Zhao",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462305/",
            "abstract": "",
            "title": "赵亦涵（同名）None影视演员",
            "character": "饰 王凯",
            "uri": "douban://douban.com/celebrity/1462305?subject_id=35613891",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462305/",
            "type": "celebrity",
            "id": "1462305",
            "name": "赵亦涵"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Yubo Zhang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462306/",
            "abstract": "",
            "title": "张玉波（同名）None影视演员",
            "character": "饰 魏威",
            "uri": "douban://douban.com/celebrity/1462306?subject_id=35613893",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462306/",
            "type": "celebrity",
            "id": "1462306",
            "name": "张玉波"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Xiu Zhang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462307/",
            "abstract": "",
            "title": "张修（同名）None影视演员",
            "character": "饰 贾民生",
            "uri": "douban://douban.com/celebrity/1462307?subject_id=35613894",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462307/",
            "type": "celebrity",
            "id": "1462307",
            "name": "张修"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Linsen Tang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462308/",
            "abstract": "",
            "title": "唐琳森（同名）None影视演员",
            "character": "饰 崔小飞",
            "uri": "douban://douban.com/celebrity/1462308?subject_id=35613895",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462308/",
            "type": "celebrity",
            "id": "1462308",
            "name": "唐琳森"
        },
        {
            "user": {
                "loc": {
                    "id": "108288",
                    "name": "北京",
                    "uid": "beijing"
                },
                "remark": "",
                "followed": false,
                "name": "朱光明",
                "avatar_side_icon": "",
                "url": "https://www.douban.com/people/214517230/",
                "verify_type": 4,
                "abstract": "",
                "reg_time": "2020-04-04 09:21:21",
                "avatar": "https://img2.doubanio.com/icon/up214517230-2.jpg",
                "uri": "douban://douban.com/user/214517230",
                "medal_groups": [],
                "is_club": false,
                "followers_count": 48,
                "in_blacklist": false,
                "id": "214517230",
                "is_banned": false,
                "type": "user",
                "kind": "user",
                "uid": "214517230"
            },
            "roles": [
                "演员"
            ],
            "latin_name": "Guangming Zhu",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462309/",
            "abstract": "",
            "title": "朱光明（同名）None影视演员",
            "character": "饰 唐茂林",
            "uri": "douban://douban.com/celebrity/1462309?subject_id=35613896",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462309/",
            "type": "celebrity",
            "id": "1462309",
            "name": "朱光明"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Yuanzhang Yin",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1399313/",
            "abstract": "尹元章，中国内地男演员。1984年考入连云港市艺术学校话剧班（中央戏剧学院连云港班），1986年毕业后分...",
            "title": "尹元章（同名）中国,江苏,连云港影视演员",
            "character": "饰 艄公",
            "uri": "douban://douban.com/celebrity/1399313?subject_id=30302217",
            "cover_url": "https://img2.doubanio.com/view/celebrity/raw/public/p1551185976.63.jpg",
            "avatar": {
                "large": "https://img2.doubanio.com/view/celebrity/raw/public/p1551185976.63.jpg",
                "normal": "https://img2.doubanio.com/view/celebrity/raw/public/p1551185976.63.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1399313/",
            "type": "celebrity",
            "id": "1399313",
            "name": "尹元章"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Xiaolin Jiang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462311/",
            "abstract": "",
            "title": "蒋潇林（同名）None影视演员",
            "character": "饰 通信员",
            "uri": "douban://douban.com/celebrity/1462311?subject_id=35613899",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462311/",
            "type": "celebrity",
            "id": "1462311",
            "name": "蒋潇林"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Zhiqin Zhang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1414825/",
            "abstract": "",
            "title": "张志勤（同名）None影视演员",
            "character": "饰 师长",
            "uri": "douban://douban.com/celebrity/1414825?subject_id=33413070",
            "cover_url": "https://img9.doubanio.com/view/celebrity/raw/public/p1555418489.16.jpg",
            "avatar": {
                "large": "https://img9.doubanio.com/view/celebrity/raw/public/p1555418489.16.jpg",
                "normal": "https://img9.doubanio.com/view/celebrity/raw/public/p1555418489.16.jpg"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1414825/",
            "type": "celebrity",
            "id": "1414825",
            "name": "张志勤"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Yi Cheng",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462312/",
            "abstract": "",
            "title": "程亦（同名）None影视演员",
            "character": "饰 师长传令兵",
            "uri": "douban://douban.com/celebrity/1462312?subject_id=35613901",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462312/",
            "type": "celebrity",
            "id": "1462312",
            "name": "程亦"
        },
        {
            "user": null,
            "roles": [
                "演员"
            ],
            "latin_name": "Can Yang",
            "author": null,
            "url": "https://movie.douban.com/celebrity/1462313/",
            "abstract": "",
            "title": "杨灿（同名）None影视演员",
            "character": "饰 车厢内传令兵",
            "uri": "douban://douban.com/celebrity/1462313?subject_id=35613902",
            "cover_url": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png",
            "avatar": {
                "large": "https://img2.doubanio.com/f/movie/63acc16ca6309ef191f0378faf793d1096a3e606/pics/movie/celebrity-default-large.png",
                "normal": "https://img1.doubanio.com/f/movie/8dd0c794499fe925ae2ae89ee30cd225750457b4/pics/movie/celebrity-default-medium.png"
            },
            "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/celebrity/1462313/",
            "type": "celebrity",
            "id": "1462313",
            "name": "杨灿"
        }
    ]
}
module.exports.yanyuan=data