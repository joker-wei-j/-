﻿let data=[{
    "rating": {
        "count": 425443,
        "max": 10,
        "star_count": 3.5,
        "value": 7.4
    },
    "lineticket_url": "douban://douban.com/movie/25845392/ticket",
    "controversy_reason": "",
    "pubdate": [
        "2021-09-30(中国大陆)"
    ],
    "last_episode_number": null,
    "pic": {
        "large": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2681329386.jpg",
        "normal": "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2681329386.jpg"
    },
    "vendor_count": 0,
    "body_bg_color": "f4f6f9",
    "is_tv": false,
    "head_info": null,
    "intro": "电影以抗美援朝战争第二次战役中的长津湖战役为背景，讲述了一段波澜壮阔的历史：71年前，中国人民志愿军赴朝作战，在极寒严酷环境下，东线作战部队凭着钢铁意志和英勇无畏的战斗精神一路追击，奋勇杀敌，扭转了战场态势，打出了军威国威。",
    "ticket_price_info": "",
    "vendor_icons": [],
    "year": "2021",
    "card_subtitle": "2021 / 中国大陆 中国香港 / 剧情 历史 战争 / 陈凯歌 徐克 林超贤 / 吴京 易烊千玺",
    "forum_info": null,
    "webisode": null,
    "id": "25845392",
    "is_restrictive": false,
    "gallery_topic_count": 0,
    "languages": [
        "汉语普通话",
        "英语"
    ],
    "genres": [
        "剧情",
        "历史",
        "战争"
    ],
    "can_interact": true,
    "review_count": 562,
    "title": "长津湖",
    "has_linewatch": false,
    "ugc_tabs": [
        {
            "source": "reviews",
            "type": "review",
            "title": "影评"
        }
    ],
    "forum_topic_count": 0,
    "webview_info": {},
    "is_released": true,
    "vendors": [],
    "actors": [
        {
            "name": "吴京"
        },
        {
            "name": "易烊千玺"
        },
        {
            "name": "段奕宏"
        },
        {
            "name": "朱亚文"
        },
        {
            "name": "李晨"
        },
        {
            "name": "韩东君"
        },
        {
            "name": "胡军"
        },
        {
            "name": "张涵予"
        },
        {
            "name": "黄轩"
        },
        {
            "name": "欧豪"
        },
        {
            "name": "史彭元"
        },
        {
            "name": "李岷城"
        },
        {
            "name": "唐国强"
        },
        {
            "name": "杨一威"
        },
        {
            "name": "周小斌"
        },
        {
            "name": "林永健"
        },
        {
            "name": "王宁"
        },
        {
            "name": "刘劲"
        },
        {
            "name": "卢奇"
        },
        {
            "name": "王伍福"
        },
        {
            "name": "耿乐"
        },
        {
            "name": "曹阳"
        },
        {
            "name": "李军"
        },
        {
            "name": "王同辉"
        },
        {
            "name": "艾米"
        },
        {
            "name": "石昊正"
        },
        {
            "name": "许明虎"
        }
    ],
    "interest": null,
    "episodes_count": 0,
    "color_scheme": {
        "is_dark": true,
        "primary_color_light": "8c92a5",
        "_base_color": [
            0.6282051282051283,
            0.1494252873563218,
            0.3411764705882353
        ],
        "secondary_color": "f4f6f9",
        "_avg_color": [
            0.6333333333333334,
            0.07194244604316542,
            0.5450980392156862
        ],
        "primary_color_dark": "6c707f"
    },
    "type": "movie",
    "null_rating_reason": "",
    "linewatches": [],
    "info_url": "https://www.douban.com/doubanapp//h5/movie/25845392/desc",
    "tags": [
        {
            "name": "战争",
            "uri": "douban://douban.com/channel/30168698"
        },
        {
            "name": "历史",
            "uri": "douban://douban.com/channel/30168934"
        },
        {
            "name": "国产",
            "uri": "douban://douban.com/channel/30307315"
        },
        {
            "name": "剧情片",
            "uri": "douban://douban.com/channel/30307495"
        },
        {
            "name": "动作片",
            "uri": "douban://douban.com/channel/30168848"
        },
        {
            "name": "爱国",
            "uri": "douban://douban.com/channel/30307946"
        },
        {
            "name": "热血",
            "uri": "douban://douban.com/channel/30308353"
        },
        {
            "name": "真实事件改编",
            "uri": "douban://douban.com/channel/30307558"
        }
    ],
    "durations": [
        "176分钟"
    ],
    "comment_count": 177950,
    "cover": {
        "description": "",
        "author": {
            "loc": {
                "id": "118237",
                "name": "郑州",
                "uid": "zhengzhou"
            },
            "kind": "user",
            "name": "小小豪力",
            "url": "https://www.douban.com/people/201194055/",
            "id": "201194055",
            "reg_time": "2019-08-05 21:23:38",
            "uri": "douban://douban.com/user/201194055",
            "avatar": "https://img2.doubanio.com/icon/up201194055-3.jpg",
            "is_club": false,
            "type": "user",
            "avatar_side_icon": "",
            "uid": "201194055"
        },
        "url": "https://movie.douban.com/photos/photo/2681329386/",
        "image": {
            "large": {
                "url": "https://img9.doubanio.com/view/photo/l/public/p2681329386.jpg",
                "width": 1080,
                "height": 1513,
                "size": 0
            },
            "raw": null,
            "small": {
                "url": "https://img9.doubanio.com/view/photo/s/public/p2681329386.jpg",
                "width": 428,
                "height": 600,
                "size": 0
            },
            "is_animated": false,
            "normal": {
                "url": "https://img9.doubanio.com/view/photo/m/public/p2681329386.jpg",
                "width": 428,
                "height": 600,
                "size": 0
            }
        },
        "uri": "douban://douban.com/photo/2681329386",
        "create_time": "2021-09-10 10:01:58",
        "position": 0,
        "owner_uri": "douban://douban.com/movie/25845392",
        "type": "photo",
        "id": "2681329386",
        "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/photo/2681329386/"
    },
    "cover_url": "https://img9.doubanio.com/view/photo/m_ratio_poster/public/p2681329386.jpg",
    "restrictive_icon_url": "",
    "header_bg_color": "6c707f",
    "is_douban_intro": false,
    "honor_infos": [],
    "sharing_url": "https://movie.douban.com/subject/25845392/",
    "subject_collections": [],
    "wechat_timeline_share": "screenshot",
    "countries": [
        "中国大陆",
        "中国香港"
    ],
    "url": "https://movie.douban.com/subject/25845392/",
    "release_date": null,
    "original_title": "",
    "uri": "douban://douban.com/movie/25845392",
    "pre_playable_date": null,
    "episodes_info": "",
    "subtype": "movie",
    "directors": [
        {
            "name": "陈凯歌"
        },
        {
            "name": "徐克"
        },
        {
            "name": "林超贤"
        }
    ],
    "is_show": false,
    "in_blacklist": false,
    "pre_release_desc": "",
    "video": null,
    "aka": [
        "冰雪长津湖",
        "抗美援朝",
        "长津湖之战",
        "The Battle at Lake Changjin",
        "Battle of Chosin Reservior"
    ],
    "webisode_count": 0,
    "trailer": {
        "sharing_url": "https://www.douban.com/doubanapp/dispatch?uri=/movie/25845392/trailer?trailer_id=281094&trailer_type=A",
        "video_url": "https://vt1.doubanio.com/202110221636/8ba77d568b10f7c8d28e6f58323a0d2a/view/movie/M/402810094.mp4",
        "title": "预告片：战火洗礼版 (中文字幕)",
        "uri": "douban://douban.com/movie/25845392/trailer?trailer_id=281094&trailer_type=A",
        "cover_url": "https://img9.doubanio.com/img/trailer/medium/2686691726.jpg?",
        "term_num": 0,
        "n_comments": 208,
        "create_time": "2021-09-24",
        "subject_title": "长津湖",
        "file_size": 24005293,
        "runtime": "01:37",
        "type": "A",
        "id": "281094",
        "desc": ""
    }
}]
module.exports.xiangqing=data