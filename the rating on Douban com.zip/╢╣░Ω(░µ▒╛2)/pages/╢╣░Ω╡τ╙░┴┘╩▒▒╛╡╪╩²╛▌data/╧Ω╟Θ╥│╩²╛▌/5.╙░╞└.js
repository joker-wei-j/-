let data={
    "count": 20,
    "start": 0,
    "total": 562,
    "reviews": [
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 2,
                "value": 2
            },
            "useful_count": 1513,
            "sharing_url": "https://movie.douban.com/review/13899235/",
            "title": "只能说一般了",
            "url": "https://movie.douban.com/review/13899235/",
            "abstract": "看了长津湖，先来说说长津湖\r\n前期这部片子宣传 造势都很强 据说投资大  成本高 又是3位比较有名的导演制作 于是抱着值得一看的心态去看了\r\n整个故事情节很散  可以说没有一个完整的情节闭合 当我感觉马上要到最精彩的地方的时候就莫名结束了 一上来就打 观影的整个过程脑壳里充满了枪声 炮声 我不否认制作团体想通过这种直接的描述战争的惨烈程度来刻画敌我双方的军事技术和装备的悬殊 也强烈表达了我国志愿军不畏困难 誓死保卫祖国的坚决和勇敢 但是情节前后不连贯 真个情节过程就像开车一样 不管你晕不晕 反正...",
            "uri": "douban://douban.com/review/13899235",
            "ad_info": null,
            "topic": null,
            "photos": [],
            "reactions_count": 1,
            "comments_count": 1066,
            "user": {
                "kind": "user",
                "name": "豆友228013347",
                "url": "https://www.douban.com/people/228013347/",
                "uri": "douban://douban.com/user/228013347",
                "avatar": "https://img2.doubanio.com/icon/up228013347-1.jpg",
                "is_club": false,
                "type": "user",
                "id": "228013347",
                "uid": "228013347"
            },
            "create_time": "2021-10-02 21:49:17",
            "reshares_count": 6,
            "type": "review",
            "id": "13899235",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 5,
                "value": 5
            },
            "useful_count": 1842,
            "sharing_url": "https://movie.douban.com/review/13894075/",
            "title": "写在烈士纪念日的今天",
            "url": "https://movie.douban.com/review/13894075/",
            "abstract": "长津湖好哭的点其实不是硬煽情，\r\n影片节奏还挺快的，特别是进入战斗部分之后，一场战斗结束，你还没来得及哭，战士们已经进入下一个阶段了。\r\n因为影片没有预备时间给观众流泪，所以观影中，我只感到震撼、憋屈、以及联与当今现实对照的感慨。\r\n片中，因为没有制空权，我们还没奔赴前线的战士被敌机当成赌注一样玩闹扫射。不满十九岁的小山和一群战友的命，竟然只值十美元。\r\n因为没有制空权，我们甚至连中心指挥所都被敌机炸掉，将军躲防空洞，领袖的骨肉被烧死。\r\n因为没有制空权，补给线被炸断，零下四十度的...",
            "uri": "douban://douban.com/review/13894075",
            "ad_info": null,
            "topic": null,
            "photos": [],
            "reactions_count": 1,
            "comments_count": 628,
            "user": {
                "kind": "user",
                "name": "llcaakk",
                "url": "https://www.douban.com/people/137315620/",
                "uri": "douban://douban.com/user/137315620",
                "avatar": "https://img1.doubanio.com/icon/up137315620-8.jpg",
                "is_club": false,
                "type": "user",
                "id": "137315620",
                "uid": "137315620"
            },
            "create_time": "2021-09-30 16:26:09",
            "reshares_count": 47,
            "type": "review",
            "id": "13894075",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 3,
                "value": 3
            },
            "useful_count": 1011,
            "sharing_url": "https://movie.douban.com/review/13899575/",
            "title": "如果用王家卫的风格拍长津湖",
            "url": "https://movie.douban.com/review/13899575/",
            "abstract": "很久以后我才知道，\r\n九岁和十九岁的中间有十年，\r\n十九岁和二十九岁的中间，\r\n却有一生。\r\n我叫伍万里，\r\n读万卷书，行万里路。\r\n我虽然没有读过万卷书，\r\n但有些人，一生下来就注定要行万里路。\r\n四处漂泊，无法落脚。\r\n但偏偏就在我十九岁的时候，\r\n在抗美援朝的路上，\r\n那个戴着红色围巾的姑娘，\r\n把她的围巾扔给了我。\r\n围巾总是让人变得暖和，\r\n但戴上围巾的那一刻，\r\n我却冷的厉害。\r\n也是在那天，\r\n我才明白，\r\n织一条围巾要七天，\r\n抗美援朝要三年，\r\n可是爱上一个人，\r\n却只要一眼。\r\n还记得她追着火车...",
            "uri": "douban://douban.com/review/13899575",
            "ad_info": null,
            "topic": null,
            "photos": [],
            "reactions_count": 1,
            "comments_count": 130,
            "user": {
                "kind": "user",
                "name": "木青白白白",
                "url": "https://www.douban.com/people/166574454/",
                "uri": "douban://douban.com/user/166574454",
                "avatar": "https://img9.doubanio.com/icon/up166574454-6.jpg",
                "is_club": false,
                "type": "user",
                "id": "166574454",
                "uid": "166574454"
            },
            "create_time": "2021-10-02 23:42:26",
            "reshares_count": 46,
            "type": "review",
            "id": "13899575",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 5,
                "value": 5
            },
            "useful_count": 1920,
            "sharing_url": "https://movie.douban.com/review/13893094/",
            "title": "冰雪长津湖 初醒冬与狮",
            "url": "https://movie.douban.com/review/13893094/",
            "abstract": "       太多太多的细节一刷肯定是看不尽记不全的，对比、隐喻、致敬用的水到渠成，很多彩蛋有待观众们共同挖掘。\r\n       铭记历史的用意也远不止于过去，70年前的仗我们在冰天雪地里打完了，70年后的电影里，背景中再二再三的朗读报道、横幅标语、石头碑刻上横竖都写着“一定要收复台湾”。从北走到南，从黑走到白，万里从军且凭一句不让家里的两亩三分地，我辈仍需努力。\r\n       本片没有着力于抠观众的泪腺，才把住了细水长流的腔血。紧张中有诙谐，热血中有俏皮，悲壮中有活泼，血肉横飞中有嬉笑怒骂。\r\n    ...",
            "uri": "douban://douban.com/review/13893094",
            "ad_info": null,
            "topic": null,
            "photos": [
                {
                    "tag_name": "img_6536905",
                    "id": "6536905",
                    "image": {
                        "large": {
                            "url": "https://img9.doubanio.com/view/thing_review/l/public/p6536905.jpg",
                            "width": 600,
                            "height": 800,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img9.doubanio.com/view/thing_review/l/public/p6536905.jpg",
                            "width": 600,
                            "height": 800,
                            "size": 0
                        }
                    },
                    "description": "9月25日首映结束全场自发鼓掌毫不夸张"
                },
                {
                    "tag_name": "img_6536907",
                    "id": "6536907",
                    "image": {
                        "large": {
                            "url": "https://img1.doubanio.com/view/thing_review/l/public/p6536907.jpg",
                            "width": 600,
                            "height": 359,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img1.doubanio.com/view/thing_review/l/public/p6536907.jpg",
                            "width": 600,
                            "height": 359,
                            "size": 0
                        }
                    },
                    "description": "影院内布置的“各部登车”版灯箱海报"
                },
                {
                    "tag_name": "img_6536908",
                    "id": "6536908",
                    "image": {
                        "large": {
                            "url": "https://img1.doubanio.com/view/thing_review/l/public/p6536908.jpg",
                            "width": 600,
                            "height": 413,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img1.doubanio.com/view/thing_review/l/public/p6536908.jpg",
                            "width": 600,
                            "height": 413,
                            "size": 0
                        }
                    },
                    "description": "“打得一拳开，免得百拳来”"
                }
            ],
            "reactions_count": 1,
            "comments_count": 333,
            "user": {
                "kind": "user",
                "name": "南尔玉嘉",
                "url": "https://www.douban.com/people/247305407/",
                "uri": "douban://douban.com/user/247305407",
                "avatar": "https://img2.doubanio.com/icon/up247305407-1.jpg",
                "is_club": false,
                "type": "user",
                "id": "247305407",
                "uid": "247305407"
            },
            "create_time": "2021-09-30 01:16:03",
            "reshares_count": 99,
            "type": "review",
            "id": "13893094",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 3,
                "value": 3
            },
            "useful_count": 530,
            "sharing_url": "https://movie.douban.com/review/13899570/",
            "title": "两场轰轰烈烈的战斗，一场模模糊糊的战役",
            "url": "https://movie.douban.com/review/13899570/",
            "abstract": "如今的电影工业早已让战争片的场面达到了二十年前无法想象的境界，但《大决战三部曲》、《血战台儿庄》这些8、90年代的作品却依然被誉为国产战争片的巅峰，这其中的原因，尽在这部国庆档大作之中。\r\n三个小时篇幅还原长津湖战役，本来绰绰有余，但编导团队在追求视觉效果和主旋律情绪的方针下，却把战役简化为了战斗。恢弘的战场实景拍摄的确能让三个小时转瞬即逝，但看完后你会发现，对于长津湖这场抗美援朝最惨烈战役的全貌，你的印象依然是模糊的。\r\n如果你看过十年前八一电影制片厂的纪录片《冰血长津湖》，就...",
            "uri": "douban://douban.com/review/13899570",
            "ad_info": null,
            "topic": null,
            "photos": [],
            "reactions_count": 1,
            "comments_count": 166,
            "user": {
                "kind": "user",
                "name": "陈一坨",
                "url": "https://www.douban.com/people/83320143/",
                "uri": "douban://douban.com/user/83320143",
                "avatar": "https://img2.doubanio.com/icon/up83320143-2.jpg",
                "is_club": false,
                "type": "user",
                "id": "83320143",
                "uid": "83320143"
            },
            "create_time": "2021-10-02 23:41:12",
            "reshares_count": 14,
            "type": "review",
            "id": "13899570",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 3,
                "value": 3
            },
            "useful_count": 393,
            "sharing_url": "https://movie.douban.com/review/13898450/",
            "title": "看还是能看的，但是没必要上纲上线只是一部商业片",
            "url": "https://movie.douban.com/review/13898450/",
            "abstract": "我看了后，感觉没有原来老抗美援朝电影的味道，商业大片， [易烊千玺] 演的角色就是败笔，吊儿郎当的样子，开始不说了，后边都说部队再济南还是哪整训了，然后再火车上还是那个鸟样子。现在很多电影电视塑造的士兵根本没个兵样子，都是痞子样。战争场面前边的仁川登陆真假，还不如用老电影片段呢，后边战斗场面像红海行动，但是到最后雷公死了和冰雕连我哭了。致敬最可爱的人民子弟兵。还有感觉电影很多都是表达了美式个人英雄主义，而不是我们的大无畏的牺牲精神。志愿军的事迹是感人的，但是电影的拍出来的效果...",
            "uri": "douban://douban.com/review/13898450",
            "ad_info": null,
            "topic": null,
            "photos": [],
            "reactions_count": 1,
            "comments_count": 344,
            "user": {
                "kind": "user",
                "name": "龙腾",
                "url": "https://www.douban.com/people/219862594/",
                "uri": "douban://douban.com/user/219862594",
                "avatar": "https://img2.doubanio.com/icon/user_large.jpg",
                "is_club": false,
                "type": "user",
                "id": "219862594",
                "uid": "219862594"
            },
            "create_time": "2021-10-02 13:56:57",
            "reshares_count": 1,
            "type": "review",
            "id": "13898450",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 5,
                "value": 5
            },
            "useful_count": 649,
            "sharing_url": "https://movie.douban.com/review/13894079/",
            "title": "长津湖观后小感",
            "url": "https://movie.douban.com/review/13894079/",
            "abstract": "从影院出来有种恍如隔世的感觉\r\n中国人，总是被他们之中最勇敢的人保护得很好\r\n徐峥说看完这样的电影就觉得语言特别的苍白无力\r\n出来看着熙熙攘攘的人群，热热闹闹的商场，老人们安逸的牌局，想说声谢谢但也太轻了\r\n我不是历史迷也不是军迷，作为大多数中普普通通的一个，真的很惭愧，上一次去了解这些东西估计是很多年前的历史课本上了，而当时的我只会抱怨这些东西怎么那么难记。\r\n这段时间因为电影的缘故，刷了不少老兵的采访。没有哪个人讲到当年的事不是潸然泪下，看的人好沉重。印象很深刻的，有个爷爷他的...",
            "uri": "douban://douban.com/review/13894079",
            "ad_info": null,
            "topic": null,
            "photos": [],
            "reactions_count": 1,
            "comments_count": 421,
            "user": {
                "kind": "user",
                "name": "寒灯独可亲",
                "url": "https://www.douban.com/people/161899706/",
                "uri": "douban://douban.com/user/161899706",
                "avatar": "https://img2.doubanio.com/icon/up161899706-3.jpg",
                "is_club": false,
                "type": "user",
                "id": "161899706",
                "uid": "161899706"
            },
            "create_time": "2021-09-30 16:28:45",
            "reshares_count": 14,
            "type": "review",
            "id": "13894079",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 5,
                "value": 5
            },
            "useful_count": 211,
            "sharing_url": "https://movie.douban.com/review/13895758/",
            "title": "万里的青春在这一刻落幕，我明白了军事力量的意义。",
            "url": "https://movie.douban.com/review/13895758/",
            "abstract": "昨晚看完了长津湖。出来之后，老公问我怎么样，我红着眼圈说，深受震撼，深受教育。电影场里，我的背后一直有抽泣声。但我右边的女生估计是陪同伴来的，一直不耐烦地过一段时间刷一下手机，还在座位上左动右动，我老公左边的男人在电影后半程，一边在手机上打游戏，一边说这个电影拍的太血腥。同一部电影不同的人看确实会有不同的感觉。\r\n我问我老公有没有哭，我老公说他看过太多抗美援朝的资料了，已经有一定承受能力了，他说在资料里真实的战场比这里更要艰苦残酷。他说最后的冰雕团，不是电影里展示的十几个人...",
            "uri": "douban://douban.com/review/13895758",
            "ad_info": null,
            "topic": null,
            "photos": [],
            "reactions_count": 1,
            "comments_count": 110,
            "user": {
                "kind": "user",
                "name": "六朝悬鹑",
                "url": "https://www.douban.com/people/133871166/",
                "uri": "douban://douban.com/user/133871166",
                "avatar": "https://img9.doubanio.com/icon/up133871166-16.jpg",
                "is_club": false,
                "type": "user",
                "id": "133871166",
                "uid": "133871166"
            },
            "create_time": "2021-10-01 10:32:17",
            "reshares_count": 4,
            "type": "review",
            "id": "13895758",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 4,
                "value": 4
            },
            "useful_count": 189,
            "sharing_url": "https://movie.douban.com/review/13895623/",
            "title": "《长津湖》：一腔流不尽的英雄血",
            "url": "https://movie.douban.com/review/13895623/",
            "abstract": "终于看了《长津湖》。\r\n这是一个让人不敢贸然碰触却又不容错过的题材。因为这场发生在极度寒冷、志愿军物资极度匮乏下的战争，是何等惨烈、残酷而又震撼人心；因为那么多志愿军战士在极限情况下，以血肉之躯对抗“武装到牙齿”的美军，并取得了艰苦卓绝的胜利；因为在冰天雪地、高山峡谷里，数不尽的英灵为祖国而呼号怒吼；因为寒风呼啸中的长津湖静默无语，内里却涌动着中国军人一腔流不尽的英雄血。\r\n影片中，伍百里、伍千里、伍万里……伍氏三兄弟前赴后继奔赴疆场。百、千、万，这是无数中华儿女的一个缩影。\r...",
            "uri": "douban://douban.com/review/13895623",
            "ad_info": null,
            "topic": null,
            "photos": [],
            "reactions_count": 1,
            "comments_count": 16,
            "user": {
                "kind": "user",
                "name": "薛易",
                "url": "https://www.douban.com/people/1359768/",
                "uri": "douban://douban.com/user/1359768",
                "avatar": "https://img9.doubanio.com/icon/up1359768-5.jpg",
                "is_club": false,
                "type": "user",
                "id": "1359768",
                "uid": "xygoing"
            },
            "create_time": "2021-10-01 08:33:32",
            "reshares_count": 10,
            "type": "review",
            "id": "13895623",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 4,
                "value": 4
            },
            "useful_count": 105,
            "sharing_url": "https://movie.douban.com/review/13898963/",
            "title": "长津湖：惊喜和遗憾都有",
            "url": "https://movie.douban.com/review/13898963/",
            "abstract": "《长津湖》才上映两天，各种评价就已经铺天盖地，大概是因为已经被剧透过了，有些缺点已经知道而且预期降低了，所以最后看下来整体观感还挺好。以下是看完了回来的瞎写写。\r\n观感好不好主要是看期待吧。如果预期是想看一部像《大决战》系列那样全面讲述长津湖战役的电影，那比较失望也不奇怪。如果只是当一部商业兼爱国大片来看，那观感应该挺好。\r\n影片改叫《钢七连之长津湖》之类的可能更符合主要内容，因为全篇都是围绕钢七连展开的。但是宣发时有说是纪念长津湖战役，这样让了解志愿军战史，想看长津湖整个战...",
            "uri": "douban://douban.com/review/13898963",
            "ad_info": null,
            "topic": null,
            "photos": [
                {
                    "tag_name": "img_6546168",
                    "id": "6546168",
                    "image": {
                        "large": {
                            "url": "https://img1.doubanio.com/view/thing_review/l/public/p6546168.jpg",
                            "width": 540,
                            "height": 756,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img1.doubanio.com/view/thing_review/l/public/p6546168.jpg",
                            "width": 540,
                            "height": 756,
                            "size": 0
                        }
                    },
                    "description": ""
                },
                {
                    "tag_name": "img_6546169",
                    "id": "6546169",
                    "image": {
                        "large": {
                            "url": "https://img1.doubanio.com/view/thing_review/l/public/p6546169.jpg",
                            "width": 540,
                            "height": 756,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img1.doubanio.com/view/thing_review/l/public/p6546169.jpg",
                            "width": 540,
                            "height": 756,
                            "size": 0
                        }
                    },
                    "description": ""
                },
                {
                    "tag_name": "img_6546171",
                    "id": "6546171",
                    "image": {
                        "large": {
                            "url": "https://img2.doubanio.com/view/thing_review/l/public/p6546171.jpg",
                            "width": 600,
                            "height": 1060,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img2.doubanio.com/view/thing_review/l/public/p6546171.jpg",
                            "width": 600,
                            "height": 1060,
                            "size": 0
                        }
                    },
                    "description": ""
                }
            ],
            "reactions_count": 1,
            "comments_count": 27,
            "user": {
                "kind": "user",
                "name": "明灵猫猫",
                "url": "https://www.douban.com/people/242457392/",
                "uri": "douban://douban.com/user/242457392",
                "avatar": "https://img2.doubanio.com/icon/up242457392-1.jpg",
                "is_club": false,
                "type": "user",
                "id": "242457392",
                "uid": "242457392"
            },
            "create_time": "2021-10-02 19:24:54",
            "reshares_count": 3,
            "type": "review",
            "id": "13898963",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 5,
                "value": 5
            },
            "useful_count": 132,
            "sharing_url": "https://movie.douban.com/review/13893127/",
            "title": "好！",
            "url": "https://movie.douban.com/review/13893127/",
            "abstract": "看过首映，憋了好几天不能剧透。今天上映了，终于可以说了。\r\n这部电影好，非常好。在imax厅看的很爽，总觉得下一秒炸弹就要飞我脸上一样。战场部分非常宏大，我们志愿军取胜不易，艰难的外部环境，硌牙的冻土豆，风雪布衣，美军热咖啡，棉衣，大鱼大肉，还想过感恩节。这个对比真的很痛心。麦克阿瑟不可一世结果还不是被痛打。\r\n整部电影基调把握的非常正确，没有一味夸大志愿军，也没有夸大美军，站在我们终将胜利的立场，把长津湖拍出来了。\r\n陈凯歌导演不愧是导过霸王别姬的导演，火车上那一幕太美了，直接震...",
            "uri": "douban://douban.com/review/13893127",
            "ad_info": null,
            "topic": null,
            "photos": [
                {
                    "tag_name": "img_6543564",
                    "id": "6543564",
                    "image": {
                        "large": {
                            "url": "https://img9.doubanio.com/view/thing_review/l/public/p6543564.jpg",
                            "width": 600,
                            "height": 800,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img9.doubanio.com/view/thing_review/l/public/p6543564.jpg",
                            "width": 600,
                            "height": 800,
                            "size": 0
                        }
                    },
                    "description": "25号的首映"
                },
                {
                    "tag_name": "img_6543565",
                    "id": "6543565",
                    "image": {
                        "large": {
                            "url": "https://img9.doubanio.com/view/thing_review/l/public/p6543565.jpg",
                            "width": 600,
                            "height": 800,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img9.doubanio.com/view/thing_review/l/public/p6543565.jpg",
                            "width": 600,
                            "height": 800,
                            "size": 0
                        }
                    },
                    "description": "去的路上看到的爷爷奶奶"
                }
            ],
            "reactions_count": 1,
            "comments_count": 62,
            "user": {
                "kind": "user",
                "name": "明天",
                "url": "https://www.douban.com/people/212549593/",
                "uri": "douban://douban.com/user/212549593",
                "avatar": "https://img2.doubanio.com/icon/up212549593-1.jpg",
                "is_club": false,
                "type": "user",
                "id": "212549593",
                "uid": "babymistry"
            },
            "create_time": "2021-09-30 08:18:29",
            "reshares_count": 2,
            "type": "review",
            "id": "13893127",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 2,
                "value": 2
            },
            "useful_count": 48,
            "sharing_url": "https://movie.douban.com/review/13911683/",
            "title": "“史石大片”",
            "url": "https://movie.douban.com/review/13911683/",
            "abstract": "异国极寒，千里冰封，万里雪飘。\r\n望火车之外，祖国山河一片红，东方巨龙要腾飞。千里江山美如画，万里长城永不倒！\r\n江山如此多娇，引无数“刺头”竞折腰！\r\n惜“伍家兄弟”，老大“八佰里”，早亡舌下。老二“千里”，孝心可嘉。老三“万里”，面目狰狞二百五！\r\n天地不仁，我长津英雄，以命抗之。一腔热血，铁骨铮铮！身化冰雕不言退！\r\n晚辈泪目，顿首拜祭先烈，英魂永存！",
            "uri": "douban://douban.com/review/13911683",
            "ad_info": null,
            "topic": null,
            "photos": [],
            "reactions_count": 1,
            "comments_count": 26,
            "user": {
                "kind": "user",
                "name": "火星",
                "url": "https://www.douban.com/people/172387538/",
                "uri": "douban://douban.com/user/172387538",
                "avatar": "https://img2.doubanio.com/icon/up172387538-1.jpg",
                "is_club": false,
                "type": "user",
                "id": "172387538",
                "uid": "172387538"
            },
            "create_time": "2021-10-08 19:37:05",
            "reshares_count": 0,
            "type": "review",
            "id": "13911683",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 3,
                "value": 3
            },
            "useful_count": 61,
            "sharing_url": "https://movie.douban.com/review/13909538/",
            "title": "作为主旋律片，还行。作为战争片，不行",
            "url": "https://movie.douban.com/review/13909538/",
            "abstract": "首先这电影的切入点，就是伍家兄弟，伍佰里，伍千里，伍万里。更多的可能是讲兄弟几个的故事，到这里其实也不算不妥，但整个电影80%的时长讲的仍然是去长津湖的路上，而不是长津湖从发动总攻打了近一个月的战役。如果是换做是写作文，这已经是跑题偏题了。\r\n从返乡到紧急集结，一路奔波不停到朝鲜。一路上都是到达一个目的地后短暂修整。几乎就是领导一句话：虽然你们很辛苦，但你们还得继续走。着实没必要，从头到尾就出现了三次一样的情况。还有一些意义不明的镜头，玩闹，嬉戏，比较突兀没必要的女兵镜头。\r\n再...",
            "uri": "douban://douban.com/review/13909538",
            "ad_info": null,
            "topic": null,
            "photos": [],
            "reactions_count": 1,
            "comments_count": 36,
            "user": {
                "kind": "user",
                "name": "Porket",
                "url": "https://www.douban.com/people/248021362/",
                "uri": "douban://douban.com/user/248021362",
                "avatar": "https://img2.doubanio.com/icon/user_large.jpg",
                "is_club": false,
                "type": "user",
                "id": "248021362",
                "uid": "248021362"
            },
            "create_time": "2021-10-07 20:07:42",
            "reshares_count": 0,
            "type": "review",
            "id": "13909538",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 5,
                "value": 5
            },
            "useful_count": 131,
            "sharing_url": "https://movie.douban.com/review/13893187/",
            "title": "震撼！看不够！太绝了！",
            "url": "https://movie.douban.com/review/13893187/",
            "abstract": "25号抢的首映！最直接的感受:震撼！看不够！太绝了！！\r\n首先是战争场面，不愧是巨作，真实，残酷，震撼（大写加粗）！激烈的片段会不由自主的屏住呼吸，身子往座椅上缩…仿佛那些子弹在我身边穿梭就要打到我身上一样…\r\n人物塑造方面，这是兰晓龙的拿手好戏，从士兵突击到我的团长我的团，第七穿插连的群像塑造更丰富了，每个人都是鲜明的，鲜活的，有血有肉，会害怕，也会疼…在他们身上可以看到当年千千万万志愿军的影子。如果你有了解过抗美援朝的历史资料和纪录片，就会发现影片中都有所诠释，所以会更加触及...",
            "uri": "douban://douban.com/review/13893187",
            "ad_info": null,
            "topic": null,
            "photos": [],
            "reactions_count": 1,
            "comments_count": 37,
            "user": {
                "kind": "user",
                "name": "紫色墨镜",
                "url": "https://www.douban.com/people/184107889/",
                "uri": "douban://douban.com/user/184107889",
                "avatar": "https://img9.doubanio.com/icon/up184107889-5.jpg",
                "is_club": false,
                "type": "user",
                "id": "184107889",
                "uid": "184107889"
            },
            "create_time": "2021-09-30 09:28:29",
            "reshares_count": 1,
            "type": "review",
            "id": "13893187",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 4,
                "value": 4
            },
            "useful_count": 30,
            "sharing_url": "https://movie.douban.com/review/13896715/",
            "title": "陈凯歌的浪漫主义色彩",
            "url": "https://movie.douban.com/review/13896715/",
            "abstract": "《长津湖》做出了大规模立体化战争的视效盛宴，尺度之大，战争场面之真实，给予了极高的代入感！176分钟的时长虽长，但绝对值得！战争有着铁一样的法则，我们在消耗中忍耐，看到片中零下40度的极端天气却只穿着单衣的志愿军战士们，以及美军在撤退途中看见被冻住的志愿军战士，凸显战争的残酷性，他们的奉献牺牲我们永远不能忘记。\r\n三个导演各施所长的合作给了这部电影不一样的精彩，在紧张刺激的战争场面之外，凯歌导演以他一以贯之的人文主义气息和家国情怀，给了这部电影经典的底色。陈凯歌导演的部分太好认了...",
            "uri": "douban://douban.com/review/13896715",
            "ad_info": null,
            "topic": null,
            "photos": [],
            "reactions_count": 1,
            "comments_count": 66,
            "user": {
                "kind": "user",
                "name": "格兰芬多",
                "url": "https://www.douban.com/people/56830853/",
                "uri": "douban://douban.com/user/56830853",
                "avatar": "https://img2.doubanio.com/icon/up56830853-13.jpg",
                "is_club": false,
                "type": "user",
                "id": "56830853",
                "uid": "56830853"
            },
            "create_time": "2021-10-01 19:31:38",
            "reshares_count": 2,
            "type": "review",
            "id": "13896715",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 5,
                "value": 5
            },
            "useful_count": 210,
            "sharing_url": "https://movie.douban.com/review/13895025/",
            "title": "打得一拳开，免得百拳来！",
            "url": "https://movie.douban.com/review/13895025/",
            "abstract": "【IMAX《长津湖》！】\r\n一定要看一场IMAX的！……不血腥，但战争场面宏大震撼，绝不亚于任何国内外的大片！\r\n感谢屁股正到不行的陈凯歌导演。\r\n我不想看那些虚头八脑的所谓“反战”。“打得一拳开，免得百拳来”，才是真正的反战。\r\n我们不是战争的发起方，但是，我是不怕任何方面发起的战争！\r\n反战，不是跪下去做奴隶，也不是面对牺牲哭唧唧……\r\n反战，就是告诉你：\r\n我爱我的生命，我爱我的家人，我爱我的祖国，我想好好活着，但是你若是想凌辱我，我愿意用一切作为武器拼搏到底，用一场让你畏惧的战斗，免去...",
            "uri": "douban://douban.com/review/13895025",
            "ad_info": null,
            "topic": null,
            "photos": [
                {
                    "tag_name": "img_6540319",
                    "id": "6540319",
                    "image": {
                        "large": {
                            "url": "https://img1.doubanio.com/view/thing_review/l/public/p6540319.jpg",
                            "width": 600,
                            "height": 1066,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img1.doubanio.com/view/thing_review/l/public/p6540319.jpg",
                            "width": 600,
                            "height": 1066,
                            "size": 0
                        }
                    },
                    "description": ""
                },
                {
                    "tag_name": "img_6540322",
                    "id": "6540322",
                    "image": {
                        "large": {
                            "url": "https://img2.doubanio.com/view/thing_review/l/public/p6540322.jpg",
                            "width": 600,
                            "height": 400,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img2.doubanio.com/view/thing_review/l/public/p6540322.jpg",
                            "width": 600,
                            "height": 400,
                            "size": 0
                        }
                    },
                    "description": ""
                },
                {
                    "tag_name": "img_6540318",
                    "id": "6540318",
                    "image": {
                        "large": {
                            "url": "https://img1.doubanio.com/view/thing_review/l/public/p6540318.jpg",
                            "width": 600,
                            "height": 400,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img1.doubanio.com/view/thing_review/l/public/p6540318.jpg",
                            "width": 600,
                            "height": 400,
                            "size": 0
                        }
                    },
                    "description": ""
                }
            ],
            "reactions_count": 1,
            "comments_count": 162,
            "user": {
                "kind": "user",
                "name": "小张姐姐",
                "url": "https://www.douban.com/people/100410680/",
                "uri": "douban://douban.com/user/100410680",
                "avatar": "https://img9.doubanio.com/icon/up100410680-6.jpg",
                "is_club": false,
                "type": "user",
                "id": "100410680",
                "uid": "xiaozhangjiejie"
            },
            "create_time": "2021-09-30 23:32:53",
            "reshares_count": 2,
            "type": "review",
            "id": "13895025",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 5,
                "value": 5
            },
            "useful_count": 16,
            "sharing_url": "https://movie.douban.com/review/13895012/",
            "title": "震撼",
            "url": "https://movie.douban.com/review/13895012/",
            "abstract": "《长津湖》牛逼！抗美援朝志愿军牛逼！\r\n看之前担心一：电影时长近三小时；二：凯子哥会不会搞很多无用的煽情&amp;浪漫主义情怀？\r\n看到电影后，顾虑都被打消了。电影时长两小时四十分钟，有波澜壮阔的祖国山河画卷，有江南水乡渔民的生活写照，也有万里长城的俯拍全景，伴随着夕阳余晖映照大地，万里小朋友第一次找到了打仗的意义；凯子哥应该也有发挥浪漫，但很恰如其分，毕竟还有另外两位擅长动作戏的大导，加上《士兵突击》电视剧编剧操刀，全程情节紧凑，作战逻辑清晰，时间线紧凑连贯，节奏拿捏的非常到位，...",
            "uri": "douban://douban.com/review/13895012",
            "ad_info": null,
            "topic": null,
            "photos": [],
            "reactions_count": 1,
            "comments_count": 22,
            "user": {
                "kind": "user",
                "name": "最甜小星星",
                "url": "https://www.douban.com/people/1546213/",
                "uri": "douban://douban.com/user/1546213",
                "avatar": "https://img9.doubanio.com/icon/up1546213-14.jpg",
                "is_club": false,
                "type": "user",
                "id": "1546213",
                "uid": "CTT"
            },
            "create_time": "2021-09-30 23:28:58",
            "reshares_count": 0,
            "type": "review",
            "id": "13895012",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 5,
                "value": 5
            },
            "useful_count": 340,
            "sharing_url": "https://movie.douban.com/review/13893128/",
            "title": "新兵伍万里和演员易烊千玺的三倍人生",
            "url": "https://movie.douban.com/review/13893128/",
            "abstract": "“电影使人生的长度延长了三倍”电影《一一》里的一句话。\r\n于冬、吴京在和千玺合作完以后就发出天才感叹。有幸在9.25抢到超前观影的机会，感受这部拍摄立国之战的影片也感受天才的演绎。\r\n伍万里的倍数人生：\r\n一如我在短评里写的，伍万里是电影的眼。他曾经离战争很遥远，战争是他失去的长兄百里，也是他离家11年未归的二哥千里，从来不是这个江边打水漂撒野戴着长命锁的小宝贝。无论空间还是时间上，我们现在离战争更遥远，只有电视里的巴以冲突，美军攻打伊拉克，美军盘踞在阿富汗十几年，和影像资料中的抗美...",
            "uri": "douban://douban.com/review/13893128",
            "ad_info": null,
            "topic": null,
            "photos": [
                {
                    "tag_name": "img_6537134",
                    "id": "6537134",
                    "image": {
                        "large": {
                            "url": "https://img9.doubanio.com/view/thing_review/l/public/p6537134.jpg",
                            "width": 600,
                            "height": 600,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img9.doubanio.com/view/thing_review/l/public/p6537134.jpg",
                            "width": 600,
                            "height": 600,
                            "size": 0
                        }
                    },
                    "description": "留念"
                },
                {
                    "tag_name": "img_6539825",
                    "id": "6539825",
                    "image": {
                        "large": {
                            "url": "https://img9.doubanio.com/view/thing_review/l/public/p6539825.jpg",
                            "width": 396,
                            "height": 3000,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img9.doubanio.com/view/thing_review/l/public/p6539825.jpg",
                            "width": 396,
                            "height": 3000,
                            "size": 0
                        }
                    },
                    "description": "这几年的观影自己的记录"
                }
            ],
            "reactions_count": 1,
            "comments_count": 86,
            "user": {
                "kind": "user",
                "name": "FourQuartets",
                "url": "https://www.douban.com/people/2875988/",
                "uri": "douban://douban.com/user/2875988",
                "avatar": "https://img2.doubanio.com/icon/up2875988-21.jpg",
                "is_club": false,
                "type": "user",
                "id": "2875988",
                "uid": "sulashen"
            },
            "create_time": "2021-09-30 08:20:46",
            "reshares_count": 9,
            "type": "review",
            "id": "13893128",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 5,
                "value": 5
            },
            "useful_count": 86,
            "sharing_url": "https://movie.douban.com/review/13893123/",
            "title": "我看过的最好的国产战争片",
            "url": "https://movie.douban.com/review/13893123/",
            "abstract": "有幸作为首批观众观看了点映，跟许多观众一样，不以为然地进，满目沉重地出。\r\n在这之前，一直觉得国产战争片弊病太多，思想不正的，画面拉胯的，个人英雄主义严重的……可是这些，在长津湖里都没有出现。开篇就定下了为什么要抗美援朝，为什么要打这场仗，很稳很正。\r\n画面美不用说，凯歌导演这次值得一夸。徐导和林导更不用说，战争戏真是一绝，战术表现得也很精彩很到位，让人恨不得冲进屏幕暴揍美国佬。\r\n再说演员，易烊千玺，很牛。从他的第一部电影到现在，我都有看，每一个角色都完全不同，伍万里更是让我...",
            "uri": "douban://douban.com/review/13893123",
            "ad_info": null,
            "topic": null,
            "photos": [],
            "reactions_count": 1,
            "comments_count": 178,
            "user": {
                "kind": "user",
                "name": "谷子狸",
                "url": "https://www.douban.com/people/183669133/",
                "uri": "douban://douban.com/user/183669133",
                "avatar": "https://img2.doubanio.com/icon/up183669133-1.jpg",
                "is_club": false,
                "type": "user",
                "id": "183669133",
                "uid": "183669133"
            },
            "create_time": "2021-09-30 08:10:41",
            "reshares_count": 2,
            "type": "review",
            "id": "13893123",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        },
        {
            "rating": {
                "count": 1,
                "max": 5,
                "star_count": 4,
                "value": 4
            },
            "useful_count": 124,
            "sharing_url": "https://movie.douban.com/review/13902746/",
            "title": "《长津湖》：冰与血之歌",
            "url": "https://movie.douban.com/review/13902746/",
            "abstract": "看完《长津湖》，我的心情久久不能平静。造成不平静的原因，和以往看片不一样，不是因为这部片太好或者太差，而是因为这样的故事从来不在自己的认知范围内，而你还知道它是真的，这种感觉让人无法平静。\r\n以一个相同规模大制作的史诗级战争片标准来衡量，《长津湖》确实还可以更好。但是，我奇怪的心理是，明知它没有那么好，却不忍心批评。我更愿意把它当作一次历史现场的还原记录来看，从这个角度而言，它好或不好都没有存在本身重要。\r\n电影《长津湖》取材于1950年冬天朝鲜战场上的真实故事。长津湖战役，在世...",
            "uri": "douban://douban.com/review/13902746",
            "ad_info": null,
            "topic": null,
            "photos": [
                {
                    "tag_name": "img_6552215",
                    "id": "6552215",
                    "image": {
                        "large": {
                            "url": "https://img9.doubanio.com/view/thing_review/l/public/p6552215.jpg",
                            "width": 600,
                            "height": 351,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img9.doubanio.com/view/thing_review/l/public/p6552215.jpg",
                            "width": 600,
                            "height": 351,
                            "size": 0
                        }
                    },
                    "description": ""
                },
                {
                    "tag_name": "img_6552216",
                    "id": "6552216",
                    "image": {
                        "large": {
                            "url": "https://img9.doubanio.com/view/thing_review/l/public/p6552216.jpg",
                            "width": 600,
                            "height": 400,
                            "size": 0
                        },
                        "raw": null,
                        "is_animated": false,
                        "normal": {
                            "url": "https://img9.doubanio.com/view/thing_review/l/public/p6552216.jpg",
                            "width": 600,
                            "height": 400,
                            "size": 0
                        }
                    },
                    "description": ""
                }
            ],
            "reactions_count": 1,
            "comments_count": 66,
            "user": {
                "kind": "user",
                "name": "mumudancing",
                "url": "https://www.douban.com/people/1553180/",
                "uri": "douban://douban.com/user/1553180",
                "avatar": "https://img9.doubanio.com/icon/up1553180-95.jpg",
                "is_club": false,
                "type": "user",
                "id": "1553180",
                "uid": "mumudancing"
            },
            "create_time": "2021-10-04 14:43:52",
            "reshares_count": 10,
            "type": "review",
            "id": "13902746",
            "subject": {
                "type": "movie",
                "title": "长津湖"
            }
        }
    ]
}
module.exports.yingping=data