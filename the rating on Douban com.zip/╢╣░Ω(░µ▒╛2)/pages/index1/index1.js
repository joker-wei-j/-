const app=getApp();
// pages/index1/index1.js
// const hotShowing = require("../豆瓣电影临时本地数据data/1.首页影院热映信息.js")
// const doubanHot = require("../豆瓣电影临时本地数据data/2.豆瓣热门.js")
// const hotTV = require("../豆瓣电影临时本地数据data/3.近期热门剧集.js")
// const hotShow = require("../豆瓣电影临时本地数据data/4.近期热门综艺.js")
Page({

  /**
   * 页面的初始数据
   */

  data: {
    // 模板复用
    hotShowing: {
      topic: "影院热映",
      dataLIst: []
    },
    doubanHot: {
      topic: "豆瓣热门",
      dataLIst:[]
    },
    hotTV: {
      topic: "近期热门剧集",
      dataLIst: []
    },
    hotShow: {
      topic: "近期热门综艺节目",
      dataLIst: []
    },
    book: {
      topic: "畅销图书",
      dataLIst: []
    },
    danqu: {
      topic: "热门单曲榜",
      dataLIst: []
    }
  },
  //页面向js传参：特殊属性 data-参数名=“参数值”
  toMore(e) {
    // console.log(e);
    let topic = e.target.dataset.topic;
    // console.log(topic);
    wx.navigateTo({
      url: `../more/more?topic=${topic}`,
    })
  },
  // 跳转到搜索
  toSearch() {
    wx.navigateTo({
      url: "../search/search",
    })
  },
  // 跳转到详情
  toDetails(e) {
    // console.log(e);
    let img = e.currentTarget.dataset.img
    let title = e.currentTarget.dataset.title
    let rate = e.currentTarget.dataset.rate
    wx.navigateTo({
      url: `../details/details?title=${title}&img=${img}&rate=${rate}`,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.request({
      url: 'http://www.doubanppp.com/page.php',
      success: (res) => {
        // console.log(res);
        let data = res.data;
        this.setData({
          hotShowing: {
            topic: "影院热映",
            dataLIst: data
          },
        });
      }
    }),
    wx.request({
      url: 'http://www.doubanppp.com/hotShow.php',
      success: (res) => {
        // console.log(res);
        let data = res.data;
        this.setData({
          doubanHot: {
            topic: "豆瓣热门",
            dataLIst:data
          },
        });
      }
    }),
    wx.request({
      url: 'http://www.doubanppp.com/recentHot.php',
      success: (res) => {
        // console.log(res);
        let data = res.data;
        this.setData({
          hotTV: {
            topic: "近期热门剧集",
            dataLIst: data
          },
        });
      }
    }),
    wx.request({
      url: 'http://www.doubanppp.com/zongyi.php',
      success: (res) => {
        // console.log(res);
        let data = res.data;
        this.setData({
          hotShow: {
            topic: "近期热门综艺节目",
            dataLIst: data
          }
        });
      }
    }),
    wx.request({
      url: 'http://www.doubanppp.com/tushu.php',
      success: (res) => {
        let data = res.data;
        // console.log(data);
        this.setData({
          book: {
            topic: "畅销图书",
            dataLIst: data
          }
        });
      }
    }),
    wx.request({
      url: 'http://www.doubanppp.com/danqu.php',
      success: (res) => {
        // console.log(res);
        let data = res.data;
        this.setData({
          danqu: {
            topic: "热门单曲榜",
            dataLIst: data
          }
        });
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})