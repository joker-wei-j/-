// pages/still/still.js
const juzhao = require("../豆瓣电影临时本地数据data/详情页数据/剧照/详情页长津湖数据剧照第1页.js")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    juzhao: juzhao.juzhao.photos,
    dataList: [],
    currentPage: 1,
    imgUrl: []
  },
  // 点击大图事件
  fangda: function (e) {
    console.log(e);
    let imgUrl = e.currentTarget.dataset.imgurl
    wx.previewImage({
      current: imgUrl,
      urls: this.data.imgUrl,
    })
  },
  onLoad: function (options) {
    // 剧照
    wx.request({
      url: 'http://www.doubanppp.com/juzhaoOne.php',
      success:(res)=>{
        // console.log(res.data.photos);
        let data = res.data;
        this.setData({
          dataList:data
        })
      }
    })
    // img循环
    for (let i = 0; i < this.data.juzhao.length; i++) {
      const img = this.data.juzhao[i].image.large.url;
      let juzhaoImg = [];
      juzhaoImg = img;
      this.setData({
        imgUrl: this.data.imgUrl.concat(juzhaoImg)
      })
    }
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    // console.log(juzhao);
    if (this.data.currentPage < 10) {
      // 更新页码
      this.setData({
        currentPage: this.data.currentPage += 1
      });
      // 模拟ajax
      let newDataList = require(`../豆瓣电影临时本地数据data/详情页数据/剧照/详情页长津湖数据剧照第${this.data.currentPage}页.js`).juzhao.photos;
      console.log(newDataList);
      //  把新数据合并到老数据上面
      this.setData({
        juzhao: this.data.juzhao.concat(newDataList)
      });


      // 预览图片下拉继续加载
      for (let i = 1; i < this.data.juzhao.length; i++) {
        const img = this.data.juzhao[i].image.large.url;
        let arr = [];
        arr = img;
        this.setData({
          imgUrl: this.data.imgUrl.concat(arr)
        })
      }
    }
  },

})