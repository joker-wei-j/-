// app.js
App({
  onLaunch() {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
        success: res => {
          // 发送 res.code 到后台换取 openId, sessionKey, unionId
        }
      })
  },

  globalData: {
    userInfo: null,
    host: "www.doubanppp.com",
// 换肤
    // skin: '', //默认是白天模式
    // reals: false,
  },
  // getSkin: function () {
  //   var that = this
  //   wx.getStorage({
  //     key: 'skin',
  //     success: function (res) {
  //       that.globalData.skin = res.data
  //     }
  //   })
  // },
  // getReals: function () {
  //   var that = this
  //   wx.getStorage({
  //     key: 'reals',
  //     success: function (res) {
  //       that.globalData.reals = res.data
  //     }
  //   })
  // },

})